-- 创建数据库
CREATE DATABASE IF NOT EXISTS club_student_info CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE club_student_info;

-- 创建学生表
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL UNIQUE COMMENT '学号',
    name VARCHAR(50) NOT NULL COMMENT '姓名',
    password VARCHAR(255) NOT NULL COMMENT '密码',
    club VARCHAR(50) NOT NULL COMMENT '社团名称',
    role VARCHAR(20) NOT NULL DEFAULT 'member' COMMENT '角色：member(成员)/admin(管理员)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社团学生信息表';

-- 创建社团表
CREATE TABLE IF NOT EXISTS clubs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE COMMENT '社团名称',
    president VARCHAR(50) NOT NULL COMMENT '社长',
    member_count INT NOT NULL DEFAULT 0 COMMENT '成员数',
    status VARCHAR(20) NOT NULL DEFAULT 'active' COMMENT '状态：active(活跃)/inactive(不活跃)',
    description TEXT COMMENT '社团描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社团信息表';

-- 创建活动表
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL COMMENT '活动标题',
    club VARCHAR(50) NOT NULL COMMENT '举办社团',
    date_time DATETIME NOT NULL COMMENT '活动时间',
    status VARCHAR(20) NOT NULL DEFAULT 'planning' COMMENT '状态：planning(策划中)/registering(报名中)/published(已发布)',
    description TEXT COMMENT '活动描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社团活动表';

-- 创建申请记录表
CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL COMMENT '学号',
    student_name VARCHAR(50) NOT NULL COMMENT '姓名',
    club VARCHAR(50) NOT NULL COMMENT '申请社团',
    status VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态：pending(待审核)/approved(已批准)/rejected(已拒绝)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社团申请记录表';

-- 插入示例学生数据
INSERT INTO students (student_id, name, password, club, role) VALUES
('2021001', '张三', '123456', '计算机社团', 'member'),
('2021002', '李四', '123456', '摄影社团', 'member'),
('2021003', '王五', '123456', '音乐社团', 'admin'),
('2021004', '赵六', '123456', '篮球社团', 'member'),
('2021005', '李晨', '123456', '科创社', 'admin'),
-- 插入管理者账号
('admin001', '管理员', 'admin123', '社团管理部', 'admin'),
('admin002', '系统管理员', 'system123', '社团管理部', 'admin');

-- 插入示例社团数据
INSERT INTO clubs (name, president, member_count, status, description) VALUES
('计算机社团', '张三', 45, 'active', '专注于计算机技术学习和交流'),
('摄影社团', '李四', 32, 'active', '记录生活美好瞬间'),
('音乐社团', '王五', 28, 'active', '分享音乐爱好，组织校园音乐节'),
('篮球社团', '赵六', 42, 'active', '开展篮球训练和比赛'),
('科创社', '李晨', 56, 'active', '科技创新和AI技术交流');

-- 插入示例活动数据
INSERT INTO events (title, club, date_time, status, description) VALUES
('校园音乐节', '社团联合会', '2023-12-20 18:00:00', 'published', '一年一度的校园音乐盛宴'),
('AI技术交流会', '科创社', '2023-12-25 14:00:00', 'planning', '人工智能技术分享和讨论'),
('冬季公益行', '公益社', '2023-12-28 09:00:00', 'registering', '冬季送温暖公益活动');

-- 插入示例申请数据
INSERT INTO applications (student_id, student_name, club, status) VALUES
('2021006', '钱七', '计算机社团', 'pending'),
('2021007', '孙八', '摄影社团', 'pending'),
('2021008', '周九', '音乐社团', 'pending');

-- 查看表结构
DESCRIBE students;
DESCRIBE clubs;
DESCRIBE events;
DESCRIBE applications;

-- 查看插入的数据
SELECT * FROM students;
SELECT * FROM clubs;
SELECT * FROM events;
SELECT * FROM applications;