<?php
// 数据库连接参数
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "club_student_info";

// 开启错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 添加CORS头和允许的方法
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 确保返回JSON格式
header('Content-Type: application/json; charset=utf-8');

// 捕获所有错误
try {
    // 获取POST请求数据
    $rawInput = file_get_contents("php://input");
    $input = json_decode($rawInput, true);

    // 检查JSON解析是否成功
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("JSON解析失败: " . json_last_error_msg());
    }

    // 检查必要字段
    if (!isset($input['username']) || !isset($input['password']) || !isset($input['loginType'])) {
        throw new Exception("缺少必要的请求参数");
    }

    // 获取用户输入
    $studentId = trim($input['username']);
    $password = trim($input['password']);
    $loginType = trim($input['loginType']); // student 或 admin

    // 验证输入数据
    if (empty($studentId) || empty($password) || empty($loginType)) {
        throw new Exception("用户名、密码和登录类型不能为空");
    }

    // 模拟登录功能（当PHP服务器不可用时）
    // 检查是否使用数据库连接（如果PHP和MySQL可用）
    $useDatabase = false;
    $conn = null;
    
    try {
        // 尝试创建数据库连接
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // 检查连接是否成功
        if (!$conn->connect_error) {
            $useDatabase = true;
            // 设置字符集
            $conn->set_charset("utf8mb4");
        }
    } catch (Exception $e) {
        // 数据库连接失败，使用模拟登录
        $useDatabase = false;
    }
    
    if ($useDatabase && $conn !== null) {
        // 使用数据库登录
        // 准备SQL查询，根据登录类型筛选
        if ($loginType === 'student') {
            // 学生登录 - 只允许普通成员登录
            $stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ? AND role = 'member'");
        } else if ($loginType === 'admin') {
            // 管理者登录 - 只允许管理员登录
            $stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ? AND role = 'admin'");
        } else {
            throw new Exception("无效的登录类型");
        }

        if (!$stmt) {
            throw new Exception("SQL准备失败: " . $conn->error);
        }

        // 绑定参数
        $stmt->bind_param("s", $studentId);

        // 执行查询
        if (!$stmt->execute()) {
            throw new Exception("SQL执行失败: " . $stmt->error);
        }

        // 获取结果
        $result = $stmt->get_result();

        // 检查查询结果
        if ($result->num_rows > 0) {
            // 获取用户数据
            $user = $result->fetch_assoc();
            
            // 验证密码（支持哈希密码）
            if (password_verify($password, $user['password'])) {
                // 登录成功，返回用户信息
                echo json_encode(array(
                    "success" => true, 
                    "message" => "登录成功",
                    "user" => array(
                        "id" => $user['student_id'],
                        "name" => $user['name'],
                        "role" => $user['role'],
                        "club" => $user['club']
                    )
                ));
            } else {
                // 密码错误
                echo json_encode(array("success" => false, "message" => "账号或密码错误，请重新填写"));
            }
        } else {
            // 账号不存在或登录类型不匹配
            if ($loginType === 'student') {
                echo json_encode(array("success" => false, "message" => "学生账号不存在或不是普通成员"));
            } else {
                echo json_encode(array("success" => false, "message" => "管理员账号不存在或不是管理员"));
            }
        }

        // 关闭连接
        $stmt->close();
        $conn->close();
    } else {
        // 使用模拟登录
        // 模拟学生账号（与模拟注册配合）
        $simulatedStudentAccounts = array(
            "student001" => array("password" => "password123", "name" => "学生1", "role" => "member", "club" => "计算机社团"),
            "student002" => array("password" => "password456", "name" => "学生2", "role" => "member", "club" => "摄影社团")
        );
        
        // 模拟管理员账号（与模拟注册配合）
        $simulatedAdminAccounts = array(
            "admin001" => array("password" => "admin123", "name" => "管理员1", "role" => "admin", "club" => "社团管理部"),
            "admin002" => array("password" => "admin456", "name" => "管理员2", "role" => "admin", "club" => "社团管理部")
        );
        
        // 根据登录类型验证
        $simulatedUser = null;
        
        if ($loginType === 'student' && isset($simulatedStudentAccounts[$studentId])) {
            if ($simulatedStudentAccounts[$studentId]["password"] === $password) {
                $simulatedUser = $simulatedStudentAccounts[$studentId];
            }
        } else if ($loginType === 'admin' && isset($simulatedAdminAccounts[$studentId])) {
            if ($simulatedAdminAccounts[$studentId]["password"] === $password) {
                $simulatedUser = $simulatedAdminAccounts[$studentId];
            }
        }
        
        if ($simulatedUser !== null) {
            // 模拟登录成功
            echo json_encode(array(
                "success" => true, 
                "message" => "模拟登录成功（PHP服务器不可用）",
                "user" => array(
                    "id" => $studentId,
                    "name" => $simulatedUser["name"],
                    "role" => $simulatedUser["role"],
                    "club" => $simulatedUser["club"]
                )
            ));
        } else {
            // 模拟登录失败
            echo json_encode(array("success" => false, "message" => "账号或密码错误（模拟登录）"));
        }
    }

} catch (Exception $e) {
    // 返回错误信息
    echo json_encode(array(
        "success" => false,
        "message" => "服务器错误: " . $e->getMessage(),
        "debug" => array(
            "error_code" => $e->getCode(),
            "error_file" => $e->getFile(),
            "error_line" => $e->getLine()
        )
    ));
    exit;
}
?>