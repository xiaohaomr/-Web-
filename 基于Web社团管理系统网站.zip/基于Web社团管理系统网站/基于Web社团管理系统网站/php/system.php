<?php
// 设置响应头为JSON格式
header('Content-Type: application/json; charset=utf-8');
// 允许跨域请求
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// 数据库连接参数
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "club_student_info";

// 处理OPTIONS请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

try {
    // 创建数据库连接
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // 检查连接是否成功
    if ($conn->connect_error) {
        throw new Exception("数据库连接失败: " . $conn->connect_error);
    }
    
    // 设置字符集
    $conn->set_charset("utf8mb4");
    
    // 获取请求类型
    $requestType = $_GET['type'] ?? '';
    
    // 根据请求类型处理不同的功能
    switch ($requestType) {
        // 获取统计数据
        case 'stats':
            // 获取活跃社团数量
            $clubCountSql = "SELECT COUNT(*) as count FROM clubs WHERE status = 'active'";
            $clubCountResult = $conn->query($clubCountSql);
            $clubCount = $clubCountResult->fetch_assoc()['count'];
            
            // 获取注册成员总数
            $memberCountSql = "SELECT SUM(member_count) as count FROM clubs";
            $memberCountResult = $conn->query($memberCountSql);
            $memberCount = $memberCountResult->fetch_assoc()['count'];
            
            // 获取待审核申请数量
            $pendingCountSql = "SELECT COUNT(*) as count FROM applications WHERE status = 'pending'";
            $pendingCountResult = $conn->query($pendingCountSql);
            $pendingCount = $pendingCountResult->fetch_assoc()['count'];
            
            // 返回统计数据
            echo json_encode([
                'success' => true,
                'data' => [
                    'clubCount' => $clubCount,
                    'memberCount' => $memberCount,
                    'pendingCount' => $pendingCount
                ]
            ]);
            break;
            
        // 获取活动列表
        case 'events':
            $eventsSql = "SELECT title, club, date_time, status FROM events ORDER BY date_time ASC LIMIT 10";
            $eventsResult = $conn->query($eventsSql);
            
            $events = [];
            while ($row = $eventsResult->fetch_assoc()) {
                $events[] = [
                    'title' => $row['title'],
                    'club' => $row['club'],
                    'date_time' => $row['date_time'],
                    'status' => $row['status']
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $events
            ]);
            break;
            
        // 获取社团列表
        case 'clubs':
            $clubsSql = "SELECT name, president, member_count, status FROM clubs ORDER BY member_count DESC LIMIT 10";
            $clubsResult = $conn->query($clubsSql);
            
            $clubs = [];
            while ($row = $clubsResult->fetch_assoc()) {
                $clubs[] = [
                    'name' => $row['name'],
                    'president' => $row['president'],
                    'member_count' => $row['member_count'],
                    'status' => $row['status']
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $clubs
            ]);
            break;
            
        // 获取申请列表
        case 'applications':
            $appsSql = "SELECT id, student_id, student_name, club, status FROM applications WHERE status = 'pending' ORDER BY created_at ASC";
            $appsResult = $conn->query($appsSql);
            
            $applications = [];
            while ($row = $appsResult->fetch_assoc()) {
                $applications[] = [
                    'id' => $row['id'],
                    'student_id' => $row['student_id'],
                    'student_name' => $row['student_name'],
                    'club' => $row['club'],
                    'status' => $row['status']
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $applications
            ]);
            break;
            
        // 处理审核申请
        case 'audit':
            // 获取POST数据
            $postData = json_decode(file_get_contents('php://input'), true);
            $appId = $postData['id'] ?? '';
            $action = $postData['action'] ?? '';
            
            if (empty($appId) || empty($action)) {
                throw new Exception("缺少必要参数");
            }
            
            // 验证action值
            $validActions = ['approve', 'reject'];
            if (!in_array($action, $validActions)) {
                throw new Exception("无效的操作类型");
            }
            
            // 确定新状态
            $newStatus = ($action == 'approve') ? 'approved' : 'rejected';
            
            // 更新申请状态
            $updateSql = "UPDATE applications SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($updateSql);
            $stmt->bind_param("si", $newStatus, $appId);
            
            if (!$stmt->execute()) {
                throw new Exception("更新申请状态失败: " . $stmt->error);
            }
            
            // 如果批准申请，更新社团成员数
            if ($action == 'approve') {
                // 获取申请的社团名称
                $getAppSql = "SELECT club FROM applications WHERE id = ?";
                $stmtApp = $conn->prepare($getAppSql);
                $stmtApp->bind_param("i", $appId);
                $stmtApp->execute();
                $appResult = $stmtApp->get_result();
                $app = $appResult->fetch_assoc();
                
                if ($app) {
                    // 更新社团成员数
                    $updateClubSql = "UPDATE clubs SET member_count = member_count + 1 WHERE name = ?";
                    $stmtClub = $conn->prepare($updateClubSql);
                    $stmtClub->bind_param("s", $app['club']);
                    $stmtClub->execute();
                }
            }
            
            echo json_encode([
                'success' => true,
                'message' => '申请' . ($action == 'approve' ? '已批准' : '已拒绝')
            ]);
            break;
            
        // 处理注册请求
        case 'register':
            // 添加调试信息
            error_log('Register request received');
            
            // 获取POST数据
            $rawData = file_get_contents('php://input');
            error_log('Raw POST data: ' . $rawData);
            
            $postData = json_decode($rawData, true);
            $schoolName = $postData['schoolName'] ?? '';
            $studentId = $postData['studentId'] ?? '';
            $name = $postData['name'] ?? '';
            $club = $postData['club'] ?? '';
            $password = $postData['password'] ?? '';
            $role = $postData['role'] ?? '';
            
            // 记录接收的参数
            error_log('Received params: studentId=' . $studentId . ', name=' . $name . ', club=' . $club . ', role=' . $role);
            
            // 验证必填字段
            if (empty($studentId) || empty($name) || empty($password) || empty($role) || empty($club)) {
                $missing = [];
                if (empty($studentId)) $missing[] = 'studentId';
                if (empty($name)) $missing[] = 'name';
                if (empty($password)) $missing[] = 'password';
                if (empty($role)) $missing[] = 'role';
                if (empty($club)) $missing[] = 'club';
                error_log('Missing params: ' . implode(', ', $missing));
                throw new Exception("缺少必要参数: " . implode(', ', $missing));
            }
            
            // 验证角色
            $validRoles = ['member', 'admin'];
            if (!in_array($role, $validRoles)) {
                throw new Exception("无效的角色类型");
            }
            
            // 检查学号是否已存在
            $checkSql = "SELECT COUNT(*) as count FROM students WHERE student_id = ?";
            $stmtCheck = $conn->prepare($checkSql);
            $stmtCheck->bind_param("s", $studentId);
            $stmtCheck->execute();
            $result = $stmtCheck->get_result();
            $row = $result->fetch_assoc();
            
            if ($row['count'] > 0) {
                throw new Exception("该学号已注册");
            }
            
            // 密码哈希处理
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // 插入新用户
            $insertSql = "INSERT INTO students (student_id, name, password, club, role) VALUES (?, ?, ?, ?, ?)";
            $stmtInsert = $conn->prepare($insertSql);
            $stmtInsert->bind_param("sssss", $studentId, $name, $hashedPassword, $club, $role);
            
            if (!$stmtInsert->execute()) {
                throw new Exception("注册失败: " . $stmtInsert->error);
            }
            
            // 如果是新社团，添加到社团表
            $checkClubSql = "SELECT COUNT(*) as count FROM clubs WHERE name = ?";
            $stmtCheckClub = $conn->prepare($checkClubSql);
            $stmtCheckClub->bind_param("s", $club);
            $stmtCheckClub->execute();
            $clubResult = $stmtCheckClub->get_result();
            $clubRow = $clubResult->fetch_assoc();
            
            if ($clubRow['count'] == 0) {
                // 添加新社团，默认社长为当前注册用户
                $insertClubSql = "INSERT INTO clubs (name, president, member_count, status, description) VALUES (?, ?, ?, 'active', '')";
                $stmtInsertClub = $conn->prepare($insertClubSql);
                $memberCount = 1;
                $stmtInsertClub->bind_param("ssi", $club, $name, $memberCount);
                $stmtInsertClub->execute();
            } else {
                // 更新社团成员数
                $updateClubSql = "UPDATE clubs SET member_count = member_count + 1 WHERE name = ?";
                $stmtUpdateClub = $conn->prepare($updateClubSql);
                $stmtUpdateClub->bind_param("s", $club);
                $stmtUpdateClub->execute();
            }
            
            echo json_encode([
                'success' => true,
                'message' => '注册成功'
            ]);
            break;
            
        // 默认情况
        default:
            echo json_encode([
                'success' => false,
                'message' => '无效的请求类型'
            ]);
    }
    
    // 关闭数据库连接
    $conn->close();
    
} catch (Exception $e) {
    // 捕获并返回错误信息
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    exit();
}
?>