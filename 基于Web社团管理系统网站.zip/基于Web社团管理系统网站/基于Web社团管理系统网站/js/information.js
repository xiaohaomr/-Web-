// 模拟数据 - 基于database.sql表结构
const mockClubs = [
    { id: 1, name: "计算机社团", category: "科技类", president: "张三", member_count: 45, status: "active", description: "专注于计算机技术学习和交流，涵盖编程、算法、人工智能等领域。", image: "club1.jpg", tag: "热门" },
    { id: 2, name: "摄影社团", category: "文艺类", president: "李四", member_count: 32, status: "active", description: "记录生活美好瞬间，学习摄影技巧，分享摄影作品。", image: "club2.jpg", tag: "推荐" },
    { id: 3, name: "音乐社团", category: "文艺类", president: "王五", member_count: 28, status: "active", description: "分享音乐爱好，组织校园音乐节，涵盖各种音乐风格。", image: "club3.jpg", tag: "热门" },
    { id: 4, name: "篮球社团", category: "体育类", president: "赵六", member_count: 42, status: "active", description: "开展篮球训练和比赛，提高篮球技能，培养团队精神。", image: "club4.jpg", tag: "热门" },
    { id: 5, name: "科创社", category: "科技类", president: "李晨", member_count: 56, status: "active", description: "科技创新和AI技术交流，举办科技竞赛和讲座。", image: "club5.jpg", tag: "推荐" },
    { id: 6, name: "足球社", category: "体育类", president: "周明", member_count: 38, status: "active", description: "喜欢足球的同学们快来加入我们吧！开展日常训练和友谊赛。", image: "club6.jpg", tag: "热门" },
    { id: 7, name: "文学社", category: "文艺类", president: "吴芳", member_count: 25, status: "active", description: "以文会友，共享文学之美，出版校园文学刊物。", image: "club7.jpg", tag: "" },
    { id: 8, name: "舞蹈社", category: "文艺类", president: "郑舞蹈", member_count: 30, status: "active", description: "学习各种舞蹈类型，举办舞蹈表演和比赛。", image: "club8.jpg", tag: "推荐" },
    { id: 9, name: "辩论社", category: "学术类", president: "王辩", member_count: 22, status: "active", description: "提高辩论技巧，参加校际辩论比赛。", image: "club9.jpg", tag: "" },
    { id: 10, name: "动漫社", category: "兴趣类", president: "陈漫", member_count: 40, status: "active", description: "动漫爱好者的聚集地，举办动漫展和cosplay活动。", image: "club10.jpg", tag: "热门" },
    { id: 11, name: "书法社", category: "文艺类", president: "刘书", member_count: 18, status: "active", description: "传承中国书法文化，学习书法技巧。", image: "club11.jpg", tag: "" },
    { id: 12, name: "志愿者协会", category: "公益类", president: "张志愿", member_count: 60, status: "active", description: "组织各种公益活动，传递爱心和温暖。", image: "club12.jpg", tag: "推荐" }
];

const mockActivities = [
    { id: 1, title: "校园音乐节", type: "活动", club: "社团联合会", date: "2023-12-20", time: "18:00-21:00", location: "大礼堂", status: "published", description: "一年一度的校园音乐盛宴，各大社团将带来精彩表演。", image: "activity1.jpg", tag: "热门" },
    { id: 2, title: "AI技术交流会", type: "活动", club: "科创社", date: "2023-12-25", time: "14:00-17:00", location: "计算机中心", status: "planning", description: "人工智能技术分享和讨论，邀请行业专家演讲。", image: "activity2.jpg", tag: "推荐" },
    { id: 3, title: "冬季公益行", type: "活动", club: "志愿者协会", date: "2023-12-28", time: "09:00-16:00", location: "社区中心", status: "registering", description: "冬季送温暖公益活动，为困难家庭送去关爱。", image: "activity3.jpg", tag: "" },
    { id: 4, title: "编程马拉松", type: "活动", club: "计算机社团", date: "2024-01-05", time: "09:00-09:00", location: "图书馆", status: "registering", description: "24小时编程挑战，展现你的技术实力和团队协作能力。", image: "activity4.jpg", tag: "热门" },
    { id: 5, title: "校园篮球联赛", type: "活动", club: "篮球社团", date: "2024-01-10", time: "15:00-18:00", location: "篮球场", status: "published", description: "各学院篮球队之间的激烈角逐，争夺联赛冠军。", image: "activity5.jpg", tag: "热门" },
    { id: 6, title: "摄影展", type: "活动", club: "摄影社团", date: "2024-01-15", time: "10:00-18:00", location: "艺术中心", status: "planning", description: "展示校园生活的精彩瞬间，优秀作品将获得奖励。", image: "activity6.jpg", tag: "推荐" },
    { id: 7, title: "文学创作分享会", type: "活动", club: "文学社", date: "2024-01-20", time: "19:00-21:00", location: "图书馆", status: "registering", description: "与文学爱好者一起分享创作心得，提高写作水平。", image: "activity7.jpg", tag: "" },
    { id: 8, title: "足球友谊赛", type: "活动", club: "足球社", date: "2024-01-25", time: "16:00-18:00", location: "足球场", status: "published", description: "与邻校足球社的友谊交流赛，增进两校友谊。", image: "activity8.jpg", tag: "" }
];

const mockNews = [
    { id: 1, title: "社团招新季开始啦！", type: "资讯", club: "学生会", date: "2023-12-01", description: "新学期，新开始，各大社团招新活动正式启动！欢迎同学们踊跃报名。", image: "news1.jpg", tag: "热门" },
    { id: 2, title: "校园文化节圆满结束", type: "资讯", club: "学生会", date: "2023-12-10", description: "为期一周的校园文化节顺利闭幕，展现了同学们的才艺与创意。", image: "news2.jpg", tag: "" },
    { id: 3, title: "编程比赛获奖喜报", type: "资讯", club: "计算机社团", date: "2023-12-15", description: "我校计算机社团在省赛中取得优异成绩，获得团体一等奖！", image: "news3.jpg", tag: "推荐" },
    { id: 4, title: "篮球社获得校际联赛冠军", type: "资讯", club: "篮球社团", date: "2023-12-20", description: "经过激烈角逐，我校篮球社成功夺得校际联赛冠军！", image: "news4.jpg", tag: "热门" },
    { id: 5, title: "音乐社举办专场音乐会", type: "资讯", club: "音乐社团", date: "2023-12-25", description: "音乐社专场音乐会即将举行，敬请期待！将呈现各种风格的音乐表演。", image: "news5.jpg", tag: "推荐" },
    { id: 6, title: "文学社出版校园文学刊物", type: "资讯", club: "文学社", date: "2023-12-30", description: "文学社精心打造的校园文学刊物《青春华章》正式出版！", image: "news6.jpg", tag: "" },
    { id: 7, title: "科创社AI讲座预告", type: "资讯", club: "科创社", date: "2024-01-05", description: "特邀知名AI专家来校讲座，主题为'人工智能的发展与应用'。", image: "news7.jpg", tag: "推荐" },
    { id: 8, title: "志愿者协会冬季公益活动圆满完成", type: "资讯", club: "志愿者协会", date: "2024-01-10", description: "本次冬季公益活动共帮助了50个困难家庭，得到了社会好评。", image: "news8.jpg", tag: "" },
    { id: 9, title: "摄影社优秀作品选登", type: "资讯", club: "摄影社团", date: "2024-01-15", description: "精选摄影社团成员的优秀作品，展示校园生活的美好瞬间。", image: "news9.jpg", tag: "" },
    { id: 10, title: "足球社招新通知", type: "资讯", club: "足球社", date: "2024-01-20", description: "足球社春季招新开始啦！欢迎热爱足球的同学加入我们。", image: "news10.jpg", tag: "热门" }
];

// 页面加载时执行搜索
window.addEventListener('load', () => {
    // 获取URL中的搜索参数
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('q') || '';
    const searchType = urlParams.get('type') || 'all';
    
    // 设置搜索关键词显示
    const searchQueryText = document.getElementById('searchQueryText');
    if (searchQueryText) {
        searchQueryText.textContent = `"${searchQuery}"`;
    }
    
    // 设置筛选器的值
    const resultTypeFilter = document.getElementById('resultTypeFilter');
    if (resultTypeFilter) {
        resultTypeFilter.value = searchType;
    }
    
    // 执行搜索
    performSearch(searchQuery, searchType);
});

// 处理筛选器变化
function filterResults() {
    // 获取当前搜索参数
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('q') || '';
    const searchType = document.getElementById('resultTypeFilter').value;
    
    // 更新URL参数
    const url = new URL(window.location.href);
    url.searchParams.set('q', searchQuery);
    url.searchParams.set('type', searchType);
    window.history.replaceState({}, '', url);
    
    // 执行搜索
    performSearch(searchQuery, searchType);
}

// 执行搜索并显示结果
function performSearch(query, type) {
    // 合并所有数据
    const allItems = [...mockClubs, ...mockActivities, ...mockNews];
    
    // 过滤结果
    const filteredResults = allItems.filter(item => {
        // 类型过滤
        if (type !== 'all') {
            // 检查类型是否匹配（活动和资讯有type属性，社团需要检查category或直接匹配'type'为'club'）
            if (item.type) {
                if (item.type !== type) {
                    return false;
                }
            } else if (item.category) {
                // 社团类型过滤：如果筛选的是'club'类型，则所有社团都符合；否则检查具体类别
                if (type !== 'club' && item.category !== type) {
                    return false;
                }
            } else {
                // 既没有type也没有category的项目，默认不显示
                return false;
            }
        }
        
        // 关键词过滤
        if (query) {
            const searchStr = query.toLowerCase();
            return item.name?.toLowerCase().includes(searchStr) || 
                   item.title?.toLowerCase().includes(searchStr) ||
                   item.description.toLowerCase().includes(searchStr) ||
                   item.club?.toLowerCase().includes(searchStr) ||
                   item.president?.toLowerCase().includes(searchStr);
        }
        
        return true;
    });
    
    // 显示搜索结果
    displayResults(filteredResults, query, type);
}

// 显示搜索结果
function displayResults(results, query, type) {
    // 更新搜索统计信息
    const searchStats = document.getElementById('searchStats');
    searchStats.textContent = `共找到 ${results.length} 条相关结果`;
    
    // 按类型分组结果
    const clubs = results.filter(item => item.category);
    const activities = results.filter(item => item.type === '活动');
    const news = results.filter(item => item.type === '资讯');
    
    // 获取结果容器
    const clubResultsContainer = document.getElementById('clubResultsContainer');
    const activityResultsContainer = document.getElementById('activityResultsContainer');
    const newsResultsContainer = document.getElementById('newsResultsContainer');
    
    const clubResultsSection = document.getElementById('club-results');
    const activityResultsSection = document.getElementById('activity-results');
    const newsResultsSection = document.getElementById('news-results');
    
    // 显示社团结果
    if (clubResultsContainer && clubResultsSection) {
        if (clubs.length > 0) {
            clubResultsContainer.innerHTML = '';
            clubs.forEach(club => {
                clubResultsContainer.appendChild(createResultItem(club, 'club'));
            });
            clubResultsSection.style.display = 'block';
        } else {
            clubResultsSection.style.display = type === 'club' ? 'block' : 'none';
            clubResultsContainer.innerHTML = type === 'club' ? '<div class="no-results">没有找到相关社团</div>' : '';
        }
    }
    
    // 显示活动结果
    if (activityResultsContainer && activityResultsSection) {
        if (activities.length > 0) {
            activityResultsContainer.innerHTML = '';
            activities.forEach(activity => {
                activityResultsContainer.appendChild(createResultItem(activity, 'activity'));
            });
            activityResultsSection.style.display = 'block';
        } else {
            activityResultsSection.style.display = type === 'activity' ? 'block' : 'none';
            activityResultsContainer.innerHTML = type === 'activity' ? '<div class="no-results">没有找到相关活动</div>' : '';
        }
    }
    
    // 显示资讯结果
    if (newsResultsContainer && newsResultsSection) {
        if (news.length > 0) {
            newsResultsContainer.innerHTML = '';
            news.forEach(newsItem => {
                newsResultsContainer.appendChild(createResultItem(newsItem, 'news'));
            });
            newsResultsSection.style.display = 'block';
        } else {
            newsResultsSection.style.display = type === 'news' ? 'block' : 'none';
            newsResultsContainer.innerHTML = type === 'news' ? '<div class="no-results">没有找到相关资讯</div>' : '';
        }
    }
}

// 创建结果区域函数已不再需要，因为我们直接在各个容器中添加结果项

// 创建单个结果项
function createResultItem(item, type) {
    const itemElement = document.createElement('div');
    itemElement.className = 'result-item';
    
    // 图片
    const imageElement = document.createElement('div');
    imageElement.className = 'result-image';
    imageElement.style.backgroundImage = `url('images/${item.image || 'default.jpg'}')`;
    itemElement.appendChild(imageElement);
    
    // 标签
    if (item.tag) {
        const tagElement = document.createElement('div');
        tagElement.className = `result-tag ${item.tag === '热门' ? 'hot' : 'recommend'}`;
        tagElement.textContent = item.tag;
        itemElement.appendChild(tagElement);
    }
    
    // 标题
    const titleElement = document.createElement('h3');
    titleElement.className = 'result-title';
    titleElement.textContent = item.name || item.title;
    itemElement.appendChild(titleElement);
    
    // 元信息
    const metaElement = document.createElement('div');
    metaElement.className = 'result-meta';
    
    if (type === 'club') {
        metaElement.textContent = `${item.category} · ${item.club || ''}`;
    } else if (type === 'activity') {
        metaElement.textContent = `${item.club} · ${item.date} ${item.time}`;
    } else if (type === 'news') {
        metaElement.textContent = `${item.club} · ${item.date}`;
    }
    
    itemElement.appendChild(metaElement);
    
    // 描述
    const descElement = document.createElement('p');
    descElement.className = 'result-description';
    descElement.textContent = item.description;
    itemElement.appendChild(descElement);
    
    // 链接
    const linkElement = document.createElement('a');
    linkElement.className = 'result-link';
    linkElement.href = '#';
    linkElement.innerHTML = `${type === 'club' ? '查看社团' : type === 'activity' ? '查看活动' : '查看资讯'} <i class="fas fa-arrow-right"></i>`;
    itemElement.appendChild(linkElement);
    
    return itemElement;
}