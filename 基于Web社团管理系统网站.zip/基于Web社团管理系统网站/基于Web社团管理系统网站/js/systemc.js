// 学生端功能实现

// API基础URL
const API_BASE_URL = 'php/system.php';

// 当前活跃的section
let currentSection = 'overview';

// 轮播图功能实现
// 轮播图数据 - 用户可以直接在这里自定义图片地址、标题和描述
let carouselImages = [
    {
        image: "../image/iamgestyle2.jpg",
        title: "编程社团招新开始",
        description: "编程社团将于9月15日开始招新，欢迎对编程感兴趣的同学加入。"
    },
    {
        image: "../image/iamgestyle3.jpg",
        title: "编程马拉松报名通知",
        description: "编程马拉松活动开始报名，报名截止日期为9月20日。"
    },
    {
        image: "../image/indexClub4.jpg",
        title: "技术分享会通知",
        description: "本周六下午2点将举行技术分享会，主题为人工智能应用。"
    },
    {
        image: "../image/iamgestyle1.jpg",
        title: "舞蹈社秋季汇报演出",
        description: "舞蹈社将于10月15日举行秋季汇报演出，欢迎大家前来观看。"
    }
];

// 轮播图当前索引
let currentSlide = 0;

// 自动轮播计时器
let carouselTimer;

// 初始化轮播图
function initCarousel() {
    const slideContainer = document.getElementById('carouselSlide');
    const dotsContainer = document.getElementById('carouselDots');
    
    if (!slideContainer || !dotsContainer) {
        return;
    }
    
    // 清空容器
    slideContainer.innerHTML = '';
    dotsContainer.innerHTML = '';
    
    // 创建轮播项
    carouselImages.forEach((item, index) => {
        // 创建轮播项
        const slideItem = document.createElement('div');
        slideItem.className = 'carousel-item';
        
        // 添加轮播内容
        slideItem.innerHTML = `
            <img src="${item.image}" alt="${item.title}">
            <div class="carousel-content">
                <h3 class="carousel-title">${item.title}</h3>
                <p class="carousel-description">${item.description}</p>
            </div>
        `;
        
        slideContainer.appendChild(slideItem);
        
        // 创建指示点
        const dot = document.createElement('button');
        dot.className = `dot ${index === 0 ? 'active' : ''}`;
        dot.setAttribute('data-index', index);
        dot.onclick = function() {
            goToSlide(index);
        };
        
        dotsContainer.appendChild(dot);
    });
    
    // 设置初始显示
    updateSlidePosition();
    
    // 启动自动轮播
    startAutoCarousel();
}

// 更新轮播图位置
function updateSlidePosition() {
    const slideContainer = document.getElementById('carouselSlide');
    if (slideContainer) {
        slideContainer.style.transform = `translateX(-${currentSlide * 100}%)`;
    }
    
    // 更新指示点状态
    updateDots();
}

// 更新指示点状态
function updateDots() {
    const dots = document.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide);
    });
}

// 切换轮播图
function changeSlide(direction) {
    currentSlide += direction;
    
    // 边界检查
    if (currentSlide < 0) {
        currentSlide = carouselImages.length - 1;
    } else if (currentSlide >= carouselImages.length) {
        currentSlide = 0;
    }
    
    updateSlidePosition();
    
    // 重置自动轮播计时器
    resetAutoCarousel();
}

// 跳转到指定索引的轮播图
function goToSlide(index) {
    currentSlide = index;
    updateSlidePosition();
    
    // 重置自动轮播计时器
    resetAutoCarousel();
}

// 启动自动轮播
function startAutoCarousel() {
    carouselTimer = setInterval(() => {
        changeSlide(1);
    }, 3000); // 每3秒自动切换
}

// 重置自动轮播计时器
function resetAutoCarousel() {
    clearInterval(carouselTimer);
    startAutoCarousel();
}

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', function() {
    // 更新欢迎消息
    updateWelcomeMessage();
    
    // 初始化显示首页内容
    showSection('overview');
    
    // 初始化轮播图
    initCarousel();
    
    // 加载首页数据
    loadSystemAnnouncements();
    loadPopularClubs();
    loadRecentActivities();
    loadMyApplications();
    
    // 加载个人信息
    loadPersonalInfo();
    
    // 添加筛选和搜索事件监听器
    // 社团信息筛选
    document.getElementById('club-category-filter').addEventListener('change', filterClubs);
    document.getElementById('club-search').addEventListener('input', filterClubs);
    
    // 社团活动筛选
    document.getElementById('activity-club-filter').addEventListener('change', filterActivities);
    document.getElementById('activity-search').addEventListener('input', filterActivities);
    
    // 社团资讯筛选
    document.getElementById('news-club-filter').addEventListener('change', filterNews);
    document.getElementById('news-search').addEventListener('input', filterNews);
    
    // 动态加载社团筛选选项
    loadClubFilterOptions();
});

// 更新欢迎消息
function updateWelcomeMessage() {
    // 从localStorage获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    const headingTight = document.querySelector('.heading-tight');
    
    if (currentUser && headingTight) {
        const user = JSON.parse(currentUser);
        // 将"欢迎回来，管理员"替换为"欢迎回来，xxx"
        headingTight.textContent = `欢迎回来，${user.name}`;
    }
}

// 页面切换功能
function showSection(sectionName) {
    // 隐藏所有section
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.style.display = 'none';
    });
    
    // 移除所有导航项的active类
    const navItems = document.querySelectorAll('.nav-pill');
    navItems.forEach(item => {
        item.classList.remove('active');
    });
    
    // 显示目标section
    const targetSection = document.getElementById(sectionName);
    if (targetSection) {
        targetSection.style.display = 'block';
        currentSection = sectionName;
    }
    
    // 设置当前导航项为active
    const targetNav = document.querySelector(`[onclick="showSection('${sectionName}')"]`);
    if (targetNav) {
        targetNav.classList.add('active');
    }
    
    // 根据当前section加载对应数据
    switch(sectionName) {
        case 'club-info':
            loadClubInfo();
            showMockClubInfo(); // 确保显示模拟数据
            // 重置筛选条件并触发筛选
            document.getElementById('club-category-filter').value = '';
            document.getElementById('club-search').value = '';
            filterClubs();
            break;
        case 'club-activities':
            loadClubActivities();
            showMockClubActivities(); // 确保显示模拟数据
            // 加载社团筛选选项
            loadClubFilterOptions();
            // 重置筛选条件并触发筛选
            document.getElementById('activity-club-filter').value = '';
            document.getElementById('activity-search').value = '';
            filterActivities();
            break;
        case 'club-news':
            loadClubNews();
            showMockClubNews(); // 确保显示模拟数据
            // 加载社团筛选选项
            loadClubFilterOptions();
            // 重置筛选条件并触发筛选
            document.getElementById('news-club-filter').value = '';
            document.getElementById('news-search').value = '';
            filterNews();
            break;
        case 'my-applications':
            loadMyApplications();
            break;
        case 'personal-info':
            loadPersonalInfo();
            break;
    }
}

// 获取系统公告
function loadSystemAnnouncements() {
    fetch(API_BASE_URL + '?type=announcements')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const announcementList = document.getElementById('announcementList');
                announcementList.innerHTML = '';
                
                data.data.forEach(ann => {
                    const li = document.createElement('li');
                    li.className = 'announcement-item';
                    li.innerHTML = `
                        <div class="announcement-header">
                            <h4>${ann.title}</h4>
                            <span class="announcement-date">${ann.date}</span>
                        </div>
                        <p class="announcement-content">${ann.content}</p>
                    `;
                    announcementList.appendChild(li);
                });
            } else {
                console.error('获取系统公告失败:', data.message);
                // 显示模拟数据
                showMockAnnouncements();
            }
        })
        .catch(error => {
            console.error('获取系统公告出错:', error);
            // 显示模拟数据
            showMockAnnouncements();
        });
}

// 获取热门社团
function loadPopularClubs() {
    fetch(API_BASE_URL + '?type=popularClubs')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const popularClubList = document.getElementById('popularClubList');
                popularClubList.innerHTML = '';
                
                data.data.forEach(club => {
                    const li = document.createElement('li');
                    li.className = 'club-item';
                    li.innerHTML = `
                        <div class="club-info">
                            <h4>${club.name}</h4>
                            <p class="club-description">${club.description}</p>
                            <p class="club-member-count">成员数: ${club.memberCount}</p>
                        </div>
                        <div class="club-actions">
                            <button onclick="applyForClub(${club.id})" class="apply-btn">申请加入</button>
                        </div>
                    `;
                    popularClubList.appendChild(li);
                });
            } else {
                console.error('获取热门社团失败:', data.message);
                // 显示模拟数据
                showMockPopularClubs();
            }
        })
        .catch(error => {
            console.error('获取热门社团出错:', error);
            // 显示模拟数据
            showMockPopularClubs();
        });
}

// 获取近期活动
function loadRecentActivities() {
    fetch(API_BASE_URL + '?type=recentActivities')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const recentActivityList = document.getElementById('recentActivityList');
                recentActivityList.innerHTML = '';
                
                data.data.forEach(activity => {
                    const li = document.createElement('li');
                    li.className = 'activity-item';
                    li.innerHTML = `
                        <div class="activity-info">
                            <h4>${activity.title}</h4>
                            <p class="activity-club">${activity.clubName}</p>
                            <p class="activity-time">时间: ${activity.time}</p>
                            <p class="activity-location">地点: ${activity.location}</p>
                        </div>
                    `;
                    recentActivityList.appendChild(li);
                });
            } else {
                console.error('获取近期活动失败:', data.message);
                // 显示模拟数据
                showMockRecentActivities();
            }
        })
        .catch(error => {
            console.error('获取近期活动出错:', error);
            // 显示模拟数据
            showMockRecentActivities();
        });
}

// 加载社团信息列表
function loadClubInfo() {
    fetch(API_BASE_URL + '?type=clubInfo')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const clubTableBody = document.querySelector('#clubList tbody');
                clubTableBody.innerHTML = '';
                
                data.data.forEach(club => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${club.name}</td>
                        <td>${club.leader}</td>
                        <td>${club.memberCount}</td>
                        <td>${club.establishmentDate}</td>
                        <td>${club.type}</td>
                        <td>
                            <button class="btn btn-primary btn-sm">查看详情</button>
                        </td>
                    `;
                    clubTableBody.appendChild(tr);
                });
            } else {
                console.error('获取社团信息失败:', data.message);
                // 显示模拟数据
                showMockClubInfo();
            }
        })
        .catch(error => {
            console.error('获取社团信息出错:', error);
            // 显示模拟数据
            showMockClubInfo();
        });
}

// 加载社团活动列表
function loadClubActivities() {
    fetch(API_BASE_URL + '?type=clubActivities')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const activityTableBody = document.querySelector('#activityList tbody');
                activityTableBody.innerHTML = '';
                
                data.data.forEach(activity => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${activity.title}</td>
                        <td>${activity.clubName}</td>
                        <td>${activity.time}</td>
                        <td>${activity.location}</td>
                        <td>${activity.status}</td>
                        <td>
                            <button onclick="viewActivityDetails(${activity.id})" class="btn btn-primary btn-sm">查看详情</button>
                        </td>
                    `;
                    activityTableBody.appendChild(tr);
                });
            } else {
                console.error('获取社团活动失败:', data.message);
                // 显示模拟数据
                showMockClubActivities();
            }
        })
        .catch(error => {
            console.error('获取社团活动出错:', error);
            // 显示模拟数据
            showMockClubActivities();
        });
}

// 加载社团资讯列表
function loadClubNews() {
    fetch(API_BASE_URL + '?type=clubNews')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const newsTableBody = document.querySelector('#newsList tbody');
                newsTableBody.innerHTML = '';
                
                data.data.forEach(news => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${news.title}</td>
                        <td>${news.clubName}</td>
                        <td>${news.date}</td>
                        <td>
                            <button onclick="viewNewsDetails(${news.id})" class="btn btn-primary btn-sm">查看详情</button>
                        </td>
                    `;
                    newsTableBody.appendChild(tr);
                });
            } else {
                console.error('获取社团资讯失败:', data.message);
                // 显示模拟数据
                showMockClubNews();
            }
        })
        .catch(error => {
            console.error('获取社团资讯出错:', error);
            // 显示模拟数据
            showMockClubNews();
        });
}

// 加载我的申请记录
function loadMyApplications() {
    // 获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    
    fetch(API_BASE_URL + '?type=myApplications&studentId=' + user.id)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // 首页我的申请列表
                const applicationList = document.getElementById('myApplicationList');
                applicationList.innerHTML = '';
                
                data.data.forEach(app => {
                    const li = document.createElement('li');
                    li.className = 'application-item';
                    li.innerHTML = `
                        <div class="application-info">
                            <h4>${app.clubName}</h4>
                            <p>申请时间：${app.applyTime}</p>
                            <span class="status ${app.status}">${app.status === 'pending' ? '待审核' : app.status === 'approved' ? '已批准' : '已拒绝'}</span>
                        </div>
                    `;
                    applicationList.appendChild(li);
                });
                
                // 申请记录页面表格
                const applicationTableBody = document.querySelector('#applicationTable tbody');
                if (applicationTableBody) {
                    applicationTableBody.innerHTML = '';
                    data.data.forEach(app => {
                        const tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td>${app.id}</td>
                            <td>${app.clubName}</td>
                            <td>${app.applyTime}</td>
                            <td><span class="status ${app.status}">${app.status === 'pending' ? '待审核' : app.status === 'approved' ? '已批准' : '已拒绝'}</span></td>
                            <td>${app.auditTime || '-'}</td>
                            <td>${app.auditResult || '-'}</td>
                        `;
                        applicationTableBody.appendChild(tr);
                    });
                }
            } else {
                console.error('获取我的申请记录失败:', data.message);
                // 显示模拟数据
                showMockMyApplications();
            }
        })
        .catch(error => {
            console.error('获取我的申请记录出错:', error);
            // 显示模拟数据
            showMockMyApplications();
        });
}

// 显示个人信息页面
function showPersonalInfo() {
    showSection('personal-info');
    loadPersonalInfo();
}

// 加载个人信息
function loadPersonalInfo() {
    // 从localStorage获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    
    // 填充个人信息表单
    document.getElementById('student-id').value = user.student_id;
    document.getElementById('name').value = user.name;
    document.getElementById('email').value = user.email || '';
    document.getElementById('phone').value = user.phone || '';
    document.getElementById('major').value = user.major || '';
    document.getElementById('grade').value = user.grade || '';
    
    // 加载已参加活动
    loadJoinedActivities();
    
    // 加载已加入社团
    loadJoinedClubs();
    
    // 加载社团积分
    loadClubPoints();
}

// 加载已参加活动
function loadJoinedActivities() {
    // 从localStorage获取已参加活动列表
    const joinedActivitiesIds = JSON.parse(localStorage.getItem('joinedActivities') || '[]');
    const joinedActivitiesList = document.getElementById('joined-activities-list');
    
    // 清空列表
    joinedActivitiesList.innerHTML = '';
    
    if (joinedActivitiesIds.length === 0) {
        // 没有已参加的活动
        joinedActivitiesList.innerHTML = '<div class="empty-message">暂无已参加的活动</div>';
        return;
    }
    
    // 从mockActivities中获取活动详细信息
    const mockActivities = [
        { id: 1, name: '编程比赛', clubName: '编程社团', date: '2025-01-15', status: 'upcoming' },
        { id: 2, name: '社团招新', clubName: '社团联合会', date: '2025-01-20', status: 'upcoming' },
        { id: 3, name: '校园音乐节', clubName: '音乐社团', date: '2025-01-25', status: 'upcoming' },
        { id: 4, name: '科技展览', clubName: '科技社团', date: '2025-02-01', status: 'upcoming' },
        { id: 5, name: '书法比赛', clubName: '书法社团', date: '2025-02-10', status: 'upcoming' }
    ];
    
    // 过滤出已参加的活动
    const joinedActivities = mockActivities.filter(activity => joinedActivitiesIds.includes(activity.id));
    
    // 渲染已参加活动列表
    joinedActivities.forEach(activity => {
        const activityItem = document.createElement('div');
        activityItem.className = 'list-item';
        activityItem.innerHTML = `
            <div>
                <div class="item-title">${activity.name}</div>
                <div class="item-subtext">${activity.clubName} · ${activity.date}</div>
            </div>
            <span class="badge success">已参加</span>
        `;
        joinedActivitiesList.appendChild(activityItem);
    });
}

// 加载已加入社团
function loadJoinedClubs() {
    // 从localStorage获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    const joinedClubsList = document.getElementById('joined-clubs-list');
    
    // 清空列表
    joinedClubsList.innerHTML = '';
    
    // 模拟已加入的社团数据（实际应用中应该从服务器获取）
    const mockClubs = [
        { id: 1, name: '编程社团', memberCount: 120, category: '学术科技' },
        { id: 2, name: '音乐社团', memberCount: 80, category: '文化艺术' },
        { id: 3, name: '科技社团', memberCount: 95, category: '学术科技' }
    ];
    
    // 渲染已加入社团列表
    mockClubs.forEach(club => {
        const clubItem = document.createElement('div');
        clubItem.className = 'list-item';
        clubItem.innerHTML = `
            <div>
                <div class="item-title">${club.name}</div>
                <div class="item-subtext">成员数: ${club.memberCount} · ${club.category}</div>
            </div>
            <button class="btn small" onclick="viewClubDetail(${club.id})">查看</button>
        `;
        joinedClubsList.appendChild(clubItem);
    });
}

// 加载社团积分
function loadClubPoints() {
    // 从localStorage获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    const clubPointsElement = document.getElementById('club-points');
    
    // 模拟社团积分数据（实际应用中应该从服务器获取）
    // 这里简单地根据用户ID生成一个随机积分
    const basePoints = user.student_id.split('').reduce((sum, digit) => sum + parseInt(digit), 0);
    const randomPoints = Math.floor(Math.random() * 500) + 100;
    const totalPoints = basePoints + randomPoints;
    
    // 保存积分到localStorage（实际应用中应该从服务器获取）
    user.clubPoints = totalPoints;
    localStorage.setItem('currentUser', JSON.stringify(user));
    
    // 显示积分
    clubPointsElement.textContent = totalPoints;
}

// 查看社团详情
function viewClubDetail(clubId) {
    // 这里可以实现查看社团详情的功能
    // 例如跳转到社团详情页或者显示一个模态框
    alert(`查看社团ID: ${clubId}的详情`);
    // 实际应用中，你可以添加跳转到社团详情页的逻辑
    // window.location.href = `clubdetail.html?id=${clubId}`;
}

// 保存个人信息
function savePersonalInfo() {
    // 获取表单数据
    const name = document.getElementById('profileName').value;
    const email = document.getElementById('profileEmail').value;
    const phone = document.getElementById('profilePhone').value;
    const major = document.getElementById('profileMajor').value;
    const grade = document.getElementById('profileGrade').value;
    
    // 获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    
    // 更新用户信息
    fetch(API_BASE_URL + '?type=updateProfile', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            id: user.id,
            name: name,
            email: email,
            phone: phone,
            major: major,
            grade: grade
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('个人信息更新成功');
            // 更新localStorage中的用户信息
            user.name = name;
            user.email = email;
            user.phone = phone;
            user.major = major;
            user.grade = grade;
            localStorage.setItem('currentUser', JSON.stringify(user));
            // 更新欢迎消息
            updateWelcomeMessage();
        } else {
            alert('个人信息更新失败: ' + data.message);
        }
    })
    .catch(error => {
        console.error('更新个人信息出错:', error);
        alert('更新出错: ' + error.message);
    });
}

// 修改密码
function changePassword() {
    const oldPassword = document.getElementById('oldPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // 验证密码
    if (newPassword !== confirmPassword) {
        alert('两次输入的新密码不一致');
        return;
    }
    
    // 获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    
    // 发送密码修改请求
    fetch(API_BASE_URL + '?type=changePassword', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            id: user.id,
            oldPassword: oldPassword,
            newPassword: newPassword
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('密码修改成功');
            // 清空密码表单
            document.getElementById('oldPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
        } else {
            alert('密码修改失败: ' + data.message);
        }
    })
    .catch(error => {
        console.error('修改密码出错:', error);
        alert('修改出错: ' + error.message);
    });
}

// 取消编辑个人信息
function cancelEditPersonalInfo() {
    // 重新加载个人信息，恢复原始数据
    loadPersonalInfo();
}

// 取消修改密码
function cancelChangePassword() {
    // 清空密码表单
    document.getElementById('oldPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
}

// 社团申请功能
function applyForClub(clubId) {
    // 获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        alert('请先登录');
        return;
    }
    
    const user = JSON.parse(currentUser);
    
    // 发送申请请求
    fetch(API_BASE_URL + '?type=applyForClub', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            studentId: user.id,
            clubId: clubId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('申请成功，等待审核');
            // 重新加载申请列表
            loadMyApplications();
            // 如果当前在社团信息页面，重新加载社团列表
            if (currentSection === 'clubs') {
                loadClubInfo();
            }
        } else {
            alert('申请失败: ' + data.message);
        }
    })
    .catch(error => {
        console.error('申请社团出错:', error);
        alert('申请出错: ' + error.message);
    });
}

// 退出登录
function logout() {
    // 清除localStorage中的用户信息
    localStorage.removeItem('currentUser');
    // 跳转到登录页面
    window.location.href = 'indexTwo.html';
}

// 筛选功能
function filterClubs() {
    const searchTerm = document.getElementById('club-search').value.toLowerCase();
    const typeFilter = document.getElementById('club-category-filter').value;
    
    // 使用与showMockClubInfo一致的社团数据
    const mockClubs = [
        { id: 1, name: '编程社', type: '学术科技', description: '学习编程技术，参与项目开发', memberCount: 50, leader: '张三', establishmentDate: '2020-09-01' },
        { id: 2, name: '舞蹈社', type: '文化艺术', description: '学习舞蹈，参加表演', memberCount: 45, leader: '李四', establishmentDate: '2019-03-15' },
        { id: 3, name: '吉他社', type: '文化艺术', description: '学习吉他，举办音乐会', memberCount: 38, leader: '王五', establishmentDate: '2018-10-20' },
        { id: 4, name: '公益社', type: '公益类', description: '参与公益活动，帮助他人', memberCount: 62, leader: '赵六', establishmentDate: '2017-05-01' },
        { id: 5, name: '辩论社', type: '学术科技', description: '锻炼口才，参加辩论赛', memberCount: 32, leader: '孙七', establishmentDate: '2021-09-01' },
        { id: 6, name: '篮球社', type: '体育类', description: '篮球训练，参加比赛', memberCount: 58, leader: '周八', establishmentDate: '2016-09-01' },
        { id: 7, name: '羽毛球社', type: '体育类', description: '羽毛球训练，参加比赛', memberCount: 48, leader: '吴九', establishmentDate: '2019-09-01' }
    ];
    
    // 筛选数据
    const filteredClubs = mockClubs.filter(club => {
        const matchesSearch = club.name.toLowerCase().includes(searchTerm);
        const matchesType = typeFilter === '' || club.type === typeFilter;
        return matchesSearch && matchesType;
    });
    
    // 更新表格显示
    const clubTableBody = document.querySelector('#clubList tbody');
    if (clubTableBody) {
        clubTableBody.innerHTML = '';
        filteredClubs.forEach(club => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${club.name}</td>
                <td>${club.leader}</td>
                <td>${club.memberCount}</td>
                <td>${club.establishmentDate}</td>
                <td>${club.type}</td>
                <td>
                    <button class="btn btn-primary btn-sm">查看详情</button>
                </td>
            `;
            clubTableBody.appendChild(tr);
        });
    }
}

function filterActivities() {
    const searchTerm = document.getElementById('activity-search').value.toLowerCase();
    const clubFilter = document.getElementById('activity-club-filter').value;
    
    // 使用与showMockClubActivities一致的活动数据
    const mockActivities = [
        // 编程社团活动
        { id: 1, title: '编程比赛', clubName: '编程社', time: '2023-11-20T14:00:00', location: '科技楼501教室', status: 'upcoming' },
        { id: 2, title: '算法学习讲座', clubName: '编程社', time: '2023-11-10T19:00:00', location: '科技楼203教室', status: 'ongoing' },
        
        // 舞蹈社活动
        { id: 3, title: '舞蹈排练', clubName: '舞蹈社', time: '2023-11-10T16:00:00', location: '体育馆舞蹈室', status: 'ongoing' },
        { id: 4, title: '街舞展示', clubName: '舞蹈社', time: '2023-11-25T19:30:00', location: '学生活动中心', status: 'upcoming' },
        
        // 吉他社活动
        { id: 5, title: '吉他基础教学', clubName: '吉他社', time: '2023-11-12T14:00:00', location: '艺术楼302教室', status: 'upcoming' },
        { id: 6, title: '吉他演奏会', clubName: '吉他社', time: '2023-12-01T19:00:00', location: '学生活动中心', status: 'upcoming' },
        
        // 公益社活动
        { id: 7, title: '爱心义卖', clubName: '公益社', time: '2023-11-15T10:00:00', location: '食堂门口', status: 'upcoming' },
        { id: 8, title: '社区服务', clubName: '公益社', time: '2023-11-18T09:00:00', location: '阳光社区', status: 'upcoming' },
        
        // 辩论社活动
        { id: 9, title: '辩论赛', clubName: '辩论社', time: '2023-11-22T15:00:00', location: '教学楼A301教室', status: 'upcoming' },
        { id: 10, title: '辩论技巧培训', clubName: '辩论社', time: '2023-11-16T16:00:00', location: '教学楼B202教室', status: 'upcoming' },
        
        // 篮球社活动
        { id: 11, title: '篮球训练', clubName: '篮球社', time: '2023-11-11T16:00:00', location: '体育馆篮球场', status: 'ongoing' },
        { id: 12, title: '篮球比赛', clubName: '篮球社', time: '2023-11-26T14:00:00', location: '体育馆篮球场', status: 'upcoming' },
        
        // 羽毛球社活动
        { id: 13, title: '羽毛球训练', clubName: '羽毛球社', time: '2023-11-12T15:00:00', location: '体育馆羽毛球场', status: 'ongoing' },
        { id: 14, title: '羽毛球比赛', clubName: '羽毛球社', time: '2023-11-27T14:00:00', location: '体育馆羽毛球场', status: 'upcoming' }
    ];
    
    // 筛选数据
    const filteredActivities = mockActivities.filter(activity => {
        const matchesSearch = activity.title.toLowerCase().includes(searchTerm);
        const matchesClub = clubFilter === '' || activity.clubName === clubFilter;
        return matchesSearch && matchesClub;
    });
    
    // 更新表格显示
    const activityTableBody = document.querySelector('#activityList tbody');
    if (activityTableBody) {
        activityTableBody.innerHTML = '';
        filteredActivities.forEach(activity => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${activity.title}</td>
                <td>${activity.clubName}</td>
                <td>${activity.time}</td>
                <td>${activity.location}</td>
                <td>${activity.status}</td>
                <td>
                    <button onclick="viewActivityDetails(${activity.id})" class="btn btn-primary btn-sm">查看详情</button>
                </td>
            `;
            activityTableBody.appendChild(tr);
        });
    }
}

function filterNews() {
    const searchTerm = document.getElementById('news-search').value.toLowerCase();
    const clubFilter = document.getElementById('news-club-filter').value;
    
    // 使用与showMockClubNews一致的资讯数据
    const mockNews = [
        { id: 1, title: '编程社团招新开始', clubName: '编程社', date: '2024-09-01', content: '编程社团将于9月15日开始招新，欢迎对编程感兴趣的同学加入。', status: 'active' },
        { id: 2, title: '编程马拉松报名通知', clubName: '编程社', date: '2024-09-10', content: '编程马拉松活动开始报名，报名截止日期为9月20日。', status: 'active' },
        { id: 3, title: '技术分享会通知', clubName: '编程社', date: '2024-09-15', content: '本周六下午2点将举行技术分享会，主题为人工智能应用。', status: 'active' },
        { id: 4, title: '舞蹈社秋季汇报演出', clubName: '舞蹈社', date: '2024-09-20', content: '舞蹈社将于10月15日举行秋季汇报演出，欢迎大家前来观看。', status: 'active' },
        { id: 5, title: '吉他社新人培训计划', clubName: '吉他社', date: '2024-09-25', content: '吉他社将在10月份开展新人培训计划，帮助新成员快速上手。', status: 'active' },
        { id: 6, title: '篮球社校内友谊赛', clubName: '篮球社', date: '2024-10-01', content: '篮球社将于10月10日举行校内友谊赛，欢迎篮球爱好者前来报名。', status: 'active' },
        { id: 7, title: '羽毛球社周末活动安排', clubName: '羽毛球社', date: '2024-10-05', content: '羽毛球社每周六下午2点至4点在体育馆开展活动，欢迎社员参加。', status: 'active' },
        { id: 8, title: '公益社爱心义卖活动', clubName: '公益社', date: '2024-10-10', content: '公益社将于10月20日举行爱心义卖活动，所得款项将用于帮助贫困地区儿童。', status: 'active' }
    ];
    
    // 筛选数据
    const filteredNews = mockNews.filter(news => {
        const matchesSearch = news.title.toLowerCase().includes(searchTerm);
        const matchesClub = clubFilter === '' || news.clubName === clubFilter;
        return matchesSearch && matchesClub;
    });
    
    // 更新表格显示
    const newsTableBody = document.querySelector('#newsList tbody');
    if (newsTableBody) {
        newsTableBody.innerHTML = '';
        filteredNews.forEach(news => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${news.title}</td>
                <td>${news.clubName}</td>
                <td>${news.date}</td>
                <td>
                    <button onclick="viewNewsDetails(${news.id})" class="btn btn-primary btn-sm">查看详情</button>
                </td>
            `;
            newsTableBody.appendChild(tr);
        });
    }
}

// 动态加载社团筛选选项
function loadClubFilterOptions() {
    // 使用与showMockClubInfo一致的社团数据
    const mockClubs = [
        { id: 1, name: '编程社', type: '学术科技' },
        { id: 2, name: '舞蹈社', type: '文化艺术' },
        { id: 3, name: '吉他社', type: '文化艺术' },
        { id: 4, name: '公益社', type: '公益类' },
        { id: 5, name: '辩论社', type: '学术科技' },
        { id: 6, name: '篮球社', type: '体育类' },
        { id: 7, name: '羽毛球社', type: '体育类' }
    ];
    
    // 获取活动和资讯的社团筛选下拉框
    const activityClubFilter = document.getElementById('activity-club-filter');
    const newsClubFilter = document.getElementById('news-club-filter');
    
    // 为活动筛选下拉框添加社团选项
    if (activityClubFilter) {
        // 清空现有选项（保留第一个"所有社团"选项）
        const allOption = activityClubFilter.children[0];
        activityClubFilter.innerHTML = '';
        activityClubFilter.appendChild(allOption);
        
        // 添加社团选项
        mockClubs.forEach(club => {
            const option = document.createElement('option');
            option.value = club.name;
            option.textContent = club.name;
            activityClubFilter.appendChild(option);
        });
    }
    
    // 为资讯筛选下拉框添加社团选项
    if (newsClubFilter) {
        // 清空现有选项（保留第一个"所有社团"选项）
        const allOption = newsClubFilter.children[0];
        newsClubFilter.innerHTML = '';
        newsClubFilter.appendChild(allOption);
        
        // 添加社团选项
        mockClubs.forEach(club => {
            const option = document.createElement('option');
            option.value = club.name;
            option.textContent = club.name;
            newsClubFilter.appendChild(option);
        });
    }
}

// 显示模拟数据（用于测试）
function showMockAnnouncements() {
    const announcementList = document.getElementById('announcementList');
    announcementList.innerHTML = '';
    
    const mockAnnouncements = [
        { id: 1, title: '社团招新开始', content: '新学期社团招新活动将于9月15日正式开始，欢迎广大同学积极参与！', date: '2024-09-01' },
        { id: 2, title: '活动报名提醒', content: '编程社团编程竞赛活动报名截止日期为9月20日，请同学们尽快报名。', date: '2024-09-10' }
    ];
    
    mockAnnouncements.forEach(ann => {
        const li = document.createElement('li');
        li.className = 'announcement-item';
        li.innerHTML = `
            <div class="announcement-header">
                <h4>${ann.title}</h4>
                <span class="announcement-date">${ann.date}</span>
            </div>
            <p class="announcement-content">${ann.content}</p>
        `;
        announcementList.appendChild(li);
    });
}

function showMockPopularClubs() {
    const popularClubList = document.getElementById('popularClubList');
    popularClubList.innerHTML = '';
    
    // 使用与systemb.js一致的社团数据
    const mockClubs = [
        { id: 1, name: '编程社', description: '学习编程技术，参与项目开发', memberCount: 50, president: '张三', founded: '2020-09-01' },
        { id: 2, name: '舞蹈社', description: '学习舞蹈，参加表演', memberCount: 45, president: '李四', founded: '2019-03-15' },
        { id: 3, name: '吉他社', description: '学习吉他，举办音乐会', memberCount: 38, president: '王五', founded: '2018-10-20' },
        { id: 4, name: '公益社', description: '参与公益活动，帮助他人', memberCount: 62, president: '赵六', founded: '2017-05-01' },
        { id: 5, name: '辩论社', description: '锻炼口才，参加辩论赛', memberCount: 32, president: '孙七', founded: '2021-09-01' },
        { id: 6, name: '篮球社', description: '篮球训练，参加比赛', memberCount: 58, president: '周八', founded: '2016-09-01' },
        { id: 7, name: '羽毛球社', description: '羽毛球训练，参加比赛', memberCount: 48, president: '吴九', founded: '2019-09-01' }
    ];
    
    mockClubs.forEach(club => {
        const li = document.createElement('li');
        li.className = 'club-item';
        li.innerHTML = `
            <div class="club-info">
                <h4>${club.name}</h4>
                <p class="club-description">${club.description}</p>
                <p class="club-member-count">成员数: ${club.memberCount}</p>
            </div>
            <div class="club-actions">
                <button onclick="applyForClub(${club.id})" class="apply-btn">申请加入</button>
            </div>
        `;
        popularClubList.appendChild(li);
    });
}

function showMockRecentActivities() {
    const recentActivityList = document.getElementById('recentActivityList');
    recentActivityList.innerHTML = '';
    
    // 使用与systemb.js一致的活动数据
    const mockActivities = [
        // 编程社团活动
        { id: 1, name: '编程比赛', clubName: '编程社', time: '2023-11-20T14:00:00', location: '科技楼501教室', status: 'upcoming' },
        { id: 2, name: '算法学习讲座', clubName: '编程社', time: '2023-11-10T19:00:00', location: '科技楼203教室', status: 'ongoing' },
        
        // 舞蹈社活动
        { id: 3, name: '舞蹈排练', clubName: '舞蹈社', time: '2023-11-10T16:00:00', location: '体育馆舞蹈室', status: 'ongoing' },
        { id: 4, name: '街舞展示', clubName: '舞蹈社', time: '2023-11-25T19:30:00', location: '学生活动中心', status: 'upcoming' },
        
        // 吉他社活动
        { id: 5, name: '吉他基础教学', clubName: '吉他社', time: '2023-11-12T14:00:00', location: '艺术楼302教室', status: 'upcoming' },
        { id: 6, name: '吉他演奏会', clubName: '吉他社', time: '2023-12-01T19:00:00', location: '学生活动中心', status: 'upcoming' },
        
        // 公益社活动
        { id: 7, name: '爱心义卖', clubName: '公益社', time: '2023-11-15T10:00:00', location: '食堂门口', status: 'upcoming' },
        { id: 8, name: '社区服务', clubName: '公益社', time: '2023-11-18T09:00:00', location: '阳光社区', status: 'upcoming' },
        
        // 辩论社活动
        { id: 9, name: '辩论赛', clubName: '辩论社', time: '2023-11-22T15:00:00', location: '教学楼A301教室', status: 'upcoming' },
        { id: 10, name: '辩论技巧培训', clubName: '辩论社', time: '2023-11-16T16:00:00', location: '教学楼B202教室', status: 'upcoming' },
        
        // 篮球社活动
        { id: 11, name: '篮球训练', clubName: '篮球社', time: '2023-11-11T16:00:00', location: '体育馆篮球场', status: 'ongoing' },
        { id: 12, name: '篮球比赛', clubName: '篮球社', time: '2023-11-26T14:00:00', location: '体育馆篮球场', status: 'upcoming' },
        
        // 羽毛球社活动
        { id: 13, name: '羽毛球训练', clubName: '羽毛球社', time: '2023-11-12T15:00:00', location: '体育馆羽毛球场', status: 'ongoing' },
        { id: 14, name: '羽毛球比赛', clubName: '羽毛球社', time: '2023-11-27T14:00:00', location: '体育馆羽毛球场', status: 'upcoming' }
    ];
    
    mockActivities.forEach(activity => {
        const li = document.createElement('li');
        li.className = 'activity-item';
        li.innerHTML = `
            <div class="activity-info">
                <h4>${activity.name}</h4>
                <p class="activity-club">${activity.clubName}</p>
                <p class="activity-time">时间: ${activity.time}</p>
                <p class="activity-location">地点: ${activity.location}</p>
            </div>
        `;
        recentActivityList.appendChild(li);
    });
}

function showMockMyApplications() {
    // 首页我的申请列表
    const applicationList = document.getElementById('myApplicationList');
    applicationList.innerHTML = '';
    
    const mockApplications = [
        { id: 1, clubName: '编程社团', applyTime: '2024-09-12 10:30', status: 'pending' },
        { id: 2, clubName: '摄影社团', applyTime: '2024-09-10 15:20', status: 'approved' }
    ];
    
    mockApplications.forEach(app => {
        const li = document.createElement('li');
        li.className = 'application-item';
        li.innerHTML = `
            <div class="application-info">
                <h4>${app.clubName}</h4>
                <p>申请时间：${app.applyTime}</p>
                <span class="status ${app.status}">${app.status === 'pending' ? '待审核' : app.status === 'approved' ? '已批准' : '已拒绝'}</span>
            </div>
        `;
        applicationList.appendChild(li);
    });
    
    // 申请记录页面表格
    const applicationTableBody = document.querySelector('#applicationTable tbody');
    if (applicationTableBody) {
        applicationTableBody.innerHTML = '';
        mockApplications.forEach(app => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${app.id}</td>
                <td>${app.clubName}</td>
                <td>${app.applyTime}</td>
                <td><span class="status ${app.status}">${app.status === 'pending' ? '待审核' : app.status === 'approved' ? '已批准' : '已拒绝'}</span></td>
                <td>${app.status === 'approved' ? '2024-09-11 14:30' : '-'}</td>
                <td>${app.status === 'approved' ? '审核通过' : '-'}</td>
            `;
            applicationTableBody.appendChild(tr);
        });
    }
}

function showMockClubInfo() {
    // 获取两个表格：社团信息页面的#clubList和另一个#clubTable
    const clubTableBody1 = document.querySelector('#clubList tbody');
    const clubTableBody2 = document.querySelector('#clubTable tbody');
    
    // 使用与systemb.js一致的社团数据，并补充负责人和成立时间字段
    const mockClubs = [
        { id: 1, name: '编程社', type: '学术科技', description: '学习编程技术，参与项目开发', memberCount: 50, leader: '张三', establishmentDate: '2020-09-01' },
        { id: 2, name: '舞蹈社', type: '文化艺术', description: '学习舞蹈，参加表演', memberCount: 45, leader: '李四', establishmentDate: '2019-03-15' },
        { id: 3, name: '吉他社', type: '文化艺术', description: '学习吉他，举办音乐会', memberCount: 38, leader: '王五', establishmentDate: '2018-10-20' },
        { id: 4, name: '公益社', type: '公益类', description: '参与公益活动，帮助他人', memberCount: 62, leader: '赵六', establishmentDate: '2017-05-01' },
        { id: 5, name: '辩论社', type: '学术科技', description: '锻炼口才，参加辩论赛', memberCount: 32, leader: '孙七', establishmentDate: '2021-09-01' },
        { id: 6, name: '篮球社', type: '体育类', description: '篮球训练，参加比赛', memberCount: 58, leader: '周八', establishmentDate: '2016-09-01' },
        { id: 7, name: '羽毛球社', type: '体育类', description: '羽毛球训练，参加比赛', memberCount: 48, leader: '吴九', establishmentDate: '2019-09-01' }
    ];
    
    // 填充第一个表格 #clubList (社团信息页面)
    if (clubTableBody1) {
        clubTableBody1.innerHTML = '';
        mockClubs.forEach(club => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${club.name}</td>
                <td>${club.leader}</td>
                <td>${club.memberCount}</td>
                <td>${club.establishmentDate}</td>
                <td>${club.type}</td>
                <td>
                    <button class="btn btn-primary btn-sm">查看详情</button>
                </td>
            `;
            clubTableBody1.appendChild(tr);
        });
    }
    
    // 填充第二个表格 #clubTable
    if (clubTableBody2) {
        clubTableBody2.innerHTML = '';
        mockClubs.forEach(club => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${club.id}</td>
                <td>${club.name}</td>
                <td>${club.type}</td>
                <td>${club.description}</td>
                <td>${club.memberCount}</td>
                <td>active</td>
                <td>
                    <button onclick="applyForClub(${club.id})" class="apply-btn">申请加入</button>
                </td>
            `;
            clubTableBody2.appendChild(tr);
        });
    }
}

function showMockClubActivities() {
    // 获取两个表格：社团活动页面的#activityList和另一个#activityTable
    const activityTableBody1 = document.querySelector('#activityList tbody');
    const activityTableBody2 = document.querySelector('#activityTable tbody');
    
    // 使用与systemb.js一致的活动数据
    const mockActivities = [
        // 编程社团活动
        { id: 1, title: '编程比赛', clubName: '编程社', time: '2023-11-20T14:00:00', location: '科技楼501教室', status: 'upcoming' },
        { id: 2, title: '算法学习讲座', clubName: '编程社', time: '2023-11-10T19:00:00', location: '科技楼203教室', status: 'ongoing' },
        
        // 舞蹈社活动
        { id: 3, title: '舞蹈排练', clubName: '舞蹈社', time: '2023-11-10T16:00:00', location: '体育馆舞蹈室', status: 'ongoing' },
        { id: 4, title: '街舞展示', clubName: '舞蹈社', time: '2023-11-25T19:30:00', location: '学生活动中心', status: 'upcoming' },
        
        // 吉他社活动
        { id: 5, title: '吉他基础教学', clubName: '吉他社', time: '2023-11-12T14:00:00', location: '艺术楼302教室', status: 'upcoming' },
        { id: 6, title: '吉他演奏会', clubName: '吉他社', time: '2023-12-01T19:00:00', location: '学生活动中心', status: 'upcoming' },
        
        // 公益社活动
        { id: 7, title: '爱心义卖', clubName: '公益社', time: '2023-11-15T10:00:00', location: '食堂门口', status: 'upcoming' },
        { id: 8, title: '社区服务', clubName: '公益社', time: '2023-11-18T09:00:00', location: '阳光社区', status: 'upcoming' },
        
        // 辩论社活动
        { id: 9, title: '辩论赛', clubName: '辩论社', time: '2023-11-22T15:00:00', location: '教学楼A301教室', status: 'upcoming' },
        { id: 10, title: '辩论技巧培训', clubName: '辩论社', time: '2023-11-16T16:00:00', location: '教学楼B202教室', status: 'upcoming' },
        
        // 篮球社活动
        { id: 11, title: '篮球训练', clubName: '篮球社', time: '2023-11-11T16:00:00', location: '体育馆篮球场', status: 'ongoing' },
        { id: 12, title: '篮球比赛', clubName: '篮球社', time: '2023-11-26T14:00:00', location: '体育馆篮球场', status: 'upcoming' },
        
        // 羽毛球社活动
        { id: 13, title: '羽毛球训练', clubName: '羽毛球社', time: '2023-11-12T15:00:00', location: '体育馆羽毛球场', status: 'ongoing' },
        { id: 14, title: '羽毛球比赛', clubName: '羽毛球社', time: '2023-11-27T14:00:00', location: '体育馆羽毛球场', status: 'upcoming' }
    ];
    
    // 填充第一个表格 #activityList (社团活动页面)
    if (activityTableBody1) {
        activityTableBody1.innerHTML = '';
        mockActivities.forEach(activity => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${activity.title}</td>
                <td>${activity.clubName}</td>
                <td>${activity.time}</td>
                <td>${activity.location}</td>
                <td>${activity.status}</td>
                <td>
                    <button onclick="viewActivityDetails(${activity.id})" class="btn btn-primary btn-sm">查看详情</button>
                </td>
            `;
            activityTableBody1.appendChild(tr);
        });
    }
    
    // 填充第二个表格 #activityTable
    if (activityTableBody2) {
        activityTableBody2.innerHTML = '';
        mockActivities.forEach(activity => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${activity.id}</td>
                <td>${activity.name}</td>
                <td>${activity.clubName}</td>
                <td>${activity.time}</td>
                <td>${activity.location}</td>
                <td>${activity.status}</td>
            `;
            activityTableBody2.appendChild(tr);
        });
    }
}

function showMockClubNews() {
    // 获取两个表格：社团资讯页面的#newsList和另一个#newsTable
    const newsTableBody1 = document.querySelector('#newsList tbody');
    const newsTableBody2 = document.querySelector('#newsTable tbody');
    
    // 使用与systemb.js一致的资讯数据
    const mockNews = [
        { id: 1, title: '编程社团招新开始', clubName: '编程社', date: '2024-09-01', content: '编程社团将于9月15日开始招新，欢迎对编程感兴趣的同学加入。', status: 'active' },
        { id: 2, title: '编程马拉松报名通知', clubName: '编程社', date: '2024-09-10', content: '编程马拉松活动开始报名，报名截止日期为9月20日。', status: 'active' },
        { id: 3, title: '技术分享会通知', clubName: '编程社', date: '2024-09-15', content: '本周六下午2点将举行技术分享会，主题为人工智能应用。', status: 'active' },
        { id: 4, title: '舞蹈社秋季汇报演出', clubName: '舞蹈社', date: '2024-09-20', content: '舞蹈社将于10月15日举行秋季汇报演出，欢迎大家前来观看。', status: 'active' },
        { id: 5, title: '吉他社新人培训计划', clubName: '吉他社', date: '2024-09-25', content: '吉他社将在10月份开展新人培训计划，帮助新成员快速上手。', status: 'active' },
        { id: 6, title: '篮球社校内友谊赛', clubName: '篮球社', date: '2024-10-01', content: '篮球社将于10月10日举行校内友谊赛，欢迎篮球爱好者前来报名。', status: 'active' },
        { id: 7, title: '羽毛球社周末活动安排', clubName: '羽毛球社', date: '2024-10-05', content: '羽毛球社每周六下午2点至4点在体育馆开展活动，欢迎社员参加。', status: 'active' },
        { id: 8, title: '公益社爱心义卖活动', clubName: '公益社', date: '2024-10-10', content: '公益社将于10月20日举行爱心义卖活动，所得款项将用于帮助贫困地区儿童。', status: 'active' }
    ];
    
    // 填充第一个表格 #newsList (社团资讯页面)
    if (newsTableBody1) {
        newsTableBody1.innerHTML = '';
        mockNews.forEach(news => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${news.title}</td>
                <td>${news.clubName}</td>
                <td>${news.date}</td>
                <td>
                    <button onclick="viewNewsDetails(${news.id})" class="btn btn-primary btn-sm">查看详情</button>
                </td>
            `;
            newsTableBody1.appendChild(tr);
        });
    }
    
    // 填充第二个表格 #newsTable
    if (newsTableBody2) {
        newsTableBody2.innerHTML = '';
        mockNews.forEach(news => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${news.id}</td>
                <td>${news.title}</td>
                <td>${news.club_name}</td>
                <td>${news.date}</td>
                <td>${news.content}</td>
            `;
            newsTableBody2.appendChild(tr);
        });
    }
}

// 查看活动详情
function viewActivityDetails(activityId) {
    // 使用与systemb.js一致的活动数据，添加了参与人数、人数上限和性别比例字段
    const mockActivities = [
        // 编程社团活动
        { id: 1, name: '编程比赛', clubName: '编程社', time: '2023-11-20T14:00:00', location: '科技楼501教室', status: 'upcoming', content: '举办编程技能比赛，增强学生编程能力', participants: 15, maxParticipants: 50, genderRatio: { male: 12, female: 3 } },
        { id: 2, name: '算法学习讲座', clubName: '编程社', time: '2023-11-10T19:00:00', location: '科技楼203教室', status: 'ongoing', content: '邀请算法竞赛获奖选手分享算法学习经验', participants: 30, maxParticipants: 80, genderRatio: { male: 22, female: 8 } },
        
        // 舞蹈社活动
        { id: 3, name: '舞蹈排练', clubName: '舞蹈社', time: '2023-11-10T16:00:00', location: '体育馆舞蹈室', status: 'ongoing', content: '每周舞蹈排练，为年底晚会做准备', participants: 20, maxParticipants: 40, genderRatio: { male: 5, female: 15 } },
        { id: 4, name: '街舞展示', clubName: '舞蹈社', time: '2023-11-25T19:30:00', location: '学生活动中心', status: 'upcoming', content: '展示街舞成果，邀请全校学生观看', participants: 0, maxParticipants: 200, genderRatio: { male: 0, female: 0 } },
        
        // 吉他社活动
        { id: 5, name: '吉他基础教学', clubName: '吉他社', time: '2023-11-12T14:00:00', location: '艺术楼302教室', status: 'upcoming', content: '吉他基础教学，适合零基础同学', participants: 8, maxParticipants: 30, genderRatio: { male: 6, female: 2 } },
        { id: 6, name: '吉他演奏会', clubName: '吉他社', time: '2023-12-01T19:00:00', location: '学生活动中心', status: 'upcoming', content: '吉他社成员演奏会，展示学习成果', participants: 0, maxParticipants: 150, genderRatio: { male: 0, female: 0 } },
        
        // 公益社活动
        { id: 7, name: '爱心义卖', clubName: '公益社', time: '2023-11-15T10:00:00', location: '食堂门口', status: 'upcoming', content: '爱心义卖活动，所得款项用于帮助贫困学生', participants: 25, maxParticipants: 60, genderRatio: { male: 10, female: 15 } },
        { id: 8, name: '社区服务', clubName: '公益社', time: '2023-11-18T09:00:00', location: '阳光社区', status: 'upcoming', content: '社区服务活动，帮助老人打扫卫生', participants: 18, maxParticipants: 50, genderRatio: { male: 7, female: 11 } },
        
        // 辩论社活动
        { id: 9, name: '辩论赛', clubName: '辩论社', time: '2023-11-22T15:00:00', location: '教学楼A301教室', status: 'upcoming', content: '辩论赛，主题：人工智能的利与弊', participants: 12, maxParticipants: 40, genderRatio: { male: 7, female: 5 } },
        { id: 10, name: '辩论技巧培训', clubName: '辩论社', time: '2023-11-16T16:00:00', location: '教学楼B202教室', status: 'upcoming', content: '辩论技巧培训，提高辩论能力', participants: 9, maxParticipants: 35, genderRatio: { male: 5, female: 4 } },
        
        // 篮球社活动
        { id: 11, name: '篮球训练', clubName: '篮球社', time: '2023-11-11T16:00:00', location: '体育馆篮球场', status: 'ongoing', content: '每周篮球训练，提高篮球技术', participants: 22, maxParticipants: 40, genderRatio: { male: 20, female: 2 } },
        { id: 12, name: '篮球比赛', clubName: '篮球社', time: '2023-11-26T14:00:00', location: '体育馆篮球场', status: 'upcoming', content: '篮球比赛，各院系之间的友谊赛', participants: 30, maxParticipants: 100, genderRatio: { male: 28, female: 2 } },
        
        // 羽毛球社活动
        { id: 13, name: '羽毛球训练', clubName: '羽毛球社', time: '2023-11-12T15:00:00', location: '体育馆羽毛球场', status: 'ongoing', content: '每周羽毛球训练，提高羽毛球技术', participants: 18, maxParticipants: 30, genderRatio: { male: 10, female: 8 } },
        { id: 14, name: '羽毛球比赛', clubName: '羽毛球社', time: '2023-11-27T14:00:00', location: '体育馆羽毛球场', status: 'upcoming', content: '羽毛球比赛，各院系之间的友谊赛', participants: 24, maxParticipants: 80, genderRatio: { male: 15, female: 9 } }
    ];
    
    const activity = mockActivities.find(a => a.id === activityId);
    if (activity) {
        // 将活动数据存储到localStorage
        localStorage.setItem('currentActivity', JSON.stringify(activity));
        // 跳转到活动详情页
        window.location.href = 'active.html';
    } else {
        alert('未找到该活动');
    }
}

// 查看资讯详情
function viewNewsDetails(newsId) {
    // 使用与systemb.js一致的资讯数据
    const mockNews = [
        { id: 1, title: '编程社团招新开始', club_name: '编程社', date: '2024-09-01', content: '编程社团将于9月15日开始招新，欢迎对编程感兴趣的同学加入。', status: 'active' },
        { id: 2, title: '编程马拉松报名通知', club_name: '编程社', date: '2024-09-10', content: '编程马拉松活动开始报名，报名截止日期为9月20日。', status: 'active' },
        { id: 3, title: '技术分享会通知', club_name: '编程社', date: '2024-09-15', content: '本周六下午2点将举行技术分享会，主题为人工智能应用。', status: 'active' },
        { id: 4, title: '舞蹈社秋季汇报演出', club_name: '舞蹈社', date: '2024-09-20', content: '舞蹈社将于10月15日举行秋季汇报演出，欢迎大家前来观看。', status: 'active' },
        { id: 5, title: '吉他社新人培训计划', club_name: '吉他社', date: '2024-09-25', content: '吉他社将在10月份开展新人培训计划，帮助新成员快速上手。', status: 'active' },
        { id: 6, title: '篮球社校内友谊赛', club_name: '篮球社', date: '2024-10-01', content: '篮球社将于10月10日举行校内友谊赛，欢迎篮球爱好者前来报名。', status: 'active' },
        { id: 7, title: '羽毛球社周末活动安排', club_name: '羽毛球社', date: '2024-10-05', content: '羽毛球社每周六下午2点至4点在体育馆开展活动，欢迎社员参加。', status: 'active' },
        { id: 8, title: '公益社爱心义卖活动', club_name: '公益社', date: '2024-10-10', content: '公益社将于10月20日举行爱心义卖活动，所得款项将用于帮助贫困地区儿童。', status: 'active' }
    ];
    
    const news = mockNews.find(n => n.id === newsId);
    if (news) {
        alert(`资讯详情：\n标题：${news.title}\n社团：${news.club_name}\n日期：${news.date}\n内容：${news.content}`);
    } else {
        alert('未找到该资讯');
    }
}

// 首页搜索功能
function searchHomePage() {
    const query = document.getElementById('home-search').value;
    if (query.trim() !== '') {
        window.location.href = `information.html?q=${encodeURIComponent(query)}&type=all`;
    }
}
