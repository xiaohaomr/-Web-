// 社团管理者系统功能实现

// API基础URL
const API_BASE_URL = 'php/system.php';

// 当前活跃的section
let currentSection = 'overview';

// 全局模拟数据数组
let mockMembers = [
    { id: 1, name: '张三', student_id: '2021001', major: '计算机科学', club_id: 1, club_name: '编程社', join_date: '2021-09-10', role: '会员', status: 'active' },
    { id: 2, name: '李四', student_id: '2022005', major: '软件工程', club_id: 1, club_name: '编程社', join_date: '2022-09-15', role: '会员', status: 'active' },
    { id: 3, name: '王五', student_id: '2023012', major: '信息安全', club_id: 1, club_name: '编程社', join_date: '2023-09-20', role: '会员', status: 'active' },
    { id: 4, name: '赵六', student_id: '2021010', major: '计算机科学', club_id: 2, club_name: '舞蹈社', join_date: '2021-10-05', role: '会员', status: 'active' },
    { id: 5, name: '孙七', student_id: '2022025', major: '软件工程', club_id: 3, club_name: '吉他社', join_date: '2022-11-12', role: '会员', status: 'active' },
    { id: 6, name: '周八', student_id: '2023030', major: '信息安全', club_id: 4, club_name: '公益社', join_date: '2023-10-08', role: '会员', status: 'active' },
    { id: 7, name: '吴九', student_id: '2021045', major: '计算机科学', club_id: 5, club_name: '辩论社', join_date: '2021-09-25', role: '会员', status: 'active' },
    { id: 8, name: '郑十', student_id: '2022050', major: '软件工程', club_id: 6, club_name: '篮球社', join_date: '2022-10-15', role: '会员', status: 'active' },
    { id: 9, name: '王二', student_id: '2023060', major: '信息安全', club_id: 7, club_name: '羽毛球社', join_date: '2023-11-01', role: '会员', status: 'active' },
    { id: 10, name: '陈一', student_id: '2021075', major: '计算机科学', club_id: 2, club_name: '舞蹈社', join_date: '2021-12-05', role: '会员', status: 'active' }
];

// 全局模拟新闻数据数组
let mockNews = [
    { id: 1, title: '编程社团招新开始', club_name: '编程社', date: '2024-09-01', content: '编程社团将于9月15日开始招新，欢迎对编程感兴趣的同学加入。', status: 'active' },
    { id: 2, title: '编程马拉松报名通知', club_name: '编程社', date: '2024-09-10', content: '编程马拉松活动开始报名，报名截止日期为9月20日。', status: 'active' },
    { id: 3, title: '技术分享会通知', club_name: '编程社', date: '2024-09-15', content: '本周六下午2点将举行技术分享会，主题为人工智能应用。', status: 'active' },
    { id: 4, title: '舞蹈社秋季汇报演出', club_name: '舞蹈社', date: '2024-09-20', content: '舞蹈社将于10月15日举行秋季汇报演出，欢迎大家前来观看。', status: 'active' },
    { id: 5, title: '吉他社新人培训计划', club_name: '吉他社', date: '2024-09-25', content: '吉他社将在10月份开展新人培训计划，帮助新成员快速上手。', status: 'active' },
    { id: 6, title: '篮球社校内友谊赛', club_name: '篮球社', date: '2024-10-01', content: '篮球社将于10月10日举行校内友谊赛，欢迎篮球爱好者前来报名。', status: 'active' },
    { id: 7, title: '羽毛球社周末活动安排', club_name: '羽毛球社', date: '2024-10-05', content: '羽毛球社每周六下午2点至4点在体育馆开展活动，欢迎社员参加。', status: 'active' },
    { id: 8, title: '公益社爱心义卖活动', club_name: '公益社', date: '2024-10-10', content: '公益社将于10月20日举行爱心义卖活动，所得款项将用于帮助贫困地区儿童。', status: 'active' }
];

// 全局模拟评论数据数组
let mockComments = [
    { id: 1, content: '活动很有趣，学到了很多东西！', author_name: '小明', comment_time: '2024-09-16 14:30', target_type: 'activity', target_title: '新生见面会', status: 'active' },
    { id: 2, content: '期待下一次活动！', author_name: '小红', comment_time: '2024-09-16 15:20', target_type: 'activity', target_title: '新生见面会', status: 'active' },
    { id: 3, content: '招新信息很详细，谢谢！', author_name: '小刚', comment_time: '2024-09-02 10:15', target_type: 'news', target_title: '编程社团招新开始', status: 'active' },
    { id: 4, content: '舞蹈演出很精彩，演员们辛苦了！', author_name: '小丽', comment_time: '2024-10-16 19:30', target_type: 'activity', target_title: '舞蹈社秋季汇报演出', status: 'active' },
    { id: 5, content: '吉他培训很实用，老师很专业！', author_name: '小强', comment_time: '2024-10-05 16:20', target_type: 'news', target_title: '吉他社新人培训计划', status: 'active' },
    { id: 6, content: '篮球比赛很激烈，希望能有更多这样的活动！', author_name: '小王', comment_time: '2024-10-11 14:45', target_type: 'activity', target_title: '篮球社校内友谊赛', status: 'active' },
    { id: 7, content: '公益活动很有意义，我也想参加！', author_name: '小张', comment_time: '2024-10-15 09:20', target_type: 'news', target_title: '公益社爱心义卖活动', status: 'active' },
    { id: 8, content: '羽毛球活动安排得很好，希望能一直持续！', author_name: '小李', comment_time: '2024-10-06 18:30', target_type: 'news', target_title: '羽毛球社周末活动安排', status: 'active' },
    { id: 9, content: '技术分享会的内容很前沿，收获颇丰！', author_name: '小刘', comment_time: '2024-09-17 10:15', target_type: 'activity', target_title: '技术分享会', status: 'active' },
    { id: 10, content: '报名参加了编程马拉松，希望能取得好成绩！', author_name: '小陈', comment_time: '2024-09-18 16:40', target_type: 'news', target_title: '编程马拉松报名通知', status: 'active' }
];

// 页面加载完成后初始化
// 加载社团选项到所有筛选下拉框
function loadClubOptions() {
    // 定义社团列表
    const clubs = [
        { id: 1, name: '编程社' },
        { id: 2, name: '舞蹈社' },
        { id: 3, name: '吉他社' },
        { id: 4, name: '公益社' },
        { id: 5, name: '辩论社' },
        { id: 6, name: '篮球社' },
        { id: 7, name: '羽毛球社' }
    ];
    
    // 获取所有筛选下拉框
    const clubSelects = [
        document.getElementById('activity-club'),
        document.getElementById('member-club-filter'),
        document.getElementById('activity-club-filter'),
        document.getElementById('news-club-filter'),
        document.getElementById('comment-club-filter'),
        document.getElementById('news-club') // 添加资讯创建模态框的社团选择器
    ];
    
    // 为每个下拉框添加社团选项
    clubSelects.forEach(select => {
        if (select) {
            // 保留默认提示选项
            const defaultOption = select.querySelector('option[value=""]');
            if (defaultOption) {
                select.innerHTML = '';
                select.appendChild(defaultOption);
            }
            
            // 添加社团选项
            clubs.forEach(club => {
                const option = document.createElement('option');
                option.value = club.id;
                option.textContent = club.name;
                select.appendChild(option);
            });
        }
    });
}

// 轮播图功能实现
// 轮播图数据 - 用户可以直接在这里自定义图片地址、标题和描述
let carouselImages = [
    {
        image: "../image/iamgestyle2.jpg",
        title: "编程社团招新开始",
        description: "编程社团将于9月15日开始招新，欢迎对编程感兴趣的同学加入。"
    },
    {
        image: "../image/iamgestyle3.jpg",
        title: "编程马拉松报名通知",
        description: "编程马拉松活动开始报名，报名截止日期为9月20日。"
    },
    {
        image: "../image/indexClub4.jpg",
        title: "技术分享会通知",
        description: "本周六下午2点将举行技术分享会，主题为人工智能应用。"
    },
    {
        image: "../image/iamgestyle1.jpg",
        title: "舞蹈社秋季汇报演出",
        description: "舞蹈社将于10月15日举行秋季汇报演出，欢迎大家前来观看。"
    }
];

// 轮播图当前索引
let currentSlide = 0;

// 自动轮播计时器
let carouselTimer;

// 初始化轮播图
function initCarousel() {
    const slideContainer = document.getElementById('carouselSlide');
    const dotsContainer = document.getElementById('carouselDots');
    
    if (!slideContainer || !dotsContainer) {
        return;
    }
    
    // 清空容器
    slideContainer.innerHTML = '';
    dotsContainer.innerHTML = '';
    
    // 创建轮播项
    carouselImages.forEach((item, index) => {
        // 创建轮播项
        const slideItem = document.createElement('div');
        slideItem.className = 'carousel-item';
        
        // 添加轮播内容
        slideItem.innerHTML = `
            <img src="${item.image}" alt="${item.title}">
            <div class="carousel-content">
                <h3 class="carousel-title">${item.title}</h3>
                <p class="carousel-description">${item.description}</p>
            </div>
        `;
        
        slideContainer.appendChild(slideItem);
        
        // 创建指示点
        const dot = document.createElement('button');
        dot.className = `dot ${index === 0 ? 'active' : ''}`;
        dot.setAttribute('data-index', index);
        dot.onclick = function() {
            goToSlide(index);
        };
        
        dotsContainer.appendChild(dot);
    });
    
    // 设置初始显示
    updateSlidePosition();
    
    // 启动自动轮播
    startAutoCarousel();
}

// 更新轮播图位置
function updateSlidePosition() {
    const slideContainer = document.getElementById('carouselSlide');
    if (slideContainer) {
        slideContainer.style.transform = `translateX(-${currentSlide * 100}%)`;
    }
    
    // 更新指示点状态
    updateDots();
}

// 更新指示点状态
function updateDots() {
    const dots = document.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide);
    });
}

// 切换轮播图
function changeSlide(direction) {
    currentSlide += direction;
    
    // 边界检查
    if (currentSlide < 0) {
        currentSlide = carouselImages.length - 1;
    } else if (currentSlide >= carouselImages.length) {
        currentSlide = 0;
    }
    
    updateSlidePosition();
    
    // 重置自动轮播计时器
    resetAutoCarousel();
}

// 跳转到指定索引的轮播图
function goToSlide(index) {
    currentSlide = index;
    updateSlidePosition();
    
    // 重置自动轮播计时器
    resetAutoCarousel();
}

// 启动自动轮播
function startAutoCarousel() {
    carouselTimer = setInterval(() => {
        changeSlide(1);
    }, 3000); // 每3秒自动切换
}

// 重置自动轮播计时器
function resetAutoCarousel() {
    clearInterval(carouselTimer);
    startAutoCarousel();
}

window.addEventListener('DOMContentLoaded', function() {
    // 更新欢迎消息
    updateWelcomeMessage();
    
    // 初始化轮播图
    initCarousel();
    
    // 初始化显示概览页面
    showSection('overview');
    
    // 加载概览数据
    loadStatistics();
    loadRecentActivities();
    loadPendingMemberships();
    
    // 初始化活动数据
    const existingActivities = localStorage.getItem('activities');
    if (!existingActivities) {
        showMockActivities();
    }
    
    // 加载社团选项
    loadClubOptions();
    
    // 直接调用loadActivities确保数据能正确显示
    loadActivities();
    
    // 为创建社团表单添加事件监听器
    const createClubForm = document.getElementById('create-club-form');
    if (createClubForm) {
        createClubForm.addEventListener('submit', handleCreateClub);
    }
    
    // 为创建活动表单添加事件监听器
    const createActivityForm = document.getElementById('create-activity-form');
    if (createActivityForm) {
        createActivityForm.addEventListener('submit', handleCreateActivity);
    }
});

// 处理创建社团表单提交
function handleCreateClub(event) {
    event.preventDefault();
    
    // 获取表单数据
    const formData = new FormData(event.target);
    const clubData = {
        name: formData.get('name'),
        type: formData.get('type'),
        founder: formData.get('founder'),
        description: formData.get('description'),
        member_count: 1, // 默认只有负责人
        status: 'active',
        created_at: new Date().toISOString().split('T')[0] // 当前日期
    };
    
    // 在真实项目中，这里应该发送AJAX请求到服务器创建社团
    // 由于是模拟环境，我们使用localStorage来存储数据
    let clubs = JSON.parse(localStorage.getItem('clubs')) || [];
    
    // 生成社团ID
    const newId = clubs.length > 0 ? Math.max(...clubs.map(c => c.id)) + 1 : 1;
    clubData.id = newId;
    
    // 添加新社团
    clubs.push(clubData);
    localStorage.setItem('clubs', JSON.stringify(clubs));
    
    // 关闭模态框
    closeModal('club-modal');
    
    // 清空表单
    event.target.reset();
    
    // 更新社团列表
    updateClubList(clubs);
    
    // 显示成功消息
    alert('社团创建成功！');
}

// 处理创建活动表单提交
function handleCreateActivity(event) {
    event.preventDefault();
    
    // 获取表单数据
    const formData = new FormData(event.target);
    
    // 获取社团信息（用于显示社团名称）
    let clubs = JSON.parse(localStorage.getItem('clubs')) || [];
    const clubId = parseInt(formData.get('clubId'));
    const club = clubs.find(c => c.id === clubId);
    
    const activityData = {
        name: formData.get('name'),
        clubId: clubId,
        clubName: club ? club.name : '未指定',
        maxPeople: parseInt(formData.get('maxPeople')),
        signupStart: formData.get('signupStart'),
        signupEnd: formData.get('signupEnd'),
        time: formData.get('time'),
        location: formData.get('location'),
        content: formData.get('content'),
        form: formData.get('form'),
        status: 'upcoming', // 默认状态为即将举行
        createdAt: new Date().toISOString()
    };
    
    // 在真实项目中，这里应该发送AJAX请求到服务器创建活动
    // 由于是模拟环境，我们使用localStorage来存储数据
    let activities = JSON.parse(localStorage.getItem('activities')) || [];
    
    // 生成活动ID
    const newId = activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1;
    activityData.id = newId;
    
    // 添加新活动
    activities.push(activityData);
    localStorage.setItem('activities', JSON.stringify(activities));
    
    // 关闭模态框
    closeModal('activity-modal');
    
    // 清空表单
    event.target.reset();
    
    // 更新活动列表
    updateActivityList(activities);
    
    // 显示成功消息
    alert('活动创建成功！');
}

// 更新社团列表
function updateClubList(clubs) {
    const clubList = document.querySelector('#clubList');
    if (!clubList) return;
    
    clubList.innerHTML = '';
    
    clubs.forEach(club => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${club.id}</td>
            <td>${club.name}</td>
            <td>${club.founder}</td>
            <td>${club.member_count}</td>
            <td>${club.created_at}</td>
            <td><span class="badge ${club.status === 'active' ? 'success' : 'warning'}">${club.status === 'active' ? '活跃' : '暂停'}</span></td>
            <td>
                <button class="btn small" onclick="editClub(${club.id})">编辑</button>
                <button class="btn small" onclick="viewClubMembers(${club.id})">成员</button>
            </td>
        `;
        clubList.appendChild(row);
    });
}

// 更新欢迎消息
function updateWelcomeMessage() {
    // 从localStorage获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    const headingTight = document.querySelector('.heading-tight');
    
    if (currentUser && headingTight) {
        const user = JSON.parse(currentUser);
        // 将"欢迎回来，管理员"替换为"欢迎回来，xxx"
        headingTight.textContent = `欢迎回来，${user.name}`;
    }
}

// 页面切换功能
function showSection(sectionName) {
    // 隐藏所有section
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.style.display = 'none';
    });
    
    // 移除所有导航项的active类
    const navItems = document.querySelectorAll('.nav-pill');
    navItems.forEach(item => {
        item.classList.remove('active');
    });
    
    // 显示目标section
    const targetSection = document.getElementById(sectionName);
    if (targetSection) {
        targetSection.style.display = 'block';
        currentSection = sectionName;
    }
    
    // 设置当前导航项为active
    const targetNav = document.querySelector(`[onclick="showSection('${sectionName}')"]`);
    if (targetNav) {
        targetNav.classList.add('active');
    }
    
    // 根据当前section加载对应数据
    switch(sectionName) {
        case 'overview':
            loadStatistics();
            loadRecentActivities();
            loadPendingMemberships();
            break;
        case 'club-management':
            loadClubManagement();
            break;
        case 'member-management':
            loadMembers();
            break;
        case 'activity-management':
            loadActivities();
            break;
        case 'news-management':
            loadNews();
            break;
        case 'comment-management':
            loadComments();
            break;
    }
}

// 获取统计数据
function loadStatistics() {
    fetch(API_BASE_URL + '?type=clubStats')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('clubCount').textContent = data.data.clubCount;
                document.getElementById('memberCount').textContent = data.data.memberCount;
                document.getElementById('pendingCount').textContent = data.data.pendingCount;
            } else {
                console.error('获取统计数据失败:', data.message);
                // 显示模拟数据
                document.getElementById('clubCount').textContent = '1';
                document.getElementById('memberCount').textContent = '45';
                document.getElementById('pendingCount').textContent = '3';
            }
            // 绘制活跃人数折线图
            drawActivityChart();
        })
        .catch(error => {
            console.error('获取统计数据出错:', error);
            // 显示模拟数据
            document.getElementById('clubCount').textContent = '1';
            document.getElementById('memberCount').textContent = '45';
            document.getElementById('pendingCount').textContent = '3';
            // 绘制活跃人数折线图
            drawActivityChart();
        });
}

// 加载更多事件 - 跳转到活动管理页面
function loadMoreEvents() {
    // 跳转到活动管理页面
    showSection('activity-management');
}

// 显示所有俱乐部
function showAllClubs() {
    // 这里可以实现显示所有俱乐部的逻辑
    console.log('显示所有俱乐部');
    // 示例：可以重定向到俱乐部管理页面
    showSection('club-management');
}

// 显示所有审核
function showAllAudits() {
    // 这里可以实现显示所有审核的逻辑
    console.log('显示所有审核');
    // 示例：可以重定向到成员管理页面或显示所有审核的模态框
    showSection('member-management');
}

// 绘制活跃人数统计折线图
function drawActivityChart() {
    const canvas = document.getElementById('activityChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // 设置canvas尺寸
    canvas.width = 500;
    canvas.height = 200;
    
    // 清空画布
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // 生成30天的随机活跃人数数据
    const days = 30;
    const data = [];
    const dates = [];
    const now = new Date();
    
    for (let i = days - 1; i >= 0; i--) {
        // 生成随机活跃人数（10-500之间）
        const value = Math.floor(Math.random() * 490) + 10;
        data.push(value);
        
        // 生成日期标签
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        dates.push(date.getDate());
    }
    
    // 计算图表边界
    const padding = { top: 20, right: 20, bottom: 40, left: 50 };
    const chartWidth = canvas.width - padding.left - padding.right;
    const chartHeight = canvas.height - padding.top - padding.bottom;
    
    // 计算数据范围
    const maxValue = Math.max(...data);
    const minValue = Math.min(...data);
    const valueRange = maxValue - minValue;
    
    // 绘制网格线
    ctx.strokeStyle = '#e0e0e0';
    ctx.lineWidth = 1;
    
    // 水平线
    for (let i = 0; i <= 5; i++) {
        const y = padding.top + (chartHeight / 5) * i;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartWidth, y);
        ctx.stroke();
        
        // 绘制数值标签
        const value = Math.round(maxValue - (valueRange / 5) * i);
        ctx.fillStyle = '#666';
        ctx.font = '12px Arial';
        ctx.textAlign = 'right';
        ctx.fillText(value, padding.left - 10, y + 5);
    }
    
    // 垂直线
    for (let i = 0; i <= days - 1; i += 5) {
        const x = padding.left + (chartWidth / (days - 1)) * i;
        ctx.beginPath();
        ctx.moveTo(x, padding.top);
        ctx.lineTo(x, padding.top + chartHeight);
        ctx.stroke();
        
        // 绘制日期标签
        ctx.fillStyle = '#666';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(dates[i], x, padding.top + chartHeight + 20);
    }
    
    // 绘制折线
    ctx.strokeStyle = '#2196F3';
    ctx.lineWidth = 3;
    ctx.beginPath();
    
    data.forEach((value, index) => {
        const x = padding.left + (chartWidth / (days - 1)) * index;
        const y = padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
    
    // 绘制数据点
    ctx.fillStyle = '#2196F3';
    data.forEach((value, index) => {
        const x = padding.left + (chartWidth / (days - 1)) * index;
        const y = padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;
        
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
        
        // 添加数据点悬停提示（可选）
        // 这里可以添加更复杂的交互逻辑
    });
    
    // 绘制图表标题
    ctx.fillStyle = '#333';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('每日活跃人数', canvas.width / 2, padding.top - 5);
}

// 获取近期活动
function loadRecentActivities() {
    fetch(API_BASE_URL + '?type=clubEvents')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const eventList = document.getElementById('recentActivityList');
                eventList.innerHTML = '';
                
                data.data.forEach(event => {
                    const li = document.createElement('li');
                    li.className = 'event-item';
                    li.innerHTML = `
                        <h4>${event.title}</h4>
                        <p>时间：${event.date_time}</p>
                        <p>地点：${event.location}</p>
                        <span class="status ${event.status}">${event.status === 'upcoming' ? '即将举行' : event.status === 'ongoing' ? '进行中' : '已结束'}</span>
                    `;
                    eventList.appendChild(li);
                });
            } else {
                console.error('获取近期活动失败:', data.message);
                // 显示模拟数据
                showMockRecentActivities();
            }
        })
        .catch(error => {
            console.error('获取近期活动出错:', error);
            // 显示模拟数据
            showMockRecentActivities();
        });
}

// 获取待审核成员申请
function loadPendingMemberships() {
    fetch(API_BASE_URL + '?type=pendingMemberships')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const applicationList = document.getElementById('pendingMembershipList');
                applicationList.innerHTML = '';
                
                data.data.forEach(app => {
                    const li = document.createElement('li');
                    li.className = 'application-item';
                    li.innerHTML = `
                        <div class="application-info">
                            <h4>${app.student_name}</h4>
                            <p>学号：${app.student_id}</p>
                            <p>申请时间：${app.apply_time}</p>
                        </div>
                        <div class="application-actions">
                            <button onclick="handleMembershipAudit(${app.id}, 'approve')" class="approve-btn">批准</button>
                            <button onclick="handleMembershipAudit(${app.id}, 'reject')" class="reject-btn">拒绝</button>
                        </div>
                    `;
                    applicationList.appendChild(li);
                });
            } else {
                console.error('获取待审核成员申请失败:', data.message);
                // 显示模拟数据
                showMockPendingMemberships();
            }
        })
        .catch(error => {
            console.error('获取待审核成员申请出错:', error);
            // 显示模拟数据
            showMockPendingMemberships();
        });
}

// 加载社团管理数据
function loadClubManagement() {
    // 首先尝试从localStorage获取数据
    let clubs = JSON.parse(localStorage.getItem('clubs'));
    
    if (clubs && clubs.length > 0) {
        // 如果localStorage中有数据，使用这些数据
        updateClubList(clubs);
    } else {
        // 否则尝试从服务器获取数据
        fetch(API_BASE_URL + '?type=clubInfo')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // 更新localStorage
                    localStorage.setItem('clubs', JSON.stringify(data.data));
                    updateClubList(data.data);
                } else {
                    console.error('获取社团信息失败:', data.message);
                    // 显示模拟数据
                    showMockClubManagement();
                }
            })
            .catch(error => {
                console.error('获取社团信息出错:', error);
                // 显示模拟数据
                showMockClubManagement();
            });
    }
}

// 加载活动管理数据
function loadActivities() {
    // 首先尝试从localStorage获取数据
    let activities = JSON.parse(localStorage.getItem('activities'));
    
    if (activities && activities.length > 0) {
        // 如果localStorage中有数据，使用这些数据
        updateActivityList(activities);
    } else {
        // 否则尝试从服务器获取数据
        fetch(API_BASE_URL + '?type=clubActivities')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // 更新localStorage
                    localStorage.setItem('activities', JSON.stringify(data.data));
                    updateActivityList(data.data);
                } else {
                    console.error('获取活动信息失败:', data.message);
                    // 显示模拟数据
                    showMockActivities();
                }
            })
            .catch(error => {
                console.error('获取活动信息出错:', error);
                // 显示模拟数据
                showMockActivities();
            });
    }
}

// 更新活动列表
function updateActivityList(activities) {
    const activityTableBody = document.querySelector('#activityList');
    activityTableBody.innerHTML = '';
    
    activities.forEach(activity => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${activity.id}</td>
            <td>${activity.name}</td>
            <td>${activity.clubName || '未指定'}</td>
            <td>${activity.time}</td>
            <td>${activity.location}</td>
            <td><span class="status ${activity.status}">${activity.status === 'upcoming' ? '即将举行' : activity.status === 'ongoing' ? '进行中' : '已结束'}</span></td>
            <td>
                <button onclick="viewActivityDetails(${activity.id})" class="view-btn">查看</button>
                <button onclick="editActivity(${activity.id})" class="edit-btn">编辑</button>
                <button onclick="openCheckinModal(${activity.id})" class="checkin-btn">签到</button>
                <button onclick="openSummaryModal(${activity.id})" class="summary-btn">总结</button>
            </td>
        `;
        activityTableBody.appendChild(row);
    });
}

// 显示模拟活动数据
function showMockActivities() {
    const mockActivities = [
        // 编程社团活动
        {
            id: 1,
            name: '编程比赛',
            clubId: 1,
            clubName: '编程社团',
            maxPeople: 50,
            signupStart: '2023-11-01T00:00:00',
            signupEnd: '2023-11-15T23:59:59',
            time: '2023-11-20T14:00:00',
            location: '科技楼501教室',
            content: '举办编程技能比赛，增强学生编程能力',
            form: '线下比赛',
            status: 'upcoming',
            createdAt: new Date().toISOString()
        },
        {
            id: 2,
            name: '算法学习讲座',
            clubId: 1,
            clubName: '编程社团',
            maxPeople: 40,
            signupStart: '2023-11-01T00:00:00',
            signupEnd: '2023-11-08T23:59:59',
            time: '2023-11-10T19:00:00',
            location: '科技楼203教室',
            content: '邀请算法竞赛获奖选手分享算法学习经验',
            form: '线下讲座',
            status: 'ongoing',
            createdAt: new Date().toISOString()
        },
        
        // 舞蹈社活动
        {
            id: 3,
            name: '舞蹈排练',
            clubId: 2,
            clubName: '舞蹈社',
            maxPeople: 25,
            signupStart: '2023-11-01T00:00:00',
            signupEnd: '2023-11-30T23:59:59',
            time: '2023-11-10T16:00:00',
            location: '体育馆舞蹈室',
            content: '每周舞蹈排练，为年底晚会做准备',
            form: '线下排练',
            status: 'ongoing',
            createdAt: new Date().toISOString()
        },
        {
            id: 4,
            name: '街舞展示',
            clubId: 2,
            clubName: '舞蹈社',
            maxPeople: 50,
            signupStart: '2023-11-10T00:00:00',
            signupEnd: '2023-11-20T23:59:59',
            time: '2023-11-25T19:30:00',
            location: '学生活动中心',
            content: '展示街舞成果，邀请全校学生观看',
            form: '线下演出',
            status: 'upcoming',
            createdAt: new Date().toISOString()
        },
        
        // 吉他社活动
        {
            id: 5,
            name: '吉他基础教学',
            clubId: 3,
            clubName: '吉他社',
            maxPeople: 30,
            signupStart: '2023-11-01T00:00:00',
            signupEnd: '2023-11-10T23:59:59',
            time: '2023-11-12T15:00:00',
            location: '艺术楼302教室',
            content: '吉他基础教学，适合初学者',
            form: '线下教学',
            status: 'upcoming',
            createdAt: new Date().toISOString()
        },
        {
            id: 6,
            name: '音乐交流会',
            clubId: 3,
            clubName: '吉他社',
            maxPeople: 40,
            signupStart: '2023-11-05T00:00:00',
            signupEnd: '2023-11-15T23:59:59',
            time: '2023-11-18T19:00:00',
            location: '学生活动中心小剧场',
            content: '吉他社成员音乐交流，展示个人才艺',
            form: '线下活动',
            status: 'upcoming',
            createdAt: new Date().toISOString()
        },
        
        // 公益社活动
        {
            id: 7,
            name: '社区清洁活动',
            clubId: 4,
            clubName: '公益社',
            maxPeople: 50,
            signupStart: '2023-11-01T00:00:00',
            signupEnd: '2023-11-08T23:59:59',
            time: '2023-11-11T09:00:00',
            location: '阳光社区',
            content: '参与社区清洁，美化社区环境',
            form: '线下公益活动',
            status: 'upcoming',
            createdAt: new Date().toISOString()
        },
        {
            id: 8,
            name: '爱心捐赠',
            clubId: 4,
            clubName: '公益社',
            maxPeople: 30,
            signupStart: '2023-11-01T00:00:00',
            signupEnd: '2023-11-15T23:59:59',
            time: '2023-11-18T14:00:00',
            location: '学生活动中心',
            content: '收集衣物、书籍等物品，捐赠给山区学校',
            form: '线下捐赠活动',
            status: 'upcoming',
            createdAt: new Date().toISOString()
        },
        
        // 辩论社活动
        {
            id: 9,
            name: '辩论技巧培训',
            clubId: 5,
            clubName: '辩论社',
            maxPeople: 25,
            signupStart: '2023-11-01T00:00:00',
            signupEnd: '2023-11-05T23:59:59',
            time: '2023-11-07T19:00:00',
            location: '教学楼405教室',
            content: '邀请辩论队指导老师进行辩论技巧培训',
            form: '线下培训',
            status: 'ongoing',
            createdAt: new Date().toISOString()
        },
        {
            id: 10,
            name: '校园辩论赛',
            clubId: 5,
            clubName: '辩论社',
            maxPeople: 60,
            signupStart: '2023-11-10T00:00:00',
            signupEnd: '2023-11-20T23:59:59',
            time: '2023-11-25T18:30:00',
            location: '学术报告厅',
            content: '举办校园辩论赛，增强学生思辨能力',
            form: '线下比赛',
            status: 'upcoming',
            createdAt: new Date().toISOString()
        }
    ];
    
    // 保存到localStorage
    localStorage.setItem('activities', JSON.stringify(mockActivities));
    
    // 更新活动列表
    updateActivityList(mockActivities);
}

// 加载成员管理数据
function loadMembers() {
    fetch(API_BASE_URL + '?type=clubMembers')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const memberTableBody = document.querySelector('#memberList');
                memberTableBody.innerHTML = '';
                
                data.data.forEach(member => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${member.student_id}</td>
                        <td>${member.name}</td>
                        <td>${member.club_name}</td>
                        <td>${member.join_date}</td>
                        <td>${member.role}</td>
                        <td><span class="status ${member.status}">${member.status === 'active' ? '活跃' : '已退出'}</span></td>
                        <td>
                            <button onclick="viewMemberDetails(${member.id})" class="view-btn">查看</button>
                            <button onclick="removeMember(${member.id})" class="remove-btn">移除</button>
                        </td>
                    `;
                    memberTableBody.appendChild(row);
                });
            } else {
                console.error('获取成员信息失败:', data.message);
                // 显示模拟数据
                showMockMembers();
            }
        })
        .catch(error => {
            console.error('获取成员信息出错:', error);
            // 显示模拟数据
            showMockMembers();
        });
}

// 删除重复的loadActivities函数定义，保留前面使用正确表格ID的版本

// 加载资讯管理数据
function loadNews() {
    fetch(API_BASE_URL + '?type=clubNews')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const newsTableBody = document.querySelector('#newsList');
                newsTableBody.innerHTML = '';
                
                data.data.forEach(news => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${news.id}</td>
                        <td>${news.title}</td>
                        <td>${news.club_name}</td>
                        <td>${news.date}</td>
                        <td>${news.status === 'active' ? '已发布' : '草稿'}</td>
                        <td>
                            <button onclick="viewNewsDetails(${news.id})" class="view-btn">查看</button>
                            <button onclick="editNews(${news.id})" class="edit-btn">编辑</button>
                            <button onclick="deleteNews(${news.id})" class="delete-btn">删除</button>
                        </td>
                    `;
                    newsTableBody.appendChild(row);
                });
            } else {
                console.error('获取资讯信息失败:', data.message);
                // 显示模拟数据
                showMockNews();
            }
        })
        .catch(error => {
            console.error('获取资讯信息出错:', error);
            // 显示模拟数据
            showMockNews();
        });
}

// 加载评论管理数据
function loadComments() {
    fetch(API_BASE_URL + '?type=clubComments')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const commentTableBody = document.querySelector('#commentList');
                commentTableBody.innerHTML = '';
                
                data.data.forEach(comment => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${comment.id}</td>
                        <td>${comment.content}</td>
                        <td>${comment.target_type === 'activity' ? '活动' : '资讯'}</td>
                        <td>${comment.author_name}</td>
                        <td>${comment.comment_time}</td>
                        <td>${comment.status === 'active' ? '正常' : '已删除'}</td>
                        <td>
                            <button onclick="deleteComment(${comment.id})" class="delete-btn">删除</button>
                        </td>
                    `;
                    commentTableBody.appendChild(row);
                });
            } else {
                console.error('获取评论信息失败:', data.message);
                // 显示模拟数据
                showMockComments();
            }
        })
        .catch(error => {
            console.error('获取评论信息出错:', error);
            // 显示模拟数据
            showMockComments();
        });
}

// 打开创建模态框
function openCreateModal(modalType) {
    // 根据不同类型打开不同的模态框
    const modalId = modalType + '-modal';
    const modal = document.getElementById(modalId);
    const modalContainer = document.getElementById('modal-container');
    
    console.log('openCreateModal called with modalType:', modalType);
    console.log('Modal ID:', modalId);
    console.log('Modal element:', modal);
    console.log('Modal container:', modalContainer);
    
    if (modal && modalContainer) {
        // 先隐藏所有模态框
        const allModals = document.querySelectorAll('.modal');
        console.log('All modals:', allModals);
        allModals.forEach(m => {
            m.style.display = 'none';
        });
        
        // 再显示目标模态框和容器
        console.log('Setting modalContainer display to flex');
        modalContainer.style.display = 'flex';
        console.log('Setting modal display to block');
        modal.style.display = 'block';
        
        // 添加active类
        modalContainer.classList.add('active');
    } else {
        console.error('Modal or modal container not found!');
        if (!modal) console.error('Modal element not found with ID:', modalId);
        if (!modalContainer) console.error('Modal container not found!');
    }
    
    // 根据模态框类型加载不同的表单内容
    if (modalType === 'activity' || modalType === 'news') {
        // 加载社团选项
        loadClubOptions();
    }
}

// 创建资讯
function createNews(event) {
    event.preventDefault();
    
    // 获取表单数据
    const title = document.getElementById('news-title').value;
    const clubId = document.getElementById('news-club').value;
    const content = document.getElementById('news-content').value;
    const status = document.getElementById('news-status').value;
    const imageFile = document.getElementById('news-image').files[0];
    const documentFile = document.getElementById('news-document').files[0];
    
    // 构建资讯数据
    const newsData = {
        title,
        clubId: parseInt(clubId),
        content,
        status,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    // 处理文件上传（模拟）
    if (imageFile) {
        // 在实际应用中，这里会上传文件到服务器
        // 这里我们只保存文件名
        newsData.image = imageFile.name;
    }
    
    if (documentFile) {
        // 在实际应用中，这里会上传文件到服务器
        // 这里我们只保存文件名
        newsData.document = documentFile.name;
    }
    
    // 从localStorage获取现有资讯
    let news = JSON.parse(localStorage.getItem('news')) || [];
    
    // 生成资讯ID
    const newId = news.length > 0 ? Math.max(...news.map(n => n.id)) + 1 : 1;
    newsData.id = newId;
    
    // 添加新资讯
    news.push(newsData);
    localStorage.setItem('news', JSON.stringify(news));
    
    // 关闭模态框
    closeModal('news-modal');
    
    // 清空表单
    event.target.reset();
    
    // 更新资讯列表
    updateNewsList(news);
    
    // 显示成功消息
    alert('资讯创建成功！');
}

// 更新资讯列表
function updateNewsList(news) {
    // 这个函数可以根据需要更新页面上的资讯列表
    // 目前我们没有在首页显示资讯列表，所以这里可以留空
    // 可以在需要时添加具体实现
    console.log('资讯列表已更新:', news);
}

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', function() {
    // 为创建资讯表单添加提交事件监听器
    const createNewsForm = document.getElementById('create-news-form');
    if (createNewsForm) {
        createNewsForm.addEventListener('submit', createNews);
    }
});

// 关闭模态框
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    const modalContainer = document.getElementById('modal-container');
    if (modal) {
        modal.style.display = 'none';
        modalContainer.style.display = 'none';
    }
}

// 处理成员申请审核
function handleMembershipAudit(applicationId, action) {
    // 显示加载状态
    const buttons = document.querySelectorAll(`button[onclick="handleMembershipAudit(${applicationId}, '${action}')"]`);
    buttons.forEach(btn => {
        btn.disabled = true;
        btn.textContent = '处理中...';
    });
    
    fetch(API_BASE_URL + '?type=auditMembership', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            id: applicationId,
            action: action
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('审核成功');
            // 重新加载待审核列表
            loadPendingMemberships();
            // 更新统计数据
            loadStatistics();
        } else {
            alert('审核失败: ' + data.message);
            // 恢复按钮状态
            buttons.forEach(btn => {
                btn.disabled = false;
                btn.textContent = action === 'approve' ? '批准' : '拒绝';
            });
        }
    })
    .catch(error => {
        console.error('处理成员申请审核出错:', error);
        alert('审核出错: ' + error.message);
        // 恢复按钮状态
        buttons.forEach(btn => {
            btn.disabled = false;
            btn.textContent = action === 'approve' ? '批准' : '拒绝';
        });
    });
}

// 活动签到功能
function openCheckinModal(activityId) {
    alert('打开活动签到模态框，活动ID: ' + activityId);
    // 实际项目中可以实现签到二维码或签到表单
}

// 提交活动总结
function openSummaryModal(activityId) {
    alert('打开活动总结提交模态框，活动ID: ' + activityId);
    // 实际项目中可以实现总结提交表单
}

// 社团管理功能
function editClub(clubId) {
    alert('打开编辑社团模态框，社团ID: ' + clubId);
}

function toggleClubStatus(clubId, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    if (confirm(`确定要将社团状态改为${newStatus === 'active' ? '活跃' : '暂停'}吗？`)) {
        // 发送状态变更请求
        fetch(API_BASE_URL + '?type=toggleClubStatus', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: clubId,
                status: newStatus
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('社团状态已更新');
                // 重新加载社团列表
                loadClubManagement();
            } else {
                alert('状态更新失败: ' + data.message);
            }
        })
        .catch(error => {
            console.error('更新社团状态出错:', error);
            alert('状态更新出错: ' + error.message);
        });
    }
}

// 成员管理功能
function viewMemberDetails(memberId) {
    alert('查看成员详情，成员ID: ' + memberId);
}

function removeMember(memberId) {
    if (confirm('确定要移除该成员吗？')) {
        // 发送移除请求
        fetch(API_BASE_URL + '?type=removeMember', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: memberId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('成员已移除');
                // 重新加载成员列表
                loadMembers();
                // 更新统计数据
                loadStatistics();
            } else {
                alert('移除失败: ' + data.message);
            }
        })
        .catch(error => {
            console.error('移除成员出错:', error);
            // 模拟删除成功，因为可能没有后端API
            // 从模拟数据中删除成员
            const index = mockMembers.findIndex(member => member.id === memberId);
            if (index !== -1) {
                mockMembers.splice(index, 1);
                alert('成员已移除');
                // 重新加载成员列表
                loadMembers();
                // 更新统计数据
                loadStatistics();
            } else {
                alert('移除失败: 未找到该成员');
            }
        });
    }
}

// 活动管理功能
function viewActivityDetails(activityId) {
    // 跳转到active2.html页面并传递活动ID参数
    window.location.href = `active2.html?activityId=${activityId}`;
}

function editActivity(activityId) {
    alert('打开编辑活动模态框，活动ID: ' + activityId);
}

function deleteActivity(activityId) {
    if (confirm('确定要删除该活动吗？')) {
        // 发送删除请求
        fetch(API_BASE_URL + '?type=deleteActivity', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: activityId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('活动已删除');
                // 重新加载活动列表
                loadActivities();
            } else {
                alert('删除失败: ' + data.message);
            }
        })
        .catch(error => {
            console.error('删除活动出错:', error);
            alert('删除出错: ' + error.message);
        });
    }
}

// 资讯管理功能
function viewNewsDetails(newsId) {
    alert('查看资讯详情，资讯ID: ' + newsId);
}

function editNews(newsId) {
    alert('打开编辑资讯模态框，资讯ID: ' + newsId);
}

function deleteNews(newsId) {
    if (confirm('确定要删除该资讯吗？')) {
        // 发送删除请求
        fetch(API_BASE_URL + '?type=deleteNews', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: newsId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('资讯已删除');
                // 重新加载资讯列表
                loadNews();
            } else {
                alert('删除失败: ' + data.message);
            }
        })
        .catch(error => {
            console.error('删除资讯出错:', error);
            // 模拟删除成功，因为可能没有后端API
            // 从模拟数据中删除资讯
            const index = mockNews.findIndex(news => news.id === newsId);
            if (index !== -1) {
                mockNews.splice(index, 1);
                alert('资讯已删除');
                // 重新加载资讯列表
                loadNews();
            } else {
                alert('删除失败: 未找到该资讯');
            }
        });
    }
}

// 评论管理功能
function deleteComment(commentId) {
    if (confirm('确定要删除该评论吗？')) {
        // 发送删除请求
        fetch(API_BASE_URL + '?type=deleteComment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: commentId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('评论已删除');
                // 重新加载评论列表
                loadComments();
            } else {
                alert('删除失败: ' + data.message);
            }
        })
        .catch(error => {
            console.error('删除评论出错:', error);
            // 模拟删除成功，因为可能没有后端API
            // 从模拟数据中删除评论
            const index = mockComments.findIndex(comment => comment.id === commentId);
            if (index !== -1) {
                mockComments.splice(index, 1);
                alert('评论已删除');
                // 重新加载评论列表
                loadComments();
            } else {
                alert('删除失败: 未找到该评论');
            }
        });
    }
}

// 退出登录
function logout() {
    // 清除localStorage中的用户信息
    localStorage.removeItem('currentUser');
    // 跳转到登录页面
    window.location.href = 'index.html';
}

// 筛选功能
function filterActivities() {
    const searchTerm = document.getElementById('activitySearch').value.toLowerCase();
    const statusFilter = document.getElementById('activityStatusFilter').value;
    
    console.log('筛选活动:', searchTerm, statusFilter);
    // 实际项目中可以调用loadActivities并传入筛选参数
}

function filterMembers() {
    const searchTerm = document.getElementById('memberSearch').value.toLowerCase();
    
    console.log('筛选成员:', searchTerm);
    // 实际项目中可以调用loadMembers并传入筛选参数
}

// 成员管理筛选功能
function filterMembers() {
    const clubFilter = document.getElementById('member-club-filter').value;
    const searchTerm = document.getElementById('memberSearch').value.toLowerCase();
    
    // 筛选模拟数据
    let filteredMembers = [...mockMembers];
    
    // 按社团筛选
    if (clubFilter) {
        filteredMembers = filteredMembers.filter(member => member.club_id == clubFilter);
    }
    
    // 按关键字筛选
    if (searchTerm) {
        filteredMembers = filteredMembers.filter(member => 
            member.name.toLowerCase().includes(searchTerm) || 
            member.student_id.includes(searchTerm)
        );
    }
    
    // 更新表格显示
    const memberTableBody = document.querySelector('#memberList');
    memberTableBody.innerHTML = '';
    
    filteredMembers.forEach(member => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${member.student_id}</td>
            <td>${member.name}</td>
            <td>${member.club_name}</td>
            <td>${member.join_date}</td>
            <td>${member.role}</td>
            <td><span class="status ${member.status}">${member.status === 'active' ? '活跃' : '已退出'}</span></td>
            <td>
                <button onclick="viewMemberDetails(${member.id})" class="view-btn">查看</button>
                <button onclick="removeMember(${member.id})" class="remove-btn">移除</button>
            </td>
        `;
        memberTableBody.appendChild(row);
    });
}

// 活动管理筛选功能
function filterActivities() {
    const clubFilter = document.getElementById('activity-club-filter').value;
    const searchTerm = document.getElementById('activitySearch').value.toLowerCase();
    
    // 获取活动数据（优先从localStorage获取）
    let activities = JSON.parse(localStorage.getItem('activities')) || [];
    if (activities.length === 0) {
        // 如果localStorage中没有数据，使用模拟数据
        activities = [
            { id: 1, name: '新生见面会', clubId: 1, clubName: '编程社', maxPeople: 50, signupStart: '2023-09-01T00:00:00', signupEnd: '2023-09-10T23:59:59', time: '2023-09-15T14:00:00', location: '教学楼A101', content: '欢迎新生加入编程社团', form: '线下', status: 'completed', createdAt: new Date().toISOString() },
            { id: 2, name: '技术分享会', clubId: 1, clubName: '编程社', maxPeople: 80, signupStart: '2023-09-10T00:00:00', signupEnd: '2023-09-20T23:59:59', time: '2023-09-25T16:00:00', location: '图书馆报告厅', content: '人工智能技术分享', form: '线下', status: 'completed', createdAt: new Date().toISOString() },
            { id: 3, name: '编程马拉松', clubId: 1, clubName: '编程社', maxPeople: 100, signupStart: '2023-10-01T00:00:00', signupEnd: '2023-10-15T23:59:59', time: '2023-10-20T09:00:00', location: '实训楼B301', content: '24小时编程挑战', form: '线下', status: 'completed', createdAt: new Date().toISOString() },
            { id: 4, name: '舞蹈基础训练', clubId: 2, clubName: '舞蹈社', maxPeople: 30, signupStart: '2023-09-05T00:00:00', signupEnd: '2023-09-15T23:59:59', time: '2023-09-20T19:00:00', location: '体育馆舞蹈房', content: '零基础舞蹈训练', form: '线下', status: 'completed', createdAt: new Date().toISOString() },
            { id: 5, name: '吉他入门课程', clubId: 3, clubName: '吉他社', maxPeople: 20, signupStart: '2023-09-10T00:00:00', signupEnd: '2023-09-20T23:59:59', time: '2023-09-25T15:00:00', location: '音乐楼203', content: '吉他入门基础知识', form: '线下', status: 'completed', createdAt: new Date().toISOString() },
            { id: 6, name: '社区服务', clubId: 4, clubName: '公益社', maxPeople: 40, signupStart: '2023-10-01T00:00:00', signupEnd: '2023-10-10T23:59:59', time: '2023-10-15T14:00:00', location: '阳光社区', content: '社区环境整治', form: '线下', status: 'completed', createdAt: new Date().toISOString() },
            { id: 7, name: '辩论技巧培训', clubId: 5, clubName: '辩论社', maxPeople: 25, signupStart: '2023-11-01T00:00:00', signupEnd: '2023-11-05T23:59:59', time: '2023-11-07T19:00:00', location: '教学楼405教室', content: '邀请辩论队指导老师进行辩论技巧培训', form: '线下', status: 'ongoing', createdAt: new Date().toISOString() },
            { id: 8, name: '校园辩论赛', clubId: 5, clubName: '辩论社', maxPeople: 60, signupStart: '2023-11-10T00:00:00', signupEnd: '2023-11-20T23:59:59', time: '2023-11-25T18:30:00', location: '学术报告厅', content: '举办校园辩论赛，增强学生思辨能力', form: '线下', status: 'upcoming', createdAt: new Date().toISOString() }
        ];
    }
    
    // 筛选活动数据
    let filteredActivities = [...activities];
    
    // 按社团筛选
    if (clubFilter) {
        filteredActivities = filteredActivities.filter(activity => activity.clubId == clubFilter);
    }
    
    // 按关键字筛选
    if (searchTerm) {
        filteredActivities = filteredActivities.filter(activity => 
            activity.name.toLowerCase().includes(searchTerm)
        );
    }
    
    // 更新表格显示
    const activityTableBody = document.querySelector('#activityList');
    activityTableBody.innerHTML = '';
    
    filteredActivities.forEach(activity => {
        const statusText = activity.status === 'completed' ? '已完成' : activity.status === 'ongoing' ? '进行中' : '即将开始';
        const statusClass = activity.status;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${activity.id}</td>
            <td>${activity.name}</td>
            <td>${activity.clubName}</td>
            <td>${new Date(activity.time).toLocaleString()}</td>
            <td>${activity.location}</td>
            <td><span class="status ${statusClass}">${statusText}</span></td>
            <td>
                <button onclick="viewActivityDetails(${activity.id})" class="view-btn">查看</button>
                <button onclick="editActivity(${activity.id})" class="edit-btn">编辑</button>
                ${activity.status === 'ongoing' ? `<button onclick="openCheckinModal(${activity.id})" class="checkin-btn">签到</button>` : ''}
                ${activity.status === 'completed' ? `<button onclick="openSummaryModal(${activity.id})" class="summary-btn">总结</button>` : ''}
            </td>
        `;
        activityTableBody.appendChild(row);
    });
}

// 资讯管理筛选功能
function filterNews() {
    const clubFilter = document.getElementById('news-club-filter').value;
    const searchTerm = document.getElementById('newsSearch').value.toLowerCase();
    
    // 筛选模拟数据
    let filteredNews = [...mockNews];
    
    // 按社团筛选
    if (clubFilter) {
        // 获取选中的社团名称
        const clubSelect = document.getElementById('news-club-filter');
        const selectedClubName = clubSelect.options[clubSelect.selectedIndex].text;
        
        filteredNews = filteredNews.filter(news => news.club_name === selectedClubName);
    }
    
    // 按关键字筛选
    if (searchTerm) {
        filteredNews = filteredNews.filter(news => 
            news.title.toLowerCase().includes(searchTerm) || 
            news.content.toLowerCase().includes(searchTerm)
        );
    }
    
    // 更新表格显示
    const newsTableBody = document.querySelector('#newsList');
    newsTableBody.innerHTML = '';
    
    filteredNews.forEach(news => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${news.id}</td>
            <td>${news.title}</td>
            <td>${news.club_name}</td>
            <td>${news.date}</td>
            <td>${news.status === 'active' ? '已发布' : '草稿'}</td>
            <td>
                <button onclick="viewNewsDetails(${news.id})" class="view-btn">查看</button>
                <button onclick="editNews(${news.id})" class="edit-btn">编辑</button>
                <button onclick="deleteNews(${news.id})" class="delete-btn">删除</button>
            </td>
        `;
        newsTableBody.appendChild(row);
    });
}

// 评论管理筛选功能
function filterComments() {
    const clubFilter = document.getElementById('comment-club-filter').value;
    const searchTerm = document.getElementById('commentSearch').value.toLowerCase();
    
    // 筛选模拟数据
    let filteredComments = [...mockComments];
    
    // 按社团筛选（需要根据评论关联的社团进行筛选，这里简化处理）
    if (clubFilter) {
        // 由于评论没有直接关联社团，我们根据目标标题间接关联
        const clubSelect = document.getElementById('comment-club-filter');
        const selectedClubName = clubSelect.options[clubSelect.selectedIndex].text;
        
        // 这里简化处理，实际项目中需要评论关联到社团
        filteredComments = filteredComments.filter(comment => 
            comment.target_title.includes(selectedClubName) || 
            comment.content.includes(selectedClubName)
        );
    }
    
    // 按关键字筛选
    if (searchTerm) {
        filteredComments = filteredComments.filter(comment => 
            comment.content.toLowerCase().includes(searchTerm) || 
            comment.author_name.toLowerCase().includes(searchTerm) ||
            comment.target_title.toLowerCase().includes(searchTerm)
        );
    }
    
    // 更新表格显示
    const commentTableBody = document.querySelector('#commentList');
    commentTableBody.innerHTML = '';
    
    filteredComments.forEach(comment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${comment.id}</td>
            <td>${comment.content}</td>
            <td>${comment.target_type === 'activity' ? '活动' : '资讯'}</td>
            <td>${comment.author_name}</td>
            <td>${comment.comment_time}</td>
            <td>${comment.status === 'active' ? '正常' : '已删除'}</td>
            <td>
                <button onclick="deleteComment(${comment.id})" class="delete-btn">删除</button>
            </td>
        `;
        commentTableBody.appendChild(row);
    });
}

// 社团管理搜索功能
function filterClubs() {
    const searchTerm = document.getElementById('clubSearch').value.toLowerCase();
    
    // 获取社团数据（优先从localStorage获取）
    let clubs = JSON.parse(localStorage.getItem('clubs')) || [];
    if (clubs.length === 0) {
        // 如果localStorage中没有数据，使用模拟数据
        clubs = [
            { id: 1, name: '编程社', type: '学术科技', description: '学习编程技术，参与项目开发', member_count: 45, founder: '张三', status: 'active', created_at: '2023-09-10' },
            { id: 2, name: '舞蹈社', type: '文化体育', description: '学习各种舞蹈，参加校园演出', member_count: 32, founder: '李四', status: 'active', created_at: '2023-09-15' },
            { id: 3, name: '吉他社', type: '文化体育', description: '学习吉他弹奏，组织音乐交流活动', member_count: 28, founder: '王五', status: 'active', created_at: '2023-09-20' },
            { id: 4, name: '公益社', type: '公益服务', description: '参与社区服务，传递爱心正能量', member_count: 56, founder: '赵六', status: 'active', created_at: '2023-09-25' },
            { id: 5, name: '辩论社', type: '学术科技', description: '锻炼思辨能力，参加辩论比赛', member_count: 22, founder: '孙七', status: 'active', created_at: '2023-10-05' }
        ];
    }
    
    // 筛选社团数据
    let filteredClubs = [...clubs];
    
    // 按关键字筛选
    if (searchTerm) {
        filteredClubs = filteredClubs.filter(club => 
            club.name.toLowerCase().includes(searchTerm) ||
            club.type.toLowerCase().includes(searchTerm) ||
            club.description.toLowerCase().includes(searchTerm)
        );
    }
    
    // 更新表格显示
    const clubTableBody = document.querySelector('#clubList');
    clubTableBody.innerHTML = '';
    
    filteredClubs.forEach(club => {
        const statusText = club.status === 'active' ? '活跃' : '暂停';
        const statusClass = club.status;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${club.id}</td>
            <td>${club.name}</td>
            <td>${club.founder}</td>
            <td>${club.member_count}</td>
            <td>${new Date(club.created_at).toLocaleDateString()}</td>
            <td><span class="status ${statusClass}">${statusText}</span></td>
            <td>
                <button onclick="editClub(${club.id})" class="edit-btn">编辑</button>
                <button onclick="toggleClubStatus(${club.id}, '${club.status}')" class="status-btn">${statusText === '活跃' ? '暂停' : '激活'}</button>
            </td>
        `;
        clubTableBody.appendChild(row);
    });
}

// 显示模拟数据（用于测试）
function showMockRecentActivities() {
    const eventList = document.getElementById('recentActivityList');
    eventList.innerHTML = '';
    
    const mockEvents = [
        { id: 1, title: '编程马拉松', date_time: '2024-09-25 14:00', location: '教学楼B301', status: 'upcoming' },
        { id: 2, title: '技术分享会', date_time: '2024-09-20 16:00', location: '图书馆报告厅', status: 'ongoing' },
        { id: 3, title: '新生见面会', date_time: '2024-09-15 10:00', location: '体育馆', status: 'completed' }
    ];
    
    mockEvents.forEach(event => {
        const li = document.createElement('li');
        li.className = 'event-item';
        li.innerHTML = `
            <h4>${event.title}</h4>
            <p>时间：${event.date_time}</p>
            <p>地点：${event.location}</p>
            <span class="status ${event.status}">${event.status === 'upcoming' ? '即将举行' : event.status === 'ongoing' ? '进行中' : '已结束'}</span>
        `;
        eventList.appendChild(li);
    });
}

function showMockPendingMemberships() {
    const applicationList = document.getElementById('pendingMembershipList');
    applicationList.innerHTML = '';
    
    const mockApplications = [
        { id: 1, student_id: '2024001', student_name: '小明', apply_time: '2024-09-18 09:30' },
        { id: 2, student_id: '2024002', student_name: '小红', apply_time: '2024-09-18 10:15' },
        { id: 3, student_id: '2024003', student_name: '小刚', apply_time: '2024-09-18 11:20' }
    ];
    
    mockApplications.forEach(app => {
        const li = document.createElement('li');
        li.className = 'application-item';
        li.innerHTML = `
            <div class="application-info">
                <h4>${app.student_name}</h4>
                <p>学号：${app.student_id}</p>
                <p>申请时间：${app.apply_time}</p>
            </div>
            <div class="application-actions">
                <button onclick="handleMembershipAudit(${app.id}, 'approve')" class="approve-btn">批准</button>
                <button onclick="handleMembershipAudit(${app.id}, 'reject')" class="reject-btn">拒绝</button>
            </div>
        `;
        applicationList.appendChild(li);
    });
}

function showMockClubManagement() {
    // 定义更多默认社团数据
    const mockClubs = [
        { id: 1, name: '编程社团', type: '学术科技', description: '学习编程技术，参与项目开发', member_count: 45, founder: '张三', status: 'active', created_at: '2023-09-10' },
        { id: 2, name: '舞蹈社', type: '文化体育', description: '学习各种舞蹈，参加校园演出', member_count: 32, founder: '李四', status: 'active', created_at: '2023-09-15' },
        { id: 3, name: '吉他社', type: '文化体育', description: '学习吉他弹奏，组织音乐交流活动', member_count: 28, founder: '王五', status: 'active', created_at: '2023-09-20' },
        { id: 4, name: '公益社', type: '公益服务', description: '参与社区服务，传递爱心正能量', member_count: 56, founder: '赵六', status: 'active', created_at: '2023-09-25' },
        { id: 5, name: '辩论社', type: '学术科技', description: '锻炼思辨能力，参加辩论比赛', member_count: 22, founder: '孙七', status: 'active', created_at: '2023-10-05' }
    ];
    
    // 更新localStorage
    localStorage.setItem('clubs', JSON.stringify(mockClubs));
    
    // 更新社团列表
    updateClubList(mockClubs);
}

function showMockMembers() {
    const memberTableBody = document.querySelector('#memberList');
    memberTableBody.innerHTML = '';
    
    mockMembers.forEach(member => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${member.student_id}</td>
            <td>${member.name}</td>
            <td>${member.club_name}</td>
            <td>${member.join_date}</td>
            <td>${member.role}</td>
            <td><span class="status ${member.status}">${member.status === 'active' ? '活跃' : '已退出'}</span></td>
            <td>
                <button onclick="viewMemberDetails(${member.id})" class="view-btn">查看</button>
                <button onclick="removeMember(${member.id})" class="remove-btn">移除</button>
            </td>
        `;
        memberTableBody.appendChild(row);
    });
}

// 删除重复的showMockActivities函数定义，保留前面使用正确表格ID的版本

function showMockNews() {
    const newsTableBody = document.querySelector('#newsList');
    newsTableBody.innerHTML = '';
    
    mockNews.forEach(news => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${news.id}</td>
            <td>${news.title}</td>
            <td>${news.club_name}</td>
            <td>${news.date}</td>
            <td>${news.status === 'active' ? '已发布' : '草稿'}</td>
            <td>
                <button onclick="viewNewsDetails(${news.id})" class="view-btn">查看</button>
                <button onclick="editNews(${news.id})" class="edit-btn">编辑</button>
                <button onclick="deleteNews(${news.id})" class="delete-btn">删除</button>
            </td>
        `;
        newsTableBody.appendChild(row);
    });
}

function showMockComments() {
    const commentTableBody = document.querySelector('#commentList');
    commentTableBody.innerHTML = '';
    
    mockComments.forEach(comment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${comment.id}</td>
            <td>${comment.content}</td>
            <td>${comment.target_type === 'activity' ? '活动' : '资讯'}</td>
            <td>${comment.author_name}</td>
            <td>${comment.comment_time}</td>
            <td>${comment.status === 'active' ? '正常' : '已删除'}</td>
            <td>
                <button onclick="deleteComment(${comment.id})" class="delete-btn">删除</button>
            </td>
        `;
        commentTableBody.appendChild(row);
    });
}

// 个人信息相关函数

// 显示个人信息页面
function showPersonalInfo() {
    showSection('personal-info');
    loadPersonalInfo();
}

// 加载个人信息
function loadPersonalInfo() {
    // 从localStorage获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    
    // 填充个人信息表单
    document.getElementById('admin-id').value = user.id;
    document.getElementById('name').value = user.name;
    document.getElementById('email').value = user.email || '';
    document.getElementById('phone').value = user.phone || '';
    document.getElementById('role').value = user.role || '管理员';
    
    // 更新统计数字
    updatePersonalStats();
}

// 更新个人统计信息
function updatePersonalStats() {
    // 获取localStorage中的数据
    const clubs = JSON.parse(localStorage.getItem('clubs')) || [];
    const activities = JSON.parse(localStorage.getItem('activities')) || [];
    
    // 模拟当前用户ID
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const userId = currentUser ? currentUser.id : '1';
    
    // 计算已创办的社团数量
    const foundedClubsCount = clubs.filter(club => club.founderId === userId).length;
    document.getElementById('founded-clubs-count').textContent = foundedClubsCount;
    
    // 计算已举办的活动数量
    const organizedActivitiesCount = activities.filter(activity => activity.organizerId === userId).length;
    document.getElementById('organized-activities-count').textContent = organizedActivitiesCount;
    
    // 计算今日安排数量（模拟今天的活动）
    const today = new Date().toISOString().split('T')[0];
    const todayScheduleCount = activities.filter(activity => 
        activity.date === today && activity.organizerId === userId
    ).length;
    document.getElementById('today-schedule-count').textContent = todayScheduleCount;
}

// 保存个人信息
function savePersonalInfo() {
    // 获取表单数据
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    
    // 获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    
    // 更新用户信息
    fetch(API_BASE_URL + '?type=updateProfile', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            id: user.id,
            name: name,
            email: email,
            phone: phone
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('个人信息更新成功');
            // 更新localStorage中的用户信息
            user.name = name;
            user.email = email;
            user.phone = phone;
            localStorage.setItem('currentUser', JSON.stringify(user));
            // 更新欢迎消息
            updateWelcomeMessage();
        } else {
            alert('个人信息更新失败: ' + data.message);
        }
    })
    .catch(error => {
        console.error('更新个人信息出错:', error);
        alert('更新出错: ' + error.message);
    });
}

// 修改密码
function changePassword() {
    const oldPassword = document.getElementById('old-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    // 验证密码
    if (newPassword !== confirmPassword) {
        alert('两次输入的新密码不一致');
        return;
    }
    
    // 获取当前用户信息
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) return;
    
    const user = JSON.parse(currentUser);
    
    // 发送密码修改请求
    fetch(API_BASE_URL + '?type=changePassword', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            id: user.id,
            oldPassword: oldPassword,
            newPassword: newPassword
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('密码修改成功');
            // 清空密码表单
            document.getElementById('old-password').value = '';
            document.getElementById('new-password').value = '';
            document.getElementById('confirm-password').value = '';
        } else {
            alert('密码修改失败: ' + data.message);
        }
    })
    .catch(error => {
        console.error('修改密码出错:', error);
        alert('修改出错: ' + error.message);
    });
}

// 取消编辑个人信息
function cancelEditPersonalInfo() {
    // 重新加载个人信息，恢复原始数据
    loadPersonalInfo();
}

// 取消修改密码
function cancelChangePassword() {
    // 清空密码表单
    document.getElementById('old-password').value = '';
    document.getElementById('new-password').value = '';
    document.getElementById('confirm-password').value = '';
}

// 表单事件监听
document.addEventListener('DOMContentLoaded', function() {
    // 个人信息表单提交事件
    const personalInfoForm = document.getElementById('personal-info-form');
    if (personalInfoForm) {
        personalInfoForm.addEventListener('submit', function(e) {
            e.preventDefault();
            savePersonalInfo();
        });
    }
    
    // 修改密码表单提交事件
    const changePasswordForm = document.getElementById('change-password-form');
    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            changePassword();
        });
    }
});

// 管理员首页搜索功能
function searchAdminHomePage() {
    const query = document.getElementById('admin-home-search').value;
    if (query.trim() !== '') {
        window.location.href = `information.html?q=${encodeURIComponent(query)}&type=all`;
    }
}

