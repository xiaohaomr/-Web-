// 活动数据
const activityData = {
    1: {
        id: 1,
        title: "2024春季招新宣讲会",
        status: "ongoing", // upcoming, ongoing, ended
        date: "2024-03-15",
        time: "19:00-21:00",
        location: "教学楼A101",
        organizer: "计算机协会",
        participants: 120,
        maxParticipants: 200,
        description: "计算机协会2024春季招新宣讲会，欢迎所有对计算机技术感兴趣的同学参加。我们将介绍协会的发展历程、组织结构、活动内容以及招新要求。现场还有技术展示和抽奖环节，不要错过！",
        requirements: "对计算机技术有兴趣，愿意参加协会活动。",
        contact: "张三 13800138000",
        posterUrl: "images/activity1.jpg",
        createTime: "2024-03-01 10:00:00",
        updateTime: "2024-03-05 16:30:00"
    }
};

// 当前活动ID
let currentActivityId = 1;

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 加载活动详情
    loadActivityDetails(currentActivityId);
    
    // 绑定返回列表按钮事件
    document.getElementById('backToList').addEventListener('click', function() {
        // 返回社团活动列表页
        window.location.href = 'systemb.html';
    });
    
    // 绑定修改活动按钮事件
    document.getElementById('editActivity').addEventListener('click', function() {
        // 跳转到活动编辑页面
        alert('跳转到活动编辑页面，活动ID: ' + currentActivityId);
    });
    
    // 绑定删除活动按钮事件
    document.getElementById('deleteActivity').addEventListener('click', function() {
        if (confirm('确定要删除该活动吗？')) {
            alert('删除活动，活动ID: ' + currentActivityId);
            // 返回社团活动列表页
            window.location.href = 'systemb.html';
        }
    });
    
    // 绑定报名管理按钮事件
    document.getElementById('manageRegistration').addEventListener('click', function() {
        alert('打开报名管理页面，活动ID: ' + currentActivityId);
    });
    
    // 绑定活动总结按钮事件
    document.getElementById('addSummary').addEventListener('click', function() {
        openSummaryModal();
    });
});

// 加载活动详情
function loadActivityDetails(activityId) {
    const activity = activityData[activityId];
    if (!activity) {
        alert('活动不存在');
        return;
    }
    
    // 设置标题
    document.getElementById('activityTitle').textContent = activity.title;
    
    // 设置状态
    const statusElement = document.getElementById('activityStatus');
    statusElement.textContent = getStatusText(activity.status);
    statusElement.className = 'activity-status ' + activity.status;
    
    // 设置元信息
    document.getElementById('activityDate').textContent = activity.date;
    document.getElementById('activityTime').textContent = activity.time;
    document.getElementById('activityLocation').textContent = activity.location;
    document.getElementById('activityOrganizer').textContent = activity.organizer;
    document.getElementById('activityParticipants').textContent = activity.participants + '/' + activity.maxParticipants;
    document.getElementById('activityContact').textContent = activity.contact;
    
    // 设置描述和要求
    document.getElementById('activityDescription').textContent = activity.description;
    document.getElementById('activityRequirements').textContent = activity.requirements;
    
    // 设置创建和更新时间
    document.getElementById('activityCreateTime').textContent = activity.createTime;
    document.getElementById('activityUpdateTime').textContent = activity.updateTime;
}

// 获取状态文本
function getStatusText(status) {
    const statusMap = {
        upcoming: '即将开始',
        ongoing: '进行中',
        ended: '已结束'
    };
    return statusMap[status] || status;
}

// 打开活动总结模态框
function openSummaryModal() {
    alert('打开活动总结模态框，活动ID: ' + currentActivityId);
}