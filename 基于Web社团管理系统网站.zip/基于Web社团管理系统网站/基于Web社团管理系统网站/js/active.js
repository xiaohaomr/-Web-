// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 从localStorage获取活动数据
    const activityData = localStorage.getItem('currentActivity');
    
    if (activityData) {
        try {
            // 解析JSON数据
            const activity = JSON.parse(activityData);
            // 显示活动详情
            displayActivityDetails(activity);
        } catch (error) {
            console.error('解析活动数据失败:', error);
            showError('无法加载活动详情，请重试');
        }
    } else {
        showError('未找到活动数据，请返回活动列表重试');
    }
});

// 显示活动详情
function displayActivityDetails(activity) {
    const container = document.getElementById('activityDetails');
    
    // 格式化日期
    const formattedDate = formatDate(activity.time);
    
    // 创建活动详情HTML
    const activityHTML = `
        <div class="activity-header">
            <h2 class="activity-title">${activity.name}</h2>
            <div class="activity-meta">
                <div class="meta-item">
                    <i class="fas fa-building"></i>
                    <span>${activity.clubName}</span>
                </div>
                <div class="meta-item">
                    <i class="fas fa-calendar-alt"></i>
                    <span>${formattedDate}</span>
                </div>
                <div class="meta-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${activity.location}</span>
                </div>
                <div class="meta-item">
                    <i class="fas fa-info-circle"></i>
                    <span class="status-badge ${activity.status}">${getStatusText(activity.status)}</span>
                </div>
            </div>
        </div>
        
        <div class="activity-content">
            <div class="content-section">
                <h3><i class="fas fa-align-left"></i> 活动描述</h3>
                <p>${activity.content}</p>
            </div>
            
            <div class="content-section">
                <h3><i class="fas fa-list-alt"></i> 活动信息</h3>
                <div class="meta-item">
                    <i class="fas fa-tags"></i>
                    <span>活动ID: ${activity.id}</span>
                </div>
            </div>
            
            <div class="content-section">
                <h3><i class="fas fa-users"></i> 参与情况</h3>
                <div class="meta-item">
                    <i class="fas fa-user-check"></i>
                    <span>当前参与人数: ${activity.participants} / ${activity.maxParticipants}</span>
                </div>
                <div class="participant-progress">
                    <div class="participant-progress-bar" style="width: ${(activity.participants / activity.maxParticipants) * 100}%"></div>
                </div>
                <div class="meta-item">
                    <i class="fas fa-male"></i>
                    <span>男生: ${activity.genderRatio.male}</span>
                </div>
                <div class="meta-item">
                    <i class="fas fa-female"></i>
                    <span>女生: ${activity.genderRatio.female}</span>
                </div>
            </div>
            
            <div class="activity-actions">
                <button id="joinActivityBtn" class="btn btn-primary" onclick="joinActivity()" ${JSON.parse(localStorage.getItem('joinedActivities') || '[]').includes(activity.id) ? 'disabled' : ''}>
                    <i class="fas fa-plus"></i> ${JSON.parse(localStorage.getItem('joinedActivities') || '[]').includes(activity.id) ? '已参加' : '参加活动'}
                </button>
            </div>
        </div>
    `;
    
    // 插入HTML到容器中
    container.innerHTML = activityHTML;
}

// 格式化日期函数
function formatDate(dateString) {
    const date = new Date(dateString);
    
    // 获取年、月、日
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    
    // 获取小时和分钟
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}`;
}

// 获取状态文本
function getStatusText(status) {
    const statusMap = {
        'ongoing': '进行中',
        'upcoming': '即将开始',
        'completed': '已结束'
    };
    
    return statusMap[status] || status;
}

// 显示错误信息
function showError(message) {
    const container = document.getElementById('activityDetails');
    
    const errorHTML = `
        <div class="error-container" style="text-align: center; padding: 40px 20px; color: #ef4444;">
            <i class="fas fa-exclamation-circle" style="font-size: 48px; margin-bottom: 16px;"></i>
            <h3 style="margin-bottom: 12px;">错误</h3>
            <p>${message}</p>
            <button onclick="window.history.back()" class="btn btn-secondary" style="margin-top: 20px;">
                <i class="fas fa-arrow-left"></i> 返回活动列表
            </button>
        </div>
    `;
    
    container.innerHTML = errorHTML;
}

// 参加活动功能
function joinActivity() {
    // 从localStorage获取当前活动数据
    const activityData = localStorage.getItem('currentActivity');
    
    if (activityData) {
        try {
            const activity = JSON.parse(activityData);
            
            // 获取用户已参加的活动列表
            const joinedActivities = JSON.parse(localStorage.getItem('joinedActivities') || '[]');
            
            // 检查是否已经参加过该活动
            if (joinedActivities.includes(activity.id)) {
                alert('您已经参加过该活动了');
                return;
            }
            
            // 检查活动是否已结束
            if (activity.status === 'completed') {
                alert('该活动已结束，无法参加');
                return;
            }
            
            // 检查是否已达到人数上限
            if (activity.participants >= activity.maxParticipants) {
                alert('该活动已达到人数上限，无法参加');
                return;
            }
            
            // 随机增加男生或女生（这里简单模拟，实际应用中应该根据用户信息确定）
            const randomGender = Math.random() > 0.5 ? 'male' : 'female';
            
            // 更新参与人数和性别比例
            activity.participants++;
            activity.genderRatio[randomGender]++;
            
            // 更新localStorage中的活动数据
            localStorage.setItem('currentActivity', JSON.stringify(activity));
            
            // 更新已参加活动列表
            joinedActivities.push(activity.id);
            localStorage.setItem('joinedActivities', JSON.stringify(joinedActivities));
            
            // 重新显示活动详情
            displayActivityDetails(activity);
            
            // 显示成功消息
            alert('成功参加活动！');
            
        } catch (error) {
            console.error('参加活动失败:', error);
            alert('参加活动失败，请重试');
        }
    } else {
        alert('未找到活动数据，请返回活动列表重试');
    }
}