// 主页交互脚本
document.addEventListener('DOMContentLoaded', () => {
  // 学生登录跳转
  const adminBtn = document.querySelector('#adminLoginBtn');
  if (adminBtn) {
    adminBtn.addEventListener('click', () => {
      window.location.href = 'indexTwo.html';
    });
  }

  // 社团卡片滚动出现动画（保持原逻辑可复用）
  const cards = document.querySelectorAll('.club-card');
  if (cards.length > 0) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    cards.forEach(card => observer.observe(card));
  }

  // 登录表单验证和密码显示功能
  const loginBtn = document.querySelector('.login-btn');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const togglePasswordBtn = document.getElementById('togglePassword');
  const usernameError = document.getElementById('usernameError');
  const passwordError = document.getElementById('passwordError');
  const generalError = document.getElementById('generalError');
  
  // 滑动验证相关元素
  const overlay = document.getElementById('verifyOverlay');
  const slider = document.getElementById('verifySlider');
  const handle = document.getElementById('sliderHandle');
  const fill = document.getElementById('sliderFill');
  const text = document.getElementById('sliderText');
  const closeBtn = document.querySelector('.verify-close');

  // 滑动验证变量
  let dragging = false;
  let startX = 0;
  let currentX = 0;
  let maxX = 0;
  let success = false;
  let startTime = 0;
  // 最小滑动时间（毫秒），确保用户必须慢速拖动
  const minDragTime = 800;

  const resetSlider = () => {
    success = false;
    currentX = 0;
    if (handle) handle.style.transform = 'translateX(0)';
    if (fill) fill.style.width = '46px';
    if (text) text.textContent = '按住滑块拖动';
    if (slider) slider.classList.remove('success');
  };

  const closeModal = () => {
    overlay?.classList.remove('show');
    resetSlider();
  };

  const openModal = () => {
    if (!overlay) return;
    resetSlider();
    overlay.classList.add('show');
    // 计算最大位移
    if (slider && handle) {
      const sliderRect = slider.getBoundingClientRect();
      const handleRect = handle.getBoundingClientRect();
      maxX = sliderRect.width - handleRect.width - 4;
    }
  };

  const complete = () => {
    if (success) return;
    success = true;
    if (handle) handle.style.transform = `translateX(${maxX}px)`;
    if (fill) fill.style.width = '100%';
    if (text) text.textContent = '验证通过，正在跳转...';
    slider?.classList.add('success');
    setTimeout(() => {
      window.location.href = 'systemc.html'; // 学生登录跳转到systemc.html
    }, 250);
  };

  const onMove = (clientX) => {
    if (!dragging || success || !slider || !handle || !fill) return;
    const newX = Math.max(0, Math.min(clientX - startX, maxX));
    currentX = newX;
    handle.style.transform = `translateX(${newX}px)`;
    fill.style.width = `${newX + handle.offsetWidth}px`;
    if (newX >= maxX - 3) {
      const currentTime = Date.now();
      const dragDuration = currentTime - startTime;
      // 检查滑动时间是否足够长
      if (dragDuration >= minDragTime) {
        complete();
      }
    }
  };

  handle?.addEventListener('mousedown', (e) => {
    if (success) return;
    dragging = true;
    startTime = Date.now(); // 记录开始滑动时间
    const rect = handle.getBoundingClientRect();
    startX = e.clientX - rect.left + rect.width / 2;
  });
  document.addEventListener('mousemove', (e) => onMove(e.clientX));
  document.addEventListener('mouseup', () => {
    if (!dragging || success) {
      dragging = false;
      return;
    }
    dragging = false;
    resetSlider();
  });

  // 触摸支持
  handle?.addEventListener('touchstart', (e) => {
    if (success) return;
    const touch = e.touches[0];
    dragging = true;
    startTime = Date.now(); // 记录开始滑动时间
    const rect = handle.getBoundingClientRect();
    startX = touch.clientX - rect.left + rect.width / 2;
  }, { passive: true });
  document.addEventListener('touchmove', (e) => {
    const touch = e.touches[0];
    onMove(touch.clientX);
  }, { passive: true });
  document.addEventListener('touchend', () => {
    if (!dragging || success) {
      dragging = false;
      return;
    }
    dragging = false;
    resetSlider();
  });

  overlay?.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });
  closeBtn?.addEventListener('click', closeModal);

  // 密码显示/隐藏功能
  togglePasswordBtn?.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    
    // 切换眼睛图标
    const svgPath = togglePasswordBtn.querySelector('svg path:nth-child(2)');
    if (type === 'text') {
      // 显示密码时，使用闭眼图标
      svgPath.setAttribute('d', 'M32 18c7.7 0 14 6.3 14 14s-6.3 14-14 14-14-6.3-14-14 6.3-14 14-14zm0 24c5.5 0 10-4.5 10-10s-4.5-10-10-10-10 4.5-10 10 4.5 10 10 10z');
    } else {
      // 隐藏密码时，使用睁眼图标
      svgPath.setAttribute('d', 'M43.8 16.4L30.3 28.2c-1.2 1-2.7 1.7-4.3 1.7s-3.1-.7-4.3-1.7L20.2 16.4c-2.1-1.8-5.7-1-7.4.9-1.7 1.9-1.8 4.7-.2 6.8l10.2 11.8c1.2 1.4 2.9 2.1 4.6 2.1 1.7 0 3.4-.7 4.6-2.1l10.2-11.8c1.6-1.9 1.5-4.7-.2-6.8-1.6-1.9-5.1-2.8-7.2-.9zM32 24c1.7 0 3-1.3 3-3s-1.3-3-3-3-3 1.3-3 3 1.3 3 3 3z');
    }
  });

  // 登录表单验证
  const validateForm = () => {
    let isValid = true;
    
    // 清除所有错误信息
    usernameError.textContent = '';
    passwordError.textContent = '';
    generalError.textContent = '';
    usernameError.classList.remove('show');
    passwordError.classList.remove('show');
    generalError.classList.remove('show');
    
    // 验证用户名
    if (!usernameInput.value.trim()) {
      usernameError.textContent = '请填写用户名';
      usernameError.classList.add('show');
      isValid = false;
    }
    
    // 验证密码
    if (!passwordInput.value.trim()) {
      passwordError.textContent = '请填写密码';
      passwordError.classList.add('show');
      isValid = false;
    }
    
    return isValid;
  };

  loginBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    
    // 表单验证
    if (validateForm()) {
      // 获取表单数据
      const username = usernameInput.value.trim();
      const password = passwordInput.value.trim();
      
      // 显示加载状态
      loginBtn.disabled = true;
      loginBtn.textContent = '登录中...';
      
      // 模拟登录请求（因为没有PHP环境）
      // 使用setTimeout模拟网络延迟
      setTimeout(() => {
        // 恢复按钮状态
        loginBtn.disabled = false;
        loginBtn.textContent = '登录';
        
        // 获取localStorage中的用户数据，如果没有则使用默认数据
        let mockUsers = [];
        try {
          const storedUsers = localStorage.getItem('mockUsers');
          if (storedUsers) {
            mockUsers = JSON.parse(storedUsers);
            console.log('使用localStorage中的用户数据:', mockUsers);
          } else {
            // 使用默认的模拟用户数据
            mockUsers = [
              { student_id: '2021001', password: '123456', name: '张三', role: 'member' },
              { student_id: '2021002', password: '123456', name: '李四', role: 'member' },
              { student_id: '2021003', password: '123456', name: '王五', role: 'admin' },
              { student_id: '2021004', password: '123456', name: '赵六', role: 'member' },
              { student_id: 'admin001', password: 'admin123', name: '管理员', role: 'admin' },
              { student_id: 'admin002', password: 'system123', name: '系统管理员', role: 'admin' }
            ];
            console.log('使用默认的模拟用户数据:', mockUsers);
          }
        } catch (error) {
          console.error('读取localStorage失败:', error);
          // 发生错误时使用默认数据
          mockUsers = [
            { student_id: '2021001', password: '123456', name: '张三', role: 'member' },
            { student_id: '2021002', password: '123456', name: '李四', role: 'member' },
            { student_id: 'admin001', password: 'admin123', name: '管理员', role: 'admin' }
          ];
        }
        
        // 验证用户名和密码，只允许学生登录（member）
        const foundUser = mockUsers.find(user => 
          user.student_id === username && user.password === password && user.role === 'member'
        );
        
        if (foundUser) {
          // 登录成功，保存用户信息到localStorage
          localStorage.setItem('currentUser', JSON.stringify(foundUser));
          // 打开滑动验证
          openModal();
        } else {
          // 登录失败，显示错误信息
          generalError.textContent = '账号或密码错误，请重新填写';
          generalError.classList.add('show');
        }
      }, 800); // 模拟800ms的网络延迟
    }
  });
});

