// 校园新闻发布管理系统 JavaScript

// DOM加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 初始化页面
    initPage();
    
    // 绑定事件
    bindEvents();
    
    // 加载默认数据
    loadDefaultData();
    
    // 加载现有数据
    loadNewsList();
    loadCategoryList();
    loadCommentsList();
    loadCollegeNewsList();
    updateStatistics();
    
    // 默认显示首页板块
    switchSection('home');
});

// 初始化页面
function initPage() {
    // 设置当前日期
    const currentDate = new Date();
    const dateString = currentDate.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long'
    });
    document.getElementById('currentDate').textContent = dateString;
}

// 切换板块
function switchSection(sectionId) {
    // 获取main元素
    const mainElement = document.querySelector('.admin-dashboard');
    
    // 隐藏所有主要板块和首页内容
    const sections = [
        'welcome-section',
        'stats-section',
        'profile-section',
        'news-section',
        'news-list-section',
        'categories-section',
        'comments-section'
    ];
    
    // 隐藏所有section
    sections.forEach(section => {
        const element = document.querySelector(`.${section}`);
        if (element) {
            element.classList.add('hidden');
        }
    });
    
    // 隐藏所有带id的板块
    const idSections = ['home', 'profile', 'categories', 'comments', 'news', 'about', 'contact', 'department-news', 'contacts', 'recycle-bin', 'settings'];
    idSections.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.classList.add('hidden');
        }
    });
    
    // 显示选中的板块
    if (sectionId === 'home') {
        // 隐藏main元素
        if (mainElement) {
            mainElement.classList.add('hidden');
        }
        // 显示首页内容
        const homeContent = document.getElementById('home');
        if (homeContent) {
            homeContent.classList.remove('hidden');
        }
        // 显示新闻列表板块（因为它现在在首页）
        const newsListSection = document.querySelector('.news-list-section');
        if (newsListSection) {
            newsListSection.classList.remove('hidden');
        }
        // 确保轮播图正常工作
        initCarousel();
        // 渲染首页新闻板块
        renderHomeNews();
    } else {
        // 显示main元素
        if (mainElement) {
            mainElement.classList.remove('hidden');
        }
        
        if (sectionId === 'news') {
            // 新闻管理板块需要显示两个部分
            document.getElementById('news').classList.remove('hidden'); // 使用id选择器确保选择正确的新闻发布板块
            document.querySelector('.news-list-section').classList.remove('hidden');
            document.querySelector('.welcome-section').classList.remove('hidden');
            document.querySelector('.stats-section').classList.remove('hidden');
        } else if (sectionId === 'profile') {
            document.getElementById('profile').classList.remove('hidden');
        } else if (sectionId === 'categories') {
            document.getElementById('categories').classList.remove('hidden');
        } else if (sectionId === 'comments') {
            document.getElementById('comments').classList.remove('hidden');
        } else if (sectionId === 'about') {
            document.getElementById('about').classList.remove('hidden');
        } else if (sectionId === 'contact') {
            document.getElementById('contact').classList.remove('hidden');
        } else if (sectionId === 'department-news') {
            document.getElementById('department-news').classList.remove('hidden');
        } else if (sectionId === 'contacts') {
            document.getElementById('contacts').classList.remove('hidden');
        } else if (sectionId === 'recycle-bin') {
            document.getElementById('recycle-bin').classList.remove('hidden');
        } else if (sectionId === 'settings') {
            document.getElementById('settings').classList.remove('hidden');
        }
    }
    
    // 更新导航链接的激活状态
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
        }
    });
}

// 绑定事件
function bindEvents() {
    // 导航链接点击事件
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const href = this.getAttribute('href');
            if (href.startsWith('#')) {
                const sectionId = href.substring(1);
                switchSection(sectionId);
            }
        });
    });
    
    // 新闻发布表单提交
    const newsForm = document.getElementById('newsForm');
    newsForm.addEventListener('submit', function(e) {
        e.preventDefault();
        publishNews();
    });
    
    // 新闻图片预览
    const newsImage = document.getElementById('newsImage');
    newsImage.addEventListener('change', function() {
        previewImage(this);
    });
    
    // 新闻搜索
    const searchBtn = document.getElementById('searchBtn');
    const searchNews = document.getElementById('searchNews');
    
    // 跳转到search.html进行搜索
    function redirectToSearch(searchTerm) {
        if (searchTerm.trim()) {
            window.location.href = `search.html?q=${encodeURIComponent(searchTerm.trim())}`;
        }
    }
    
    searchBtn.addEventListener('click', function() {
        redirectToSearch(searchNews.value);
    });
    
    searchNews.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            redirectToSearch(this.value);
        }
    });
    
    // 类别管理表单提交
    const categoryForm = document.getElementById('categoryForm');
    categoryForm.addEventListener('submit', function(e) {
        e.preventDefault();
        addCategory();
    });
    
    // 退出登录按钮点击事件
    const logoutBtn = document.getElementById('logoutBtn');
    logoutBtn.addEventListener('click', function() {
        logout();
    });
    
    // 分页指示器点击事件
    const paginationDots = document.querySelectorAll('.pagination-dot');
    paginationDots.forEach(dot => {
        dot.addEventListener('click', function() {
            const pageIndex = parseInt(this.dataset.page);
            switchAboutPage(pageIndex);
        });
    });
}

// 切换关于系统页面
function switchAboutPage(pageIndex) {
    // 隐藏所有页面
    const pages = document.querySelectorAll('.about-page');
    pages.forEach(page => {
        page.classList.remove('active');
    });
    
    // 显示当前页面
    const currentPage = pages[pageIndex];
    if (currentPage) {
        currentPage.classList.add('active');
    }
    
    // 更新dot状态
    const dots = document.querySelectorAll('.pagination-dot');
    dots.forEach(dot => {
        dot.classList.remove('active');
    });
    
    const currentDot = dots[pageIndex];
    if (currentDot) {
        currentDot.classList.add('active');
    }
}

// 退出登录功能
function logout() {
    // 显示确认对话框
    if (confirm('确定要退出登录吗？')) {
        // 清除用户登录状态（如果有）
        localStorage.removeItem('currentUser');
        
        // 跳转到index.html页面
        window.location.href = 'index.html';
    }
}

// 发布新闻
function publishNews() {
    // 获取表单数据
    const title = document.getElementById('newsTitle').value;
    const newsType = document.getElementById('newsType').value;
    const category = document.getElementById('newsCategory').value;
    const author = document.getElementById('newsAuthor').value;
    const content = document.getElementById('newsContent').value;
    const status = document.getElementById('newsStatus').value;
    const image = document.getElementById('newsImage').files[0];
    
    // 创建新闻对象
    const newsData = {
        id: Date.now(),
        title: title,
        type: newsType,
        category: category,
        author: author,
        content: content,
        status: status,
        date: new Date().toLocaleDateString('zh-CN'),
        time: new Date().toLocaleTimeString('zh-CN'),
        views: 0,
        comments: [],
        image: image ? URL.createObjectURL(image) : ''
    };
    
    // 保存到localStorage
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    newsList.push(newsData);
    localStorage.setItem('campusNews', JSON.stringify(newsList));
    
    // 显示成功通知
    showNotification('新闻发布成功！', 'success');
    
    // 重置表单
    document.getElementById('newsForm').reset();
    document.getElementById('imagePreview').textContent = '';
    
    // 更新新闻列表和统计
    loadNewsList();
    updateStatistics();
}



// 加载新闻列表
function loadNewsList() {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    const newsListElement = document.getElementById('newsList');
    
    if (newsList.length === 0) {
        newsListElement.innerHTML = '<p class="no-data">暂无新闻数据</p>';
        return;
    }
    
    // 按时间倒序排列
    newsList.sort((a, b) => b.id - a.id);
    
    // 渲染新闻列表
    newsListElement.innerHTML = newsList.map(news => `
        <div class="news-item" data-id="${news.id}">
            <div class="news-header">
                <h3>${news.title}</h3>
                <span class="news-status ${news.status}">${news.status === 'published' ? '已发布' : '草稿'}</span>
            </div>
            <div class="news-meta">
                <span class="news-type">${news.type === 'news' ? '新闻' : '公告'}</span>
                <span class="news-category">${news.category}</span>
                <span class="news-author">${news.author}</span>
                <span class="news-date">${news.date} ${news.time}</span>
                <span class="news-views"><i class="fas fa-eye"></i> ${news.views}</span>
                <span class="news-comments"><i class="fas fa-comments"></i> ${news.comments.length}</span>
            </div>
            ${news.image ? `<div class="news-image"><img src="${news.image}" alt="新闻图片"></div>` : ''}
            <div class="news-content">${news.content.substring(0, 100)}...</div>
            <div class="news-actions">
                <button class="btn btn-view" onclick="viewNews(${news.id})">
                    <i class="fas fa-eye"></i> 查看
                </button>
                <button class="btn btn-edit" onclick="editNews(${news.id})">
                    <i class="fas fa-edit"></i> 编辑
                </button>
                <button class="btn btn-delete" onclick="deleteNews(${news.id})">
                    <i class="fas fa-trash"></i> 删除
                </button>
            </div>
        </div>
    `).join('');
}

// 搜索新闻列表
function searchNewsList(keyword) {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    const newsListElement = document.getElementById('newsList');
    
    if (!keyword) {
        loadNewsList();
        return;
    }
    
    // 搜索匹配的新闻
    const filteredNews = newsList.filter(news => 
        news.title.includes(keyword) || 
        news.content.includes(keyword) ||
        news.author.includes(keyword) ||
        news.category.includes(keyword)
    );
    
    if (filteredNews.length === 0) {
        newsListElement.innerHTML = '<p class="no-data">没有找到匹配的新闻</p>';
        return;
    }
    
    // 渲染搜索结果
    newsListElement.innerHTML = filteredNews.map(news => `
        <div class="news-item" data-id="${news.id}">
            <div class="news-header">
                <h3>${news.title}</h3>
                <span class="news-status ${news.status}">${news.status === 'published' ? '已发布' : '草稿'}</span>
            </div>
            <div class="news-meta">
                <span class="news-type">${news.type === 'news' ? '新闻' : '公告'}</span>
                <span class="news-category">${news.category}</span>
                <span class="news-author">${news.author}</span>
                <span class="news-date">${news.date} ${news.time}</span>
                <span class="news-views"><i class="fas fa-eye"></i> ${news.views}</span>
                <span class="news-comments"><i class="fas fa-comments"></i> ${news.comments.length}</span>
            </div>
            ${news.image ? `<div class="news-image"><img src="${news.image}" alt="新闻图片"></div>` : ''}
            <div class="news-content">${news.content.substring(0, 100)}...</div>
            <div class="news-actions">
                <button class="btn btn-view" onclick="viewNews(${news.id})">
                    <i class="fas fa-eye"></i> 查看
                </button>
                <button class="btn btn-edit" onclick="editNews(${news.id})">
                    <i class="fas fa-edit"></i> 编辑
                </button>
                <button class="btn btn-delete" onclick="deleteNews(${news.id})">
                    <i class="fas fa-trash"></i> 删除
                </button>
            </div>
        </div>
    `).join('');
}

// 查看新闻
function viewNews(newsId) {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    const news = newsList.find(n => n.id === newsId);
    
    if (news) {
        // 增加浏览量
        news.views++;
        localStorage.setItem('campusNews', JSON.stringify(newsList));
        updateStatistics();
        loadNewsList();
        
        // 这里可以扩展为弹窗查看完整新闻
        showNotification('查看新闻功能开发中...', 'info');
    }
}

// 编辑新闻
function editNews(newsId) {
    showNotification('编辑新闻功能开发中...', 'info');
}

// 删除新闻
function deleteNews(newsId) {
    if (confirm('确定要删除这条新闻吗？')) {
        let newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
        newsList = newsList.filter(n => n.id !== newsId);
        localStorage.setItem('campusNews', JSON.stringify(newsList));
        
        showNotification('新闻删除成功！', 'success');
        loadNewsList();
        updateStatistics();
        loadCommentsList(); // 更新评论列表
    }
}

// 添加类别
function addCategory() {
    const categoryName = document.getElementById('categoryName').value;
    const categoryDescription = document.getElementById('categoryDescription').value;
    
    if (!categoryName) {
        showNotification('请输入类别名称！', 'error');
        return;
    }
    
    // 创建类别对象
    const category = {
        id: Date.now(),
        name: categoryName,
        description: categoryDescription,
        createdAt: new Date().toLocaleString('zh-CN')
    };
    
    // 保存到localStorage
    const categories = JSON.parse(localStorage.getItem('campusCategories')) || [];
    categories.push(category);
    localStorage.setItem('campusCategories', JSON.stringify(categories));
    
    // 更新类别选择下拉框
    updateCategorySelect();
    
    // 显示成功通知
    showNotification('类别添加成功！', 'success');
    
    // 重置表单
    document.getElementById('categoryForm').reset();
    
    // 更新类别列表
    loadCategoryList();
    updateStatistics();
}

// 加载类别列表
function loadCategoryList() {
    const categories = JSON.parse(localStorage.getItem('campusCategories')) || [];
    const categoryListElement = document.getElementById('categoryList');
    
    if (categories.length === 0) {
        categoryListElement.innerHTML = '<p class="no-data">暂无类别数据</p>';
        return;
    }
    
    // 渲染类别列表
    categoryListElement.innerHTML = categories.map(category => `
        <div class="category-item" data-id="${category.id}">
            <div class="category-header">
                <h3>${category.name}</h3>
                <div class="category-actions">
                    <button class="btn btn-edit" onclick="editCategory(${category.id})">
                        <i class="fas fa-edit"></i> 编辑
                    </button>
                    <button class="btn btn-delete" onclick="deleteCategory(${category.id})">
                        <i class="fas fa-trash"></i> 删除
                    </button>
                </div>
            </div>
            <div class="category-description">${category.description || '无描述'}</div>
            <div class="category-meta">
                <span>创建时间：${category.createdAt}</span>
            </div>
        </div>
    `).join('');
}



// 编辑类别
function editCategory(categoryId) {
    showNotification('编辑类别功能开发中...', 'info');
}

// 删除类别
function deleteCategory(categoryId) {
    if (confirm('确定要删除这个类别吗？')) {
        let categories = JSON.parse(localStorage.getItem('campusCategories')) || [];
        categories = categories.filter(c => c.id !== categoryId);
        localStorage.setItem('campusCategories', JSON.stringify(categories));
        
        showNotification('类别删除成功！', 'success');
        loadCategoryList();
        updateCategorySelect();
        updateStatistics();
    }
}

// 加载评论列表
function loadCommentsList() {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    const commentsListElement = document.getElementById('commentsList');
    
    // 收集所有评论
    let allComments = [];
    newsList.forEach(news => {
        if (news.comments && news.comments.length > 0) {
            news.comments.forEach(comment => {
                allComments.push({
                    ...comment,
                    newsId: news.id,
                    newsTitle: news.title
                });
            });
        }
    });
    
    if (allComments.length === 0) {
        commentsListElement.innerHTML = '<p class="no-data">暂无评论数据</p>';
        return;
    }
    
    // 按时间倒序排列
    allComments.sort((a, b) => b.id - a.id);
    
    // 渲染评论列表
    commentsListElement.innerHTML = allComments.map(comment => `
        <div class="comment-item" data-id="${comment.id}" data-news-id="${comment.newsId}">
            <div class="comment-header">
                <div class="comment-author">${comment.author}</div>
                <div class="comment-date">${comment.date}</div>
            </div>
            <div class="comment-news">
                <span class="comment-news-label">所属新闻：</span>
                <a href="#" onclick="viewNews(${comment.newsId})">${comment.newsTitle}</a>
            </div>
            <div class="comment-content">${comment.content}</div>
            <div class="comment-actions">
                <button class="btn btn-approve" onclick="approveComment(${comment.id}, ${comment.newsId})">
                    <i class="fas fa-check"></i> 批准
                </button>
                <button class="btn btn-delete" onclick="deleteComment(${comment.id}, ${comment.newsId})">
                    <i class="fas fa-trash"></i> 删除
                </button>
            </div>
        </div>
    `).join('');
}

// 批准评论
function approveComment(commentId, newsId) {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    const news = newsList.find(n => n.id === newsId);
    
    if (news && news.comments) {
        const comment = news.comments.find(c => c.id === commentId);
        if (comment) {
            comment.approved = true;
            localStorage.setItem('campusNews', JSON.stringify(newsList));
            showNotification('评论批准成功！', 'success');
            loadCommentsList();
        }
    }
}

// 删除评论
function deleteComment(commentId, newsId) {
    if (confirm('确定要删除这条评论吗？')) {
        const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
        const news = newsList.find(n => n.id === newsId);
        
        if (news && news.comments) {
            news.comments = news.comments.filter(c => c.id !== commentId);
            localStorage.setItem('campusNews', JSON.stringify(newsList));
            
            showNotification('评论删除成功！', 'success');
            loadCommentsList();
            updateStatistics();
        }
    }
}

// 加载默认数据
function loadDefaultData() {
    // 检查是否已存在数据
    if (localStorage.getItem('campusNews') || localStorage.getItem('campusCategories')) {
        return;
    }
    
    // 默认新闻数据
    const defaultNews = [
        {            id: 1634567890001,            title: '我校举办2025年秋季运动会',            category: '校园动态',            author: '校学生会',            content: '10月15日至16日，我校2025年秋季运动会在田径场隆重举行。来自全校20个学院的3000余名运动员参加了田径、球类、趣味项目等30余个比赛项目的角逐。运动会期间，运动员们奋勇争先，充分展现了我校学生的青春活力和体育精神。',            status: 'published',            date: '2025-10-17',            time: '14:30',            views: 1234,            comments: [                {                    id: 1001,                    author: '学生张三',                    content: '运动会非常精彩，我们学院获得了团体总分第二名！',                    date: '2025-10-17 15:45',                    approved: true                },                {                    id: 1002,                    author: '教师李四',                    content: '看到同学们的精彩表现，感到非常欣慰！',                    date: '2025-10-17 16:30',                    approved: true                }            ],            image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&h=400&fit=crop'        },
        {            id: 1634567890002,            title: '我校新增3个国家级一流本科专业建设点',            category: '教学科研',            author: '教务处',            content: '近日，教育部公布了2025年度国家级和省级一流本科专业建设点名单，我校申报的计算机科学与技术、电子信息工程、汉语言文学3个专业获批国家级一流本科专业建设点。至此，我校国家级一流本科专业建设点总数达到12个，省级一流本科专业建设点达到18个，专业建设水平迈上新台阶。',            status: 'published',            date: '2025-10-15',            time: '10:00',            views: 892,            comments: [                {                    id: 2001,                    author: '学生王五',                    content: '恭喜计算机专业成为国家级一流专业！',                    date: '2025-10-15 11:20',                    approved: true                }            ],            image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800&h=400&fit=crop'        },
        {
            id: 1634567890003,
            title: '校园冬季安全教育讲座通知',
            category: '通知公告',
            author: '保卫处',
            content: '为加强校园冬季安全管理，提高师生安全意识，学校定于10月20日下午2:30在学术报告厅举办冬季安全教育讲座，邀请市公安局消防支队专家进行专题讲解。讲座内容包括：冬季防火安全、用电安全、交通安全、防盗防骗等。请各学院组织师生参加，确保校园安全稳定。',
            status: 'published',
            date: '2025-10-18',
            time: '09:15',
            views: 567,
            comments: [],
            image: ''
        },
        {
            id: 1634567890004,
            title: '我校大学生创新创业大赛取得优异成绩',
            category: '学生活动',
            author: '创新创业中心',
            content: '在刚刚结束的2025年大学生创新创业大赛中，我校参赛团队表现优异，共获得国家级金奖1项、银奖2项、铜奖3项，省级金奖5项、银奖8项、铜奖12项。其中，"智能校园服务平台"项目获得国家级金奖，实现了我校在该项赛事中的历史性突破。',
            status: 'published',
            date: '2025-10-19',
            time: '16:45',
            views: 789,
            comments: [
                {
                    id: 3001,
                    author: '学生赵六',
                    content: '太棒了！为参赛团队感到骄傲！',
                    date: '2025-10-19 17:30',
                    approved: true
                }
            ],
            image: ''
        },
        {
            id: 1634567890005,
            title: '校园文化节活动安排',
            category: '校园文化',
            author: '团委',
            content: '为丰富校园文化生活，展现我校师生的艺术才华，学校定于11月1日至11月15日举办2025年校园文化节。文化节期间将开展文艺汇演、书画展览、摄影比赛、辩论赛、演讲比赛等一系列活动。欢迎广大师生积极参与，共同营造浓厚的校园文化氛围。',
            status: 'published',
            date: '2025-10-20',
            time: '14:00',
            views: 456,
            comments: [],
            image: ''
        }
    ];
    
    // 默认类别数据
    const defaultCategories = [
        {
            id: 10001,
            name: '校园动态',
            description: '校园最新动态和新闻',
            createdAt: '2025-09-01 09:00'
        },
        {
            id: 10002,
            name: '教学科研',
            description: '教学改革和科研成果',
            createdAt: '2025-09-01 09:00'
        },
        {
            id: 10003,
            name: '学生活动',
            description: '学生组织和校园活动',
            createdAt: '2025-09-01 09:00'
        },
        {
            id: 10004,
            name: '通知公告',
            description: '学校通知和公告信息',
            createdAt: '2025-09-01 09:00'
        },
        {
            id: 10005,
            name: '校园文化',
            description: '校园文化和艺术活动',
            createdAt: '2025-09-01 09:00'
        }
    ];
    
    // 保存默认数据
    localStorage.setItem('campusNews', JSON.stringify(defaultNews));
    localStorage.setItem('campusCategories', JSON.stringify(defaultCategories));
}

// 更新类别选择下拉框
function updateCategorySelect() {
    const categories = JSON.parse(localStorage.getItem('campusCategories')) || [];
    const categorySelect = document.getElementById('newsCategory');
    
    // 保存当前选中值
    const currentValue = categorySelect.value;
    
    // 清除现有选项（保留第一个提示选项）
    categorySelect.innerHTML = '<option value="">请选择类别</option>';
    
    // 添加新选项
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.name;
        option.textContent = category.name;
        categorySelect.appendChild(option);
    });
    
    // 恢复选中值
    categorySelect.value = currentValue;
}

// 更新统计信息
function updateStatistics() {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    const categories = JSON.parse(localStorage.getItem('campusCategories')) || [];
    
    // 统计总新闻数
    const totalNews = newsList.length;
    document.getElementById('totalNews').textContent = totalNews;
    
    // 统计总评论数
    let totalComments = 0;
    newsList.forEach(news => {
        if (news.comments && news.comments.length > 0) {
            totalComments += news.comments.length;
        }
    });
    document.getElementById('totalComments').textContent = totalComments;
    
    // 统计类别数
    document.getElementById('totalCategories').textContent = categories.length;
    
    // 统计总浏览量
    let totalViews = 0;
    newsList.forEach(news => {
        totalViews += news.views || 0;
    });
    document.getElementById('totalViews').textContent = totalViews;
}

// 显示通知
function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'block';
    
    // 3秒后自动隐藏
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// 图片预览
function previewImage(input) {
    const preview = document.getElementById('imagePreview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.innerHTML = `<img src="${e.target.result}" alt="预览图片" style="max-width: 200px; max-height: 150px; margin-top: 10px; border-radius: 5px; border: 1px solid #ddd;">`;
        }
        
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.innerHTML = '';
    }
}

// 轮播图功能
let currentSlide = 0;
let slideInterval;

// 初始化轮播图
function initCarousel() {
    // 添加延迟，确保DOM元素完全渲染
    setTimeout(() => {
        const slides = document.querySelectorAll('.carousel-item');
        const indicators = document.querySelectorAll('.indicator');
        
        if (slides.length === 0 || indicators.length === 0) return;
        
        // 先停止之前的自动轮播，确保只有一个计时器在运行
        stopSlide();
        
        // 确保currentSlide在有效范围内
        currentSlide = Math.max(0, Math.min(currentSlide, slides.length - 1));
        
        // 先移除所有轮播项和导航点的active类
        slides.forEach(slide => slide.classList.remove('active'));
        indicators.forEach(indicator => indicator.classList.remove('active'));
        
        // 初始化显示状态
        if (slides[currentSlide]) {
            slides[currentSlide].classList.add('active');
        }
        if (indicators[currentSlide]) {
            indicators[currentSlide].classList.add('active');
        }
        
        // 开始自动轮播
        startSlide();
    }, 100);
}

// 上一张幻灯片
function prevSlide() {
    const slides = document.querySelectorAll('.carousel-item');
    const indicators = document.querySelectorAll('.indicator');
    
    if (slides.length === 0 || indicators.length === 0) return;
    
    // 移除当前轮播项和导航点的active类
    if (slides[currentSlide]) {
        slides[currentSlide].classList.remove('active');
    }
    if (indicators[currentSlide]) {
        indicators[currentSlide].classList.remove('active');
    }
    
    // 计算上一个轮播项的索引
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    
    // 为新的轮播项和导航点添加active类
    if (slides[currentSlide]) {
        slides[currentSlide].classList.add('active');
    } else {
        // 如果currentSlide索引无效，重新设置为最后一个索引
        currentSlide = slides.length - 1;
        if (slides[currentSlide]) {
            slides[currentSlide].classList.add('active');
        }
    }
    
    if (indicators[currentSlide]) {
        indicators[currentSlide].classList.add('active');
    } else if (indicators[indicators.length - 1]) {
        indicators[indicators.length - 1].classList.add('active');
    }
    
    // 重置自动轮播
    stopSlide();
    startSlide();
}

// 下一张幻灯片
function nextSlide() {
    const slides = document.querySelectorAll('.carousel-item');
    const indicators = document.querySelectorAll('.indicator');
    
    if (slides.length === 0 || indicators.length === 0) return;
    
    // 移除当前轮播项和导航点的active类
    if (slides[currentSlide]) {
        slides[currentSlide].classList.remove('active');
    }
    if (indicators[currentSlide]) {
        indicators[currentSlide].classList.remove('active');
    }
    
    // 计算下一个轮播项的索引
    currentSlide = (currentSlide + 1) % slides.length;
    
    // 为新的轮播项和导航点添加active类
    if (slides[currentSlide]) {
        slides[currentSlide].classList.add('active');
    } else {
        // 如果currentSlide索引无效，重新设置为0
        currentSlide = 0;
        if (slides[currentSlide]) {
            slides[currentSlide].classList.add('active');
        }
    }
    
    if (indicators[currentSlide]) {
        indicators[currentSlide].classList.add('active');
    } else if (indicators[0]) {
        indicators[0].classList.add('active');
    }
    
    // 重置自动轮播
    stopSlide();
    startSlide();
}

// 跳转到指定幻灯片
function goToSlide(n) {
    const slides = document.querySelectorAll('.carousel-item');
    const indicators = document.querySelectorAll('.indicator');
    
    if (slides.length === 0 || indicators.length === 0) return;
    
    // 验证索引范围
    if (n < 0 || n >= slides.length) {
        n = 0;
    }
    
    // 移除当前轮播项和导航点的active类
    if (slides[currentSlide]) {
        slides[currentSlide].classList.remove('active');
    }
    if (indicators[currentSlide]) {
        indicators[currentSlide].classList.remove('active');
    }
    
    // 设置新的轮播项索引
    currentSlide = n;
    
    // 为新的轮播项和导航点添加active类
    if (slides[currentSlide]) {
        slides[currentSlide].classList.add('active');
    }
    
    if (indicators[currentSlide]) {
        indicators[currentSlide].classList.add('active');
    }
    
    // 重置自动轮播
    stopSlide();
    startSlide();
}

// 开始自动轮播
function startSlide() {
    // 确保只有一个计时器在运行
    stopSlide();
    slideInterval = setInterval(nextSlide, 5000);
}

// 停止自动轮播
function stopSlide() {
    clearInterval(slideInterval);
    slideInterval = null;
}

// 首页新闻数据渲染
function renderHomeNews() {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    
    // 按浏览量排序，取前3条作为热点新闻
    const hotNews = [...newsList].sort((a, b) => b.views - a.views).slice(0, 3);
    
    // 筛选通知公告类新闻，取前3条
    const announcements = newsList.filter(news => news.category === '通知公告').slice(0, 3);
    
    // 筛选学生活动类新闻，取前3条
    const activities = newsList.filter(news => news.category === '学生活动' || news.category === '校园文化').slice(0, 3);
    
    // 渲染热点新闻
    renderNewsGrid('hotNewsGrid', hotNews);
    
    // 渲染通知公告
    renderNewsGrid('announcementGrid', announcements);
    
    // 渲染活动举办
    renderNewsGrid('activityGrid', activities);
    
    // 渲染新闻列表（现在在首页）
    renderHomeNewsList();
}

// 渲染新闻网格
function renderNewsGrid(gridId, newsData) {
    const grid = document.getElementById(gridId);
    if (!grid) return;
    
    if (newsData.length === 0) {
        grid.innerHTML = '<p class="no-news">暂无相关新闻</p>';
        return;
    }
    
    grid.innerHTML = newsData.map(news => `
        <div class="news-card">
            ${news.image ? `<div class="news-card-image"><img src="${news.image}" alt="${news.title}"></div>` : ''}
            <div class="news-card-content">
                <h3 class="news-card-title">${news.title}</h3>
                <p class="news-card-meta">
                    <i class="fas fa-user"></i> ${news.author} | 
                    <i class="fas fa-calendar-alt"></i> ${news.date} | 
                    <i class="fas fa-eye"></i> ${news.views}
                </p>
                <p class="news-card-excerpt">${news.content.substring(0, 100)}...</p>
                <a href="#" class="news-card-link" onclick="viewNews(${news.id})">
                    查看详情 <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
    `).join('');
}

// 渲染首页新闻列表
function renderHomeNewsList() {
    const newsList = JSON.parse(localStorage.getItem('campusNews')) || [];
    const newsListElement = document.getElementById('newsList');
    
    if (!newsListElement) return;
    
    if (newsList.length === 0) {
        newsListElement.innerHTML = '<p class="no-news">暂无新闻数据</p>';
        return;
    }
    
    // 按时间倒序排列
    newsList.sort((a, b) => b.id - a.id);
    
    // 渲染简洁的新闻列表（适合首页显示，不含管理操作）
    newsListElement.innerHTML = newsList.map(news => `
        <div class="news-item" data-id="${news.id}">
            <div class="news-header">
                <h3>${news.title}</h3>
            </div>
            <div class="news-meta">
                <span class="news-category">${news.category}</span>
                <span class="news-author">${news.author}</span>
                <span class="news-date">${news.date}</span>
                <span class="news-views"><i class="fas fa-eye"></i> ${news.views}</span>
                <span class="news-comments"><i class="fas fa-comments"></i> ${news.comments.length}</span>
            </div>
            ${news.image ? `<div class="news-image"><img src="${news.image}" alt="新闻图片"></div>` : ''}
            <div class="news-content">${news.content.substring(0, 150)}...</div>
            <div class="news-actions">
                <button class="btn btn-view" onclick="viewNews(${news.id})"><i class="fas fa-eye"></i> 查看详情</button>
            </div>
        </div>
    `).join('');
}

// 学院新闻管理相关功能

// 加载学院新闻列表
function loadCollegeNewsList() {
    // 从localStorage获取学院新闻数据
    let collegeNews = JSON.parse(localStorage.getItem('collegeNews')) || [];
    
    // 如果没有数据，创建默认数据
    if (collegeNews.length === 0) {
        collegeNews = [
            {
                id: 1,
                title: '计算机学院举办人工智能学术讲座',
                college: '计算机学院',
                author: '李教授',
                content: '计算机学院于10月25日举办了人工智能学术讲座，邀请了清华大学张教授进行主讲。讲座内容包括人工智能的最新发展趋势、应用案例以及未来展望。',
                date: '2025-10-25',
                status: 'pending',
                reply: ''
            },
            {
                id: 2,
                title: '文学院开展经典文学作品朗读比赛',
                college: '文学院',
                author: '王老师',
                content: '文学院于10月20日开展了经典文学作品朗读比赛，来自各年级的30名选手参加了比赛。比赛旨在提高学生的文学素养和朗读能力，营造浓厚的校园文化氛围。',
                date: '2025-10-20',
                status: 'pending',
                reply: ''
            },
            {
                id: 3,
                title: '经济学院与企业合作建立实习基地',
                college: '经济学院',
                author: '赵主任',
                content: '经济学院与多家知名企业合作建立了实习基地，为学生提供了更多的实践机会。实习基地将为学生提供专业培训和实践指导，帮助学生更好地适应未来的职业发展。',
                date: '2025-10-18',
                status: 'pending',
                reply: ''
            }
        ];
        
        // 保存默认数据到localStorage
        localStorage.setItem('collegeNews', JSON.stringify(collegeNews));
    }
    
    // 渲染学院新闻列表
    renderCollegeNewsList(collegeNews);
}

// 渲染学院新闻列表
function renderCollegeNewsList(collegeNews) {
    const collegeNewsListElement = document.getElementById('collegeNewsList');
    
    if (!collegeNewsListElement) return;
    
    if (collegeNews.length === 0) {
        collegeNewsListElement.innerHTML = '<p class="no-data">暂无学院传递的新闻</p>';
        return;
    }
    
    // 按时间倒序排列
    collegeNews.sort((a, b) => b.id - a.id);
    
    // 渲染学院新闻列表
    collegeNewsListElement.innerHTML = collegeNews.map(news => `
        <div class="news-item" data-id="${news.id}">
            <div class="news-header">
                <h3>${news.title}</h3>
                <span class="news-college">${news.college}</span>
            </div>
            <div class="news-meta">
                <span class="news-author">${news.author}</span>
                <span class="news-date">${news.date}</span>
                <span class="news-status ${news.status}">${news.status === 'approved' ? '已审核' : '待审核'}</span>
            </div>
            <div class="news-content">${news.content.substring(0, 100)}...</div>
            ${news.reply ? `<div class="news-reply">
                <strong>回复：</strong>${news.reply}
            </div>` : ''}
            <div class="news-actions">
                <button class="btn btn-approve" onclick="approveCollegeNews(${news.id})">
                    <i class="fas fa-check"></i> 审核
                </button>
                <button class="btn btn-reply" onclick="replyCollegeNews(${news.id})">
                    <i class="fas fa-comment"></i> 回复
                </button>
                <button class="btn btn-push" onclick="pushCollegeNews(${news.id})">
                    <i class="fas fa-share"></i> 推送
                </button>
            </div>
        </div>
    `).join('');
}

// 审核学院新闻
function approveCollegeNews(newsId) {
    let collegeNews = JSON.parse(localStorage.getItem('collegeNews')) || [];
    const newsIndex = collegeNews.findIndex(news => news.id === newsId);
    
    if (newsIndex !== -1) {
        collegeNews[newsIndex].status = collegeNews[newsIndex].status === 'approved' ? 'pending' : 'approved';
        localStorage.setItem('collegeNews', JSON.stringify(collegeNews));
        
        showNotification('新闻审核状态已更新！', 'success');
        loadCollegeNewsList();
    }
}

// 回复学院新闻
function replyCollegeNews(newsId) {
    let collegeNews = JSON.parse(localStorage.getItem('collegeNews')) || [];
    const news = collegeNews.find(news => news.id === newsId);
    
    if (news) {
        const reply = prompt('请输入回复内容：', news.reply || '');
        
        if (reply !== null) {
            news.reply = reply;
            localStorage.setItem('collegeNews', JSON.stringify(collegeNews));
            
            showNotification('新闻回复已保存！', 'success');
            loadCollegeNewsList();
        }
    }
}

// 推送学院新闻到主新闻列表
function pushCollegeNews(newsId) {
    let collegeNews = JSON.parse(localStorage.getItem('collegeNews')) || [];
    const news = collegeNews.find(news => news.id === newsId);
    
    if (news) {
        // 检查是否已经推送过
        if (news.status !== 'approved') {
            showNotification('请先审核通过该新闻！', 'warning');
            return;
        }
        
        // 创建主新闻对象
        const mainNews = {
            id: Date.now(),
            title: news.title,
            category: '校园动态',
            author: news.author,
            content: news.content,
            status: 'published',
            date: new Date().toLocaleDateString('zh-CN'),
            time: new Date().toLocaleTimeString('zh-CN'),
            views: 0,
            comments: [],
            image: ''
        };
        
        // 保存到主新闻列表
        const mainNewsList = JSON.parse(localStorage.getItem('campusNews')) || [];
        mainNewsList.push(mainNews);
        localStorage.setItem('campusNews', JSON.stringify(mainNewsList));
        
        showNotification('新闻已成功推送！', 'success');
        
        // 更新统计信息
        updateStatistics();
        
        // 如果当前在首页，更新首页新闻列表
        if (document.getElementById('home') && !document.getElementById('home').classList.contains('hidden')) {
            renderHomeNewsList();
        }
    }
}
