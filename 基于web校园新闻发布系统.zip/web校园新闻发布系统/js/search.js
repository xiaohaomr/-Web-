// 新闻数据 - 至少20条随机写入的新闻
const newsData = [
    {
        id: 1,
        title: "计算机学院举办人工智能创新大赛",
        type: "college",
        college: "计算机学院",
        date: "2025-12-14",
        excerpt: "计算机学院成功举办了第二届人工智能创新大赛，共有来自全校各学院的50多支队伍参赛，展示了同学们在AI领域的创新能力和实践成果。",
        content: "详细内容：计算机学院成功举办了第二届人工智能创新大赛，共有来自全校各学院的50多支队伍参赛，展示了同学们在AI领域的创新能力和实践成果。比赛分为算法设计、应用开发和创意设计三个赛道，最终有12支队伍脱颖而出，获得了奖项。",
        image: "https://picsum.photos/seed/ai1/600/400"
    },
    {
        id: 2,
        title: "关于2026年春季学期选课的通知",
        type: "announcement",
        college: "教务处",
        date: "2025-12-13",
        excerpt: "教务处发布通知，2026年春季学期选课工作将于12月20日开始，同学们需在规定时间内完成选课，逾期将无法补选。",
        content: "详细内容：教务处发布通知，2026年春季学期选课工作将于12月20日开始，同学们需在规定时间内完成选课，逾期将无法补选。选课系统开放时间为12月20日至12月25日，具体选课流程请查看教务处网站。",
        image: "https://picsum.photos/seed/select1/600/400"
    },
    {
        id: 3,
        title: "文学院举办校园诗歌朗诵会",
        type: "event",
        college: "文学院",
        date: "2025-12-12",
        excerpt: "文学院举办了以'青春与梦想'为主题的校园诗歌朗诵会，来自各学院的同学们用优美的诗歌表达了对青春的热爱和对梦想的追求。",
        content: "详细内容：文学院举办了以'青春与梦想'为主题的校园诗歌朗诵会，来自各学院的同学们用优美的诗歌表达了对青春的热爱和对梦想的追求。活动现场气氛热烈，同学们的精彩表演赢得了观众的阵阵掌声。",
        image: "https://picsum.photos/seed/poem1/600/400"
    },
    {
        id: 4,
        title: "关于加强校园安全管理的通知",
        type: "notice",
        college: "保卫处",
        date: "2025-12-11",
        excerpt: "保卫处发布通知，为加强校园安全管理，维护校园秩序，将于近期开展校园安全大检查，请全体师生配合工作。",
        content: "详细内容：保卫处发布通知，为加强校园安全管理，维护校园秩序，将于近期开展校园安全大检查，请全体师生配合工作。检查内容包括消防安全、用电安全、宿舍安全等方面，请各单位和个人提前做好准备。",
        image: "https://picsum.photos/seed/security1/600/400"
    },
    {
        id: 5,
        title: "经济学院举办企业宣讲会",
        type: "college",
        college: "经济学院",
        date: "2025-12-10",
        excerpt: "经济学院邀请了多家知名企业来校举办宣讲会，为同学们提供就业信息和职业发展指导。",
        content: "详细内容：经济学院邀请了多家知名企业来校举办宣讲会，为同学们提供就业信息和职业发展指导。参与宣讲的企业包括银行、证券公司、互联网公司等，提供了丰富的实习和就业机会。",
        image: "https://picsum.photos/seed/economy1/600/400"
    },
    {
        id: 6,
        title: "图书馆新增电子资源数据库",
        type: "announcement",
        college: "图书馆",
        date: "2025-12-09",
        excerpt: "图书馆新增了多个电子资源数据库，包括学术期刊、电子图书、学位论文等，为师生提供更丰富的学习和研究资源。",
        content: "详细内容：图书馆新增了多个电子资源数据库，包括学术期刊、电子图书、学位论文等，为师生提供更丰富的学习和研究资源。新增数据库涵盖了各个学科领域，欢迎师生们使用。",
        image: "https://picsum.photos/seed/library1/600/400"
    },
    {
        id: 7,
        title: "体育学院举办校园运动会",
        type: "event",
        college: "体育学院",
        date: "2025-12-08",
        excerpt: "体育学院举办了一年一度的校园运动会，来自各学院的运动员们在赛场上展现了顽强拼搏的精神和良好的体育道德风尚。",
        content: "详细内容：体育学院举办了一年一度的校园运动会，来自各学院的运动员们在赛场上展现了顽强拼搏的精神和良好的体育道德风尚。运动会设立了田径、球类、趣味运动等多个项目，吸引了广大师生的参与。",
        image: "https://picsum.photos/seed/sport1/600/400"
    },
    {
        id: 8,
        title: "关于2026年寒假放假安排的通知",
        type: "notice",
        college: "校长办公室",
        date: "2025-12-07",
        excerpt: "校长办公室发布通知，2026年寒假放假时间为1月20日至2月25日，2月26日正式开学，请全体师生做好假期安排。",
        content: "详细内容：校长办公室发布通知，2026年寒假放假时间为1月20日至2月25日，2月26日正式开学，请全体师生做好假期安排。假期期间，学校将安排值班人员，确保校园安全。",
        image: "https://picsum.photos/seed/winter1/600/400"
    },
    {
        id: 9,
        title: "机械工程学院开展校企合作项目",
        type: "college",
        college: "机械工程学院",
        date: "2025-12-06",
        excerpt: "机械工程学院与多家企业开展校企合作项目，共建实习基地，为学生提供实践机会，促进产学研结合。",
        content: "详细内容：机械工程学院与多家企业开展校企合作项目，共建实习基地，为学生提供实践机会，促进产学研结合。合作企业包括机械制造、汽车制造、航空航天等领域的知名企业，为学生的职业发展提供了良好平台。",
        image: "https://picsum.photos/seed/mechanical1/600/400"
    },
    {
        id: 10,
        title: "校园网络升级改造完成",
        type: "announcement",
        college: "信息中心",
        date: "2025-12-05",
        excerpt: "信息中心完成了校园网络的升级改造，网络带宽大幅提升，覆盖范围更加广泛，为师生提供更稳定、更快速的网络服务。",
        content: "详细内容：信息中心完成了校园网络的升级改造，网络带宽大幅提升，覆盖范围更加广泛，为师生提供更稳定、更快速的网络服务。升级后的校园网络支持千兆接入，满足了师生们对高速网络的需求。",
        image: "https://picsum.photos/seed/network1/600/400"
    },
    {
        id: 11,
        title: "外国语学院举办外语文化节",
        type: "event",
        college: "外国语学院",
        date: "2025-12-04",
        excerpt: "外国语学院举办了第十届外语文化节，通过外语演讲、戏剧表演、文化展示等活动，丰富了校园文化生活。",
        content: "详细内容：外国语学院举办了第十届外语文化节，通过外语演讲、戏剧表演、文化展示等活动，丰富了校园文化生活。来自不同国家的留学生也参与了此次活动，促进了中外文化交流。",
        image: "https://picsum.photos/seed/foreign1/600/400"
    },
    {
        id: 12,
        title: "关于申报2026年科研项目的通知",
        type: "notice",
        college: "科研处",
        date: "2025-12-03",
        excerpt: "科研处发布通知，2026年科研项目申报工作正式启动，请各学院和教师积极申报。",
        content: "详细内容：科研处发布通知，2026年科研项目申报工作正式启动，请各学院和教师积极申报。申报项目包括国家级、省部级和校级科研项目，申报截止时间为1月15日，请各申报人按时提交材料。",
        image: "https://picsum.photos/seed/research1/600/400"
    },
    {
        id: 13,
        title: "建筑学院举办设计作品展",
        type: "college",
        college: "建筑学院",
        date: "2025-12-02",
        excerpt: "建筑学院举办了学生设计作品展，展示了同学们在建筑设计、城市规划等方面的优秀作品。",
        content: "详细内容：建筑学院举办了学生设计作品展，展示了同学们在建筑设计、城市规划等方面的优秀作品。作品展吸引了众多师生和业内人士参观，获得了广泛好评。",
        image: "https://picsum.photos/seed/architecture1/600/400"
    },
    {
        id: 14,
        title: "学生社团招新活动圆满结束",
        type: "announcement",
        college: "学生处",
        date: "2025-12-01",
        excerpt: "学生处组织的学生社团招新活动圆满结束，共有80多个社团参与招新，吸引了大量新生加入。",
        content: "详细内容：学生处组织的学生社团招新活动圆满结束，共有80多个社团参与招新，吸引了大量新生加入。社团涵盖了学术科技、文化艺术、体育健身、志愿服务等多个领域，为同学们提供了丰富的课余生活选择。",
        image: "https://picsum.photos/seed/club1/600/400"
    },
    {
        id: 15,
        title: "化学学院举办实验技能竞赛",
        type: "event",
        college: "化学学院",
        date: "2025-11-30",
        excerpt: "化学学院举办了学生实验技能竞赛，提高了同学们的实验操作能力和科学素养。",
        content: "详细内容：化学学院举办了学生实验技能竞赛，提高了同学们的实验操作能力和科学素养。竞赛包括基础实验操作、创新实验设计等环节，全面考核了学生的实验能力。",
        image: "https://picsum.photos/seed/chemistry1/600/400"
    },
    {
        id: 16,
        title: "关于评选优秀学生干部的通知",
        type: "notice",
        college: "学生处",
        date: "2025-11-29",
        excerpt: "学生处发布通知，开始评选2025年度优秀学生干部，请各学院按照要求推荐候选人。",
        content: "详细内容：学生处发布通知，开始评选2025年度优秀学生干部，请各学院按照要求推荐候选人。评选标准包括思想品德、学习成绩、工作能力、群众基础等方面，评选结果将在全校范围内公示。",
        image: "https://picsum.photos/seed/student1/600/400"
    },
    {
        id: 17,
        title: "生命科学学院开展科普宣传活动",
        type: "college",
        college: "生命科学学院",
        date: "2025-11-28",
        excerpt: "生命科学学院开展了科普宣传活动，通过展览、讲座、实验演示等形式，向师生普及生命科学知识。",
        content: "详细内容：生命科学学院开展了科普宣传活动，通过展览、讲座、实验演示等形式，向师生普及生命科学知识。活动内容包括生物技术、环境保护、健康生活等方面，增强了大家的科学意识。",
        image: "https://picsum.photos/seed/life1/600/400"
    },
    {
        id: 18,
        title: "校园一卡通系统升级通知",
        type: "announcement",
        college: "后勤处",
        date: "2025-11-27",
        excerpt: "后勤处发布通知，校园一卡通系统将于近期进行升级，升级期间部分功能可能受到影响，请师生们谅解。",
        content: "详细内容：后勤处发布通知，校园一卡通系统将于近期进行升级，升级期间部分功能可能受到影响，请师生们谅解。升级后的系统将增加更多便捷功能，提升服务质量。",
        image: "https://picsum.photos/seed/card1/600/400"
    },
    {
        id: 19,
        title: "马克思主义学院举办理论研讨会",
        type: "event",
        college: "马克思主义学院",
        date: "2025-11-26",
        excerpt: "马克思主义学院举办了理论研讨会，邀请了多位专家学者就当前热点理论问题进行深入探讨。",
        content: "详细内容：马克思主义学院举办了理论研讨会，邀请了多位专家学者就当前热点理论问题进行深入探讨。研讨会主题包括马克思主义中国化、新时代中国特色社会主义思想等，促进了学术交流和理论研究。",
        image: "https://picsum.photos/seed/marx1/600/400"
    },
    {
        id: 20,
        title: "关于做好2026年春季教材预订工作的通知",
        type: "notice",
        college: "教务处",
        date: "2025-11-25",
        excerpt: "教务处发布通知，开始预订2026年春季学期教材，请各学院和教师及时提交教材需求计划。",
        content: "详细内容：教务处发布通知，开始预订2026年春季学期教材，请各学院和教师及时提交教材需求计划。教材预订截止时间为12月15日，请各单位按时完成预订工作。",
        image: "https://picsum.photos/seed/book1/600/400"
    },
    {
        id: 21,
        title: "数学学院举办数学建模竞赛",
        type: "college",
        college: "数学学院",
        date: "2025-11-24",
        excerpt: "数学学院举办了数学建模竞赛，提高了同学们的数学应用能力和团队合作精神。",
        content: "详细内容：数学学院举办了数学建模竞赛，提高了同学们的数学应用能力和团队合作精神。竞赛题目涉及经济、管理、工程、环境等多个领域，同学们通过建立数学模型解决实际问题。",
        image: "https://picsum.photos/seed/math1/600/400"
    },
    {
        id: 22,
        title: "校园绿化美化工程启动",
        type: "announcement",
        college: "后勤处",
        date: "2025-11-23",
        excerpt: "后勤处启动了校园绿化美化工程，将对校园环境进行全面升级改造，营造更加优美的学习和生活环境。",
        content: "详细内容：后勤处启动了校园绿化美化工程，将对校园环境进行全面升级改造，营造更加优美的学习和生活环境。工程包括新增绿地、种植花卉、改造景观等项目，预计春节前完成。",
        image: "https://picsum.photos/seed/green1/600/400"
    }
];

// 页面加载时获取搜索参数并执行搜索
document.addEventListener('DOMContentLoaded', function() {
    // 获取URL中的搜索参数
    const urlParams = new URLSearchParams(window.location.search);
    const searchTerm = urlParams.get('q') || '';
    
    // 设置搜索输入框的值
    const searchInput = document.getElementById('searchInput');
    searchInput.value = searchTerm;
    
    // 执行搜索
    performSearch(searchTerm);
    
    // 为搜索输入框添加事件监听
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch(this.value);
        }
    });
});

// 执行搜索函数
function performSearch(searchTerm) {
    const resultsGrid = document.getElementById('resultsGrid');
    const resultsCount = document.querySelector('.results-count');
    const searchTermElement = document.querySelector('.search-term');
    
    // 更新搜索结果信息
    searchTermElement.textContent = searchTerm;
    
    // 过滤新闻数据
    let filteredNews = [];
    if (searchTerm.trim() === '') {
        filteredNews = newsData;
    } else {
        const term = searchTerm.toLowerCase();
        filteredNews = newsData.filter(news => 
            news.title.toLowerCase().includes(term) ||
            news.excerpt.toLowerCase().includes(term) ||
            news.college.toLowerCase().includes(term) ||
            news.content.toLowerCase().includes(term)
        );
    }
    
    // 更新结果数量
    resultsCount.textContent = filteredNews.length;
    
    // 生成搜索结果HTML
    if (filteredNews.length === 0) {
        resultsGrid.innerHTML = `
            <div class="no-results">
                <i class="fas fa-search"></i>
                <h2>没有找到相关新闻</h2>
                <p>请尝试其他搜索词或检查拼写是否正确</p>
            </div>
        `;
    } else {
        const resultsHTML = filteredNews.map(news => `
            <div class="news-card">
                <img src="${news.image}" alt="${news.title}" class="news-card-image">
                <div class="news-card-content">
                    <span class="news-type ${news.type}">
                        ${news.type === 'college' ? '学院新闻' : 
                          news.type === 'announcement' ? '校园公告' : 
                          news.type === 'event' ? '活动通知' : '通知公告'}
                    </span>
                    <h3 class="news-card-title">${news.title}</h3>
                    <div class="news-card-meta">
                        <span>${news.college}</span>
                        <span>${news.date}</span>
                    </div>
                    <p class="news-card-excerpt">${news.excerpt}</p>
                    <a href="#" class="read-more">
                        阅读全文 <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        `).join('');
        
        resultsGrid.innerHTML = resultsHTML;
    }
}