// DOM元素获取
const loginForm = document.getElementById('loginForm');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const rememberCheckbox = document.getElementById('remember');
const socialBtns = document.querySelectorAll('.social-btn');
const forgotPasswordLink = document.querySelector('.forgot-password');
const registerLink = document.querySelector('.register-link');

// 页面加载时检查是否有保存的用户信息
window.addEventListener('DOMContentLoaded', function() {
    loadSavedCredentials();
});

// 密码显示/隐藏切换功能
function togglePassword() {
    const passwordField = document.getElementById('password');
    const toggleIcon = passwordField.nextElementSibling;
    
    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    } else {
        passwordField.type = 'password';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    }
}

// 表单验证函数
function validateForm() {
    let isValid = true;
    
    // 清除之前的错误提示
    clearErrors();
    
    // 验证用户名/邮箱
    if (usernameInput.value.trim() === '') {
        showError(usernameInput, '用户名/邮箱不能为空');
        isValid = false;
    } else if (!isValidUsernameOrEmail(usernameInput.value.trim())) {
        showError(usernameInput, '请输入有效的用户名或邮箱地址');
        isValid = false;
    }
    
    // 验证密码
    if (passwordInput.value.trim() === '') {
        showError(passwordInput, '密码不能为空');
        isValid = false;
    } else if (passwordInput.value.trim().length < 6) {
        showError(passwordInput, '密码长度不能少于6个字符');
        isValid = false;
    }
    
    return isValid;
}

// 检查用户名/邮箱格式是否有效
function isValidUsernameOrEmail(value) {
    // 邮箱格式正则
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // 用户名格式正则（允许字母、数字、下划线，长度3-20）
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    
    return emailRegex.test(value) || usernameRegex.test(value);
}

// 显示错误信息
function showError(input, message) {
    const formGroup = input.closest('.form-group');
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.style.color = '#e53e3e';
    errorElement.style.fontSize = '0.85rem';
    errorElement.style.marginTop = '5px';
    
    formGroup.appendChild(errorElement);
    input.style.borderColor = '#e53e3e';
}

// 清除错误信息
function clearErrors() {
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(error => error.remove());
    
    // 重置输入框边框颜色
    usernameInput.style.borderColor = '';
    passwordInput.style.borderColor = '';
}

// 保存用户凭证到localStorage
function saveCredentials(username, password, remember) {
    if (remember) {
        localStorage.setItem('campus_news_username', username);
        localStorage.setItem('campus_news_password', password);
        localStorage.setItem('campus_news_remember', 'true');
    } else {
        localStorage.removeItem('campus_news_username');
        localStorage.removeItem('campus_news_password');
        localStorage.removeItem('campus_news_remember');
    }
}

// 加载保存的用户凭证
function loadSavedCredentials() {
    const remember = localStorage.getItem('campus_news_remember') === 'true';
    if (remember) {
        const username = localStorage.getItem('campus_news_username');
        const password = localStorage.getItem('campus_news_password');
        
        if (username) usernameInput.value = username;
        if (password) passwordInput.value = password;
        rememberCheckbox.checked = true;
    }
}

// 登录处理函数
function handleLogin(event) {
    event.preventDefault();
    
    if (validateForm()) {
        // 显示加载状态
        const loginBtn = loginForm.querySelector('.login-btn');
        const originalText = loginBtn.textContent;
        loginBtn.textContent = '登录中...';
        loginBtn.disabled = true;
        
        // 创建表单数据
        const formData = new FormData(loginForm);
        
        // 发送登录请求
        fetch(loginForm.action, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // 重置登录按钮
            loginBtn.textContent = originalText;
            loginBtn.disabled = false;
            
            // 处理响应
            if (data.status === 'success') {
                // 保存用户凭证
                saveCredentials(
                    usernameInput.value.trim(),
                    passwordInput.value.trim(),
                    rememberCheckbox.checked
                );
                
                // 登录成功提示
                alert(data.message);
                
                // 跳转到指定页面
                if (data.redirect) {
                    window.location.href = data.redirect;
                }
            } else {
                // 显示错误信息
                alert(data.message);
            }
        })
        .catch(error => {
            // 重置登录按钮
            loginBtn.textContent = originalText;
            loginBtn.disabled = false;
            
            // 显示网络错误
            alert('登录请求失败，请检查网络连接或稍后重试。');
            console.error('登录错误:', error);
        });
    }
}

// 社交登录处理函数
function handleSocialLogin(provider) {
    alert(`正在跳转到${provider}登录页面...`);
    // 实际项目中应实现对应的社交登录逻辑
}

// 忘记密码处理函数
function handleForgotPassword() {
    alert('忘记密码功能开发中，请联系管理员获取帮助。');
}

// 注册处理函数
function handleRegister() {
    window.location.href = 'Register.html';
}

// 事件监听器
loginForm.addEventListener('submit', handleLogin);

// 社交登录按钮点击事件
socialBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        const provider = this.classList.contains('google') ? 'Google' : '微信';
        handleSocialLogin(provider);
    });
});

// 忘记密码链接点击事件
forgotPasswordLink.addEventListener('click', function(e) {
    e.preventDefault();
    handleForgotPassword();
});

// 注册链接点击事件
registerLink.addEventListener('click', function(e) {
    e.preventDefault();
    handleRegister();
});

// 导航栏链接点击事件（检查登录状态）
const navLinks = document.querySelectorAll('.nav-links a');
navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        // 检查是否是需要登录的链接（排除首页）
        if (href !== '#home') {
            // 检查用户是否已登录
            const isLoggedIn = localStorage.getItem('campus_news_username') && localStorage.getItem('campus_news_password');
            if (!isLoggedIn) {
                e.preventDefault();
                alert('请先登录！');
            }
        }
    });
});

// 输入框焦点事件，清除错误信息
usernameInput.addEventListener('focus', clearErrors);
passwordInput.addEventListener('focus', clearErrors);

// 输入框实时验证（可选）
usernameInput.addEventListener('input', function() {
    if (this.value.trim() !== '') {
        clearErrors();
    }
});

passwordInput.addEventListener('input', function() {
    if (this.value.trim() !== '') {
        clearErrors();
    }
});

// 页面滚动效果
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
    } else {
        navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    }
});

// 响应式导航菜单（移动端）
function toggleNavMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('show');
}

// 添加移动端菜单按钮（如果需要）
const navbar = document.querySelector('.navbar .container');
if (window.innerWidth <= 768 && !document.querySelector('.mobile-menu-btn')) {
    const mobileMenuBtn = document.createElement('button');
    mobileMenuBtn.className = 'mobile-menu-btn';
    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
    mobileMenuBtn.style.background = 'none';
    mobileMenuBtn.style.border = 'none';
    mobileMenuBtn.style.color = '#667eea';
    mobileMenuBtn.style.fontSize = '1.5rem';
    mobileMenuBtn.style.cursor = 'pointer';
    mobileMenuBtn.addEventListener('click', toggleNavMenu);
    
    navbar.appendChild(mobileMenuBtn);
}