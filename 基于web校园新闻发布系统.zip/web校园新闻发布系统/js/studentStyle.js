// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 导航切换功能
    const navLinks = document.querySelectorAll('.nav-links a');
    const contentSections = document.querySelectorAll('.content-section');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 获取目标内容区域的ID
            const targetId = this.getAttribute('href').substring(1);
            
            // 移除所有链接的active类
            navLinks.forEach(nav => nav.classList.remove('active'));
            
            // 移除所有内容区域的active类并添加hidden类
            contentSections.forEach(section => {
                section.classList.remove('active');
                section.classList.add('hidden');
            });
            
            // 为当前链接添加active类
            this.classList.add('active');
            
            // 显示目标内容区域
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.remove('hidden');
                targetSection.classList.add('active');
            }
        });
    });
    
    // 轮播图功能
    let currentSlide = 0;
    const slides = document.querySelectorAll('.carousel-item');
    const indicators = document.querySelectorAll('.indicator');
    
    // 显示当前幻灯片
    function showSlide(index) {
        // 隐藏所有幻灯片
        slides.forEach(slide => slide.classList.remove('active'));
        // 移除所有指示器的active类
        indicators.forEach(indicator => indicator.classList.remove('active'));
        
        // 显示当前幻灯片
        slides[index].classList.add('active');
        // 激活当前指示器
        indicators[index].classList.add('active');
        
        // 更新当前索引
        currentSlide = index;
    }
    
    // 下一张幻灯片
    window.nextSlide = function() {
        const nextIndex = (currentSlide + 1) % slides.length;
        showSlide(nextIndex);
    };
    
    // 上一张幻灯片
    window.prevSlide = function() {
        const prevIndex = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(prevIndex);
    };
    
    // 跳转到指定幻灯片
    window.goToSlide = function(index) {
        showSlide(index);
    };
    
    // 自动轮播
    let slideInterval = setInterval(nextSlide, 5000);
    
    // 鼠标悬停时停止自动轮播
    const carouselContainer = document.querySelector('.carousel-container');
    carouselContainer.addEventListener('mouseenter', function() {
        clearInterval(slideInterval);
    });
    
    // 鼠标离开时恢复自动轮播
    carouselContainer.addEventListener('mouseleave', function() {
        slideInterval = setInterval(nextSlide, 5000);
    });
    
    // 默认新闻数据
    const newsData = [
        {
            id: 1,
            title: '校园文化节隆重开幕',
            category: 'activity',
            date: '2025-12-10',
            author: '新闻中心',
            excerpt: '12月10日，我校一年一度的校园文化节在主体育场隆重开幕。本次文化节以“青春绽放，梦想启航”为主题，吸引了来自全校各学院的师生积极参与。',
            image: 'image/Carousel1.jpg'
        },
        {
            id: 2,
            title: '计算机学院举办编程大赛',
            category: 'academic',
            date: '2025-12-08',
            author: '计算机学院',
            excerpt: '为提高学生的编程能力和创新思维，计算机学院于12月8日举办了第十届校园编程大赛，共有来自全校300余名学生参赛。',
            image: 'image/Carousel2.jpg'
        },
        {
            id: 3,
            title: '2026年春季学期选课通知',
            category: 'notice',
            date: '2025-12-05',
            author: '教务处',
            excerpt: '2026年春季学期选课工作将于12月15日开始，12月25日结束。请同学们提前做好选课准备，按照学院安排的时间进行选课。',
            image: 'image/Carousel3.jpg'
        },
        {
            id: 4,
            title: '我校在全国大学生数学建模竞赛中获得佳绩',
            category: 'achievement',
            date: '2025-12-03',
            author: '数学学院',
            excerpt: '近日，2025年全国大学生数学建模竞赛结果揭晓，我校参赛队伍共获得一等奖3项，二等奖5项，三等奖10项，取得了历史最好成绩。',
            image: 'image/Carousel1.jpg'
        },
        {
            id: 5,
            title: '校园冬季运动会圆满结束',
            category: 'activity',
            date: '2025-11-28',
            author: '体育学院',
            excerpt: '11月28日，为期三天的校园冬季运动会圆满结束。本次运动会共设有15个比赛项目，来自全校各学院的2000余名运动员参加了比赛。',
            image: 'image/Carousel2.jpg'
        },
        {
            id: 6,
            title: '关于加强校园安全管理的通知',
            category: 'notice',
            date: '2025-11-25',
            author: '保卫处',
            excerpt: '为加强校园安全管理，保障师生人身财产安全，保卫处决定从12月1日起，进一步加强校园出入管理和夜间巡逻工作。',
            image: 'image/Carousel3.jpg'
        }
    ];
    
    // 学院传声筒数据
    const departmentNews = [
        {
            id: 1,
            title: '计算机学院举办人工智能前沿讲座',
            category: 'academic',
            date: '2025-12-09',
            author: '计算机学院',
            excerpt: '为拓展学生视野，计算机学院特邀人工智能领域专家王教授来校作前沿讲座，分享最新研究成果。',
            image: 'image/Carousel1.jpg'
        },
        {
            id: 2,
            title: '文学院举办年度论文答辩会',
            category: 'academic',
            date: '2025-12-08',
            author: '文学院',
            excerpt: '文学院2025年度硕士论文答辩会于12月8日在文心楼举行，共有50名研究生参加答辩。',
            image: 'image/Carousel2.jpg'
        },
        {
            id: 3,
            title: '理学院实验室开放日活动顺利开展',
            category: 'activity',
            date: '2025-12-07',
            author: '理学院',
            excerpt: '理学院举办实验室开放日活动，邀请各学院学生参观物理、化学等重点实验室，激发学生科研兴趣。',
            image: 'image/Carousel3.jpg'
        }
    ];
    
    // 默认论坛话题数据
    const forumTopics = [
        {
            id: 1,
            title: '分享一下我的学习经验',
            category: 'study',
            author: '学霸小明',
            date: '2025-12-09',
            replies: 12,
            views: 156
        },
        {
            id: 2,
            title: '求推荐一些好用的编程工具',
            category: 'study',
            author: '编程小白',
            date: '2025-12-08',
            replies: 8,
            views: 98
        },
        {
            id: 3,
            title: '周末想去爬山，有人一起吗？',
            category: 'life',
            author: '户外运动爱好者',
            date: '2025-12-07',
            replies: 15,
            views: 203
        },
        {
            id: 4,
            title: '2026届毕业生就业形势分析',
            category: 'career',
            author: '就业指导中心',
            date: '2025-12-06',
            replies: 20,
            views: 312
        },
        {
            id: 5,
            title: '校园音乐节即将到来，你最期待哪个乐队？',
            category: 'hobby',
            author: '音乐迷',
            date: '2025-12-05',
            replies: 25,
            views: 423
        },
        {
            id: 6,
            title: '求购二手自行车',
            category: 'life',
            author: '新生小周',
            date: '2025-12-04',
            replies: 5,
            views: 87
        }
    ];
    
    // 生成新闻卡片
    function generateNewsCards(news, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = '';
        
        news.forEach(item => {
            const card = document.createElement('div');
            card.className = 'news-card';
            
            card.innerHTML = `
                <img src="${item.image}" alt="${item.title}" class="news-card-image">
                <div class="news-card-content">
                    <h3 class="news-card-title">${item.title}</h3>
                    <div class="news-card-meta">
                        <span><i class="fas fa-calendar-alt"></i> ${item.date}</span>
                        <span><i class="fas fa-user"></i> ${item.author}</span>
                        <span><i class="fas fa-tag"></i> ${getCategoryName(item.category)}</span>
                    </div>
                    <p class="news-card-excerpt">${item.excerpt}</p>
                    <a href="#" class="read-more">阅读全文 <i class="fas fa-arrow-right"></i></a>
                </div>
            `;
            
            container.appendChild(card);
        });
    }
    
    // 生成论坛话题列表
    function generateTopicList(topics, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = '';
        
        topics.forEach(topic => {
            const topicItem = document.createElement('div');
            topicItem.className = 'topic-item';
            
            topicItem.innerHTML = `
                <div class="topic-title">${topic.title}</div>
                <div class="topic-meta">
                    <span><i class="fas fa-user"></i> ${topic.author}</span>
                    <span><i class="fas fa-calendar-alt"></i> ${topic.date}</span>
                    <span><i class="fas fa-comment"></i> ${topic.replies} 回复</span>
                    <span><i class="fas fa-eye"></i> ${topic.views} 浏览</span>
                    <span><i class="fas fa-tag"></i> ${getCategoryName(topic.category)}</span>
                </div>
            `;
            
            container.appendChild(topicItem);
        });
    }
    
    // 获取分类名称
    function getCategoryName(category) {
        const categoryMap = {
            'notice': '通知公告',
            'activity': '校园活动',
            'academic': '学术动态',
            'achievement': '成果展示',
            'study': '学习交流',
            'life': '校园生活',
            'career': '就业创业',
            'hobby': '兴趣爱好'
        };
        
        return categoryMap[category] || category;
    }
    
    // 初始化页面数据
    // 首页最新新闻（显示3条）
    generateNewsCards(newsData.slice(0, 3), 'latestNewsGrid');
    
    // 首页热门话题（显示2条）
    generateTopicList(forumTopics.slice(0, 2), 'hotTopicsList');
    
    // 首页学院传声筒（显示3条）
    generateNewsCards(departmentNews, 'departmentNewsGrid');
    
    // 校园新闻页面（显示所有新闻）
    generateNewsCards(newsData, 'campusNewsList');
    
    // 论坛交流页面（显示所有话题）
    generateTopicList(forumTopics, 'forumTopicList');
    
    // 新闻分类筛选功能
    const newsCategoryBtns = document.querySelectorAll('.news-categories .category-btn');
    
    newsCategoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // 移除所有按钮的active类
            newsCategoryBtns.forEach(button => button.classList.remove('active'));
            
            // 为当前按钮添加active类
            this.classList.add('active');
            
            // 获取选中的分类
            const category = this.getAttribute('data-category');
            
            // 筛选新闻
            let filteredNews;
            if (category === 'all') {
                filteredNews = newsData;
            } else {
                filteredNews = newsData.filter(news => news.category === category);
            }
            
            // 重新生成新闻列表
            generateNewsCards(filteredNews, 'campusNewsList');
        });
    });
    
    // 论坛分类筛选功能
    const forumCategoryBtns = document.querySelectorAll('.forum-categories .category-btn');
    
    forumCategoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // 移除所有按钮的active类
            forumCategoryBtns.forEach(button => button.classList.remove('active'));
            
            // 为当前按钮添加active类
            this.classList.add('active');
            
            // 获取选中的分类
            const category = this.getAttribute('data-category');
            
            // 筛选话题
            let filteredTopics;
            if (category === 'all') {
                filteredTopics = forumTopics;
            } else {
                filteredTopics = forumTopics.filter(topic => topic.category === category);
            }
            
            // 重新生成话题列表
            generateTopicList(filteredTopics, 'forumTopicList');
        });
    });
    
    // 留言反馈表单提交功能
    const feedbackForm = document.getElementById('feedbackForm');
    const feedbackList = document.getElementById('feedbackList');
    
    // 初始化留言列表
    const feedbackData = [
        {
            id: 1,
            title: '建议增加新闻搜索功能',
            content: '希望能够增加按关键词搜索新闻的功能，这样可以更方便地找到感兴趣的内容。',
            date: '2025-12-07'
        },
        {
            id: 2,
            title: '论坛界面优化建议',
            content: '建议论坛界面能够更加美观，增加一些互动功能，比如点赞、收藏等。',
            date: '2025-12-05'
        }
    ];
    
    // 生成留言列表
    function generateFeedbackList(feedback) {
        if (!feedbackList) return;
        
        feedbackList.innerHTML = '';
        
        feedback.forEach(item => {
            const feedbackItem = document.createElement('div');
            feedbackItem.className = 'feedback-item';
            
            feedbackItem.innerHTML = `
                <h4>${item.title}</h4>
                <div class="feedback-date">${item.date}</div>
                <div class="feedback-content">${item.content}</div>
            `;
            
            feedbackList.appendChild(feedbackItem);
        });
    }
    
    // 初始化留言列表
    generateFeedbackList(feedbackData);
    
    // 处理表单提交
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // 获取表单数据
            const title = document.getElementById('feedbackTitle').value;
            const content = document.getElementById('feedbackContent').value;
            
            // 创建新留言
            const newFeedback = {
                id: feedbackData.length + 1,
                title: title,
                content: content,
                date: new Date().toISOString().split('T')[0]
            };
            
            // 添加到留言数据中
            feedbackData.unshift(newFeedback);
            
            // 重新生成留言列表
            generateFeedbackList(feedbackData);
            
            // 重置表单
            this.reset();
            
            // 显示提交成功提示
            alert('留言提交成功！');
        });
    }
    
    // 搜索功能（简化版）
    const newsSearch = document.getElementById('newsSearch');
    if (newsSearch) {
        newsSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            
            // 筛选新闻
            const filteredNews = newsData.filter(news => 
                news.title.toLowerCase().includes(searchTerm) || 
                news.excerpt.toLowerCase().includes(searchTerm)
            );
            
            // 重新生成新闻列表
            generateNewsCards(filteredNews, 'campusNewsList');
        });
    }
    
    // 顶部导航栏搜索功能
    const topSearchBar = document.querySelector('.top-search-bar input');
    if (topSearchBar) {
        topSearchBar.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value.trim();
                if (searchTerm) {
                    window.location.href = `search.html?q=${encodeURIComponent(searchTerm)}`;
                }
            }
        });
    }
    
    // 个人中心数据展示
    // 这里可以根据实际情况从服务器获取用户数据
    const userName = document.getElementById('userName');
    const userStudentId = document.getElementById('userStudentId');
    const userDepartment = document.getElementById('userDepartment');
    const userMajor = document.getElementById('userMajor');
    
    // 模拟用户数据
    const userData = {
        name: '张三',
        studentId: '20210001',
        department: '计算机科学与技术学院',
        major: '计算机科学与技术'
    };
    
    // 更新个人中心数据
    if (userName) userName.textContent = userData.name;
    if (userStudentId) userStudentId.textContent = `学号：${userData.studentId}`;
    if (userDepartment) userDepartment.textContent = `学院：${userData.department}`;
    if (userMajor) userMajor.textContent = `专业：${userData.major}`;
});