// 用户类型切换
document.addEventListener('DOMContentLoaded', function() {
    const userTypeBtns = document.querySelectorAll('.user-type-btn');
    const studentFields = document.querySelector('.student-fields');
    const adminFields = document.querySelector('.admin-fields');
    const userTypeInput = document.getElementById('userType');

    userTypeBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // 移除所有按钮的active类
            userTypeBtns.forEach(b => b.classList.remove('active'));
            // 为当前按钮添加active类
            this.classList.add('active');
            // 更新隐藏输入的值
            userTypeInput.value = this.dataset.type;
            // 显示/隐藏对应字段
            if (this.dataset.type === 'student') {
                studentFields.classList.remove('hidden');
                adminFields.classList.add('hidden');
            } else {
                studentFields.classList.add('hidden');
                adminFields.classList.remove('hidden');
            }
        });
    });

    // 密码可见性切换
    const togglePasswordIcons = document.querySelectorAll('.toggle-password');
    togglePasswordIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            const input = this.previousElementSibling;
            if (input.type === 'password') {
                input.type = 'text';
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            } else {
                input.type = 'password';
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            }
        });
    });

    // 表单验证
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (validateForm()) {
                // 提交表单
                const formData = new FormData(this);
                
                // 显示加载状态
                const registerBtn = this.querySelector('.register-btn');
                const originalText = registerBtn.textContent;
                registerBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 注册中...';
                registerBtn.disabled = true;
                
                // 发送AJAX请求
                fetch(this.action, { method: 'POST', body: formData })
                    .then(response => response.json())
                    .then(data => {
                        // 恢复按钮状态
                        registerBtn.textContent = originalText;
                        registerBtn.disabled = false;
                        
                        // 处理响应
                        if (data.status === 'success') {
                            alert('注册成功！');
                            window.location.href = 'index.html';
                        } else {
                            alert('注册失败：' + data.message);
                        }
                    })
                    .catch(error => {
                        // 恢复按钮状态
                        registerBtn.textContent = originalText;
                        registerBtn.disabled = false;
                        alert('注册失败，请稍后重试。');
                    });
            }
        });
    }

    // 表单验证函数
    function validateForm() {
        let isValid = true;
        const form = document.getElementById('registerForm');
        const userType = document.getElementById('userType').value;
        
        // 重置所有错误信息
        const errorMessages = form.querySelectorAll('.error-message');
        errorMessages.forEach(msg => msg.remove());
        
        // 验证用户名
        const username = document.getElementById('username').value.trim();
        if (username === '') {
            showError('username', '用户名不能为空');
            isValid = false;
        } else if (username.length < 3) {
            showError('username', '用户名至少需要3个字符');
            isValid = false;
        }
        
        // 验证邮箱
        const email = document.getElementById('email').value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email === '') {
            showError('email', '邮箱不能为空');
            isValid = false;
        } else if (!emailRegex.test(email)) {
            showError('email', '请输入有效的邮箱地址');
            isValid = false;
        }
        
        // 验证密码
        const password = document.getElementById('password').value;
        if (password === '') {
            showError('password', '密码不能为空');
            isValid = false;
        } else if (password.length < 6) {
            showError('password', '密码至少需要6个字符');
            isValid = false;
        }
        
        // 验证确认密码
        const confirmPassword = document.getElementById('confirmPassword').value;
        if (confirmPassword === '') {
            showError('confirmPassword', '请确认密码');
            isValid = false;
        } else if (password !== confirmPassword) {
            showError('confirmPassword', '两次输入的密码不一致');
            isValid = false;
        }
        
        // 根据用户类型验证特定字段
        if (userType === 'student') {
            const studentId = document.getElementById('studentId').value.trim();
            if (studentId === '') {
                showError('studentId', '学号不能为空');
                isValid = false;
            }
            
            const major = document.getElementById('major').value.trim();
            if (major === '') {
                showError('major', '专业不能为空');
                isValid = false;
            }
        } else {
            const adminId = document.getElementById('adminId').value.trim();
            if (adminId === '') {
                showError('adminId', '管理员ID不能为空');
                isValid = false;
            }
            
            const department = document.getElementById('department').value.trim();
            if (department === '') {
                showError('department', '部门不能为空');
                isValid = false;
            }
        }
        
        // 验证服务条款
        const terms = document.getElementById('terms');
        if (!terms.checked) {
            const termsGroup = terms.closest('.form-group');
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.textContent = '请同意服务条款和隐私政策';
            errorDiv.style.color = 'red';
            errorDiv.style.fontSize = '0.8rem';
            errorDiv.style.marginTop = '5px';
            termsGroup.appendChild(errorDiv);
            isValid = false;
        }
        
        return isValid;
    }
    
    // 显示错误信息
    function showError(inputId, message) {
        const input = document.getElementById(inputId);
        const inputWrapper = input.closest('.input-wrapper');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        errorDiv.style.color = 'red';
        errorDiv.style.fontSize = '0.8rem';
        errorDiv.style.marginTop = '5px';
        inputWrapper.parentNode.appendChild(errorDiv);
        input.style.borderColor = 'red';
    }
    
    // 实时输入验证
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            // 移除错误信息
            const errorMessage = this.closest('.form-group').querySelector('.error-message');
            if (errorMessage) {
                errorMessage.remove();
            }
            // 恢复输入框样式
            this.style.borderColor = '';
        });
    });
});