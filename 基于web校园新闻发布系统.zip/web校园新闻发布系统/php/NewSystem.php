<?php
// 设置响应头为JSON格式
header('Content-Type: application/json');

// 数据库连接配置
$host = 'localhost';
$dbname = 'CampusNewsSystem';
$username = 'root';
$password = '';

// 创建数据库连接
$conn = new mysqli($host, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => '数据库连接失败: ' . $conn->connect_error]);
    exit;
}

// 设置字符集
$conn->set_charset('utf8mb4');

// 获取请求类型
$action = $_POST['action'] ?? '';

// 根据请求类型处理不同的功能
switch ($action) {
    case 'register':
        handleRegister($conn);
        break;
    case 'login':
        handleLogin($conn);
        break;
    default:
        echo json_encode(['status' => 'error', 'message' => '无效的请求']);
}

// 关闭数据库连接
$conn->close();

/**
 * 处理用户注册
 */
function handleRegister($conn) {
    // 获取表单数据
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $userType = $_POST['user_type'] ?? '';
    $studentId = $_POST['studentId'] ?? null;
    $major = $_POST['major'] ?? null;
    $adminId = $_POST['adminId'] ?? null;
    $department = $_POST['department'] ?? null;

    // 验证数据
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword) || empty($userType)) {
        echo json_encode(['status' => 'error', 'message' => '请填写所有必填字段']);
        return;
    }

    // 验证密码一致性
    if ($password !== $confirmPassword) {
        echo json_encode(['status' => 'error', 'message' => '两次输入的密码不一致']);
        return;
    }

    // 验证邮箱格式
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['status' => 'error', 'message' => '请输入有效的邮箱地址']);
        return;
    }

    // 根据用户类型验证特定字段
    if ($userType === 'student') {
        if (empty($studentId) || empty($major)) {
            echo json_encode(['status' => 'error', 'message' => '请填写学号和专业']);
            return;
        }
    } else if ($userType === 'admin') {
        if (empty($adminId) || empty($department)) {
            echo json_encode(['status' => 'error', 'message' => '请填写管理员ID和部门']);
            return;
        }
    }

    // 检查用户名是否已存在
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => '用户名已存在']);
        $stmt->close();
        return;
    }
    $stmt->close();

    // 检查邮箱是否已存在
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => '邮箱已被注册']);
        $stmt->close();
        return;
    }
    $stmt->close();

    // 检查学生ID是否已存在
    if ($userType === 'student' && !empty($studentId)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE student_id = ?");
        $stmt->bind_param("s", $studentId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            echo json_encode(['status' => 'error', 'message' => '学号已被注册']);
            $stmt->close();
            return;
        }
        $stmt->close();
    }

    // 检查管理员ID是否已存在
    if ($userType === 'admin' && !empty($adminId)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE admin_id = ?");
        $stmt->bind_param("s", $adminId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            echo json_encode(['status' => 'error', 'message' => '管理员ID已被注册']);
            $stmt->close();
            return;
        }
        $stmt->close();
    }

    // 加密密码
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // 插入用户数据
    if ($userType === 'student') {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, user_type, student_id, major) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $username, $email, $hashedPassword, $userType, $studentId, $major);
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, user_type, admin_id, department) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $username, $email, $hashedPassword, $userType, $adminId, $department);
    }

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => '注册成功']);
    } else {
        echo json_encode(['status' => 'error', 'message' => '注册失败: ' . $stmt->error]);
    }

    $stmt->close();
}

/**
 * 处理用户登录
 */
function handleLogin($conn) {
    // 获取表单数据
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // 验证数据
    if (empty($username) || empty($password)) {
        echo json_encode(['status' => 'error', 'message' => '请填写用户名和密码']);
        return;
    }

    // 查询用户
    $stmt = $conn->prepare("SELECT id, username, email, password, user_type FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['status' => 'error', 'message' => '用户名或密码错误']);
        $stmt->close();
        return;
    }

    $user = $result->fetch_assoc();
    $stmt->close();

    // 验证密码
    if (!password_verify($password, $user['password'])) {
        echo json_encode(['status' => 'error', 'message' => '用户名或密码错误']);
        return;
    }

    // 登录成功，设置会话
    session_start();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['user_type'] = $user['user_type'];

    // 返回成功响应
    echo json_encode([
        'status' => 'success', 
        'message' => '登录成功',
        'redirect' => ($user['user_type'] === 'admin') ? 'admin.html' : 'index.html'
    ]);
}